import { SubjectHoursProgress, ComplementaryActivity, CalendarItem } from '../types';
import { parseTimeToMinutes } from '../utils/dateUtils';

export const INITIAL_SUBJECTS: SubjectHoursProgress[] = [
  {
    id: 'sub-calc3',
    code: 'MAT-301',
    name: 'Cálculo Diferencial e Integral III',
    layer: 'faculdade',
    colorHex: '#4A879F',
    totalRequiredHours: 60,
    completedHours: 28.5,
    plannedHoursThisWeek: 4.5,
    credits: 4,
    professor: 'Prof. Dr. Armando Silveira',
    semester: '2025.1',
  },
  {
    id: 'sub-engsw2',
    code: 'ENG-202',
    name: 'Engenharia de Software II',
    layer: 'faculdade',
    colorHex: '#4A879F',
    totalRequiredHours: 60,
    completedHours: 24.0,
    plannedHoursThisWeek: 4.0,
    credits: 4,
    professor: 'Profa. Dra. Helena Mendes',
    semester: '2025.1',
  },
  {
    id: 'sub-tcc',
    code: 'TCC-600',
    name: 'TCC & Pesquisa Acadêmica',
    layer: 'tcc',
    colorHex: '#D85F79',
    totalRequiredHours: 120,
    completedHours: 48.0,
    plannedHoursThisWeek: 6.0,
    credits: 8,
    professor: 'Orientador Prof. Carlos Eduardo',
    semester: '2025.1',
  },
  {
    id: 'sub-prob',
    code: 'EST-104',
    name: 'Probabilidade e Estatística',
    layer: 'estudos',
    colorHex: '#5A9F76',
    totalRequiredHours: 45,
    completedHours: 18.0,
    plannedHoursThisWeek: 3.5,
    credits: 3,
    professor: 'Prof. Vinícius K.',
    semester: '2025.1',
  },
  {
    id: 'sub-mkt',
    code: 'MKT-110',
    name: 'Marketing & Comunicação',
    layer: 'marketing',
    colorHex: '#BD913C',
    totalRequiredHours: 30,
    completedHours: 12.0,
    plannedHoursThisWeek: 2.0,
    credits: 2,
    professor: 'Profa. Beatriz Lima',
    semester: '2025.1',
  },
];

export const INITIAL_COMPLEMENTARY_ACTIVITIES: ComplementaryActivity[] = [
  {
    id: 'ac-1',
    title: 'Iniciação Científica em Sistemas Inteligentes',
    category: 'pesquisa',
    categoryLabel: 'Pesquisa / IC',
    hours: 30,
    date: '2024-11-20',
    institution: 'Laboratório de Inteligência Computacional',
    validated: true,
    certificateUrl: 'cert-ic-2024.pdf',
  },
  {
    id: 'ac-2',
    title: 'Workshop de Design de Interação & Acessibilidade',
    category: 'extensao',
    categoryLabel: 'Extensão Universitária',
    hours: 16,
    date: '2024-12-05',
    institution: 'Semana de Tecnologia Aplicada',
    validated: true,
    certificateUrl: 'cert-ux-2024.pdf',
  },
  {
    id: 'ac-3',
    title: 'Monitoria Voluntária de Algoritmos I',
    category: 'ensino',
    categoryLabel: 'Ensino / Monitoria',
    hours: 22,
    date: '2024-10-15',
    institution: 'Departamento de Computação',
    validated: true,
    certificateUrl: 'cert-monitoria.pdf',
  },
  {
    id: 'ac-4',
    title: 'Curso de Especialização em Git e CI/CD',
    category: 'outro',
    categoryLabel: 'Curso Extracurricular',
    hours: 15,
    date: '2025-01-10',
    institution: 'Plataforma Aberta de Engenharia',
    validated: false,
    certificateUrl: 'cert-git-2025.pdf',
  },
];

/**
 * Computes weekly and overall hours statistics directly from real calendar items.
 */
export function calculateHoursStats(items: CalendarItem[], targetWeekDate: string) {
  let plannedMinutes = 0;
  let completedMinutes = 0;
  let focusSessionsCount = 0;

  const byLayer: Record<string, { planned: number; completed: number; count: number; plannedBlocks: number; completedBlocks: number }> = {
    faculdade: { planned: 0, completed: 0, count: 0, plannedBlocks: 0, completedBlocks: 0 },
    tcc: { planned: 0, completed: 0, count: 0, plannedBlocks: 0, completedBlocks: 0 },
    estudos: { planned: 0, completed: 0, count: 0, plannedBlocks: 0, completedBlocks: 0 },
    marketing: { planned: 0, completed: 0, count: 0, plannedBlocks: 0, completedBlocks: 0 },
    google_calendar: { planned: 0, completed: 0, count: 0, plannedBlocks: 0, completedBlocks: 0 },
  };

  items.forEach((item) => {
    const itemPlannedMins = item.plannedDurationMinutes || (parseTimeToMinutes(item.endTime) - parseTimeToMinutes(item.startTime)) || 0;
    let itemCompletedMins = 0;

    if (item.actualExecution?.durationMinutes) {
      itemCompletedMins = item.actualExecution.durationMinutes;
      focusSessionsCount++;
    } else if (item.status === 'concluido') {
      itemCompletedMins = itemPlannedMins;
    }

    plannedMinutes += itemPlannedMins;
    completedMinutes += itemCompletedMins;

    const layerKey = item.layer || 'faculdade';
    if (!byLayer[layerKey]) {
      byLayer[layerKey] = { planned: 0, completed: 0, count: 0, plannedBlocks: 0, completedBlocks: 0 };
    }
    byLayer[layerKey].planned += itemPlannedMins;
    byLayer[layerKey].completed += itemCompletedMins;
    byLayer[layerKey].count += 1;
    byLayer[layerKey].plannedBlocks += Math.round(itemPlannedMins / 30);
    byLayer[layerKey].completedBlocks += Math.round(itemCompletedMins / 30);
  });

  const efficiencyRate = plannedMinutes > 0 ? Math.min(100, Math.round((completedMinutes / plannedMinutes) * 100)) : 100;
  const planned30mBlocks = Math.round(plannedMinutes / 30);
  const completed30mBlocks = Math.round(completedMinutes / 30);

  return {
    plannedHours: Number((plannedMinutes / 60).toFixed(1)),
    completedHours: Number((completedMinutes / 60).toFixed(1)),
    plannedMinutes,
    completedMinutes,
    planned30mBlocks,
    completed30mBlocks,
    focusSessionsCount,
    efficiencyRate,
    byLayer,
  };
}
