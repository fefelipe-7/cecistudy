import React, { useEffect } from 'react';
import { CheckCircle2, AlertCircle, Info, Sparkles, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type?: 'success' | 'info' | 'warning' | 'sparkles';
}

interface ToastNotificationProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastNotification: React.FC<ToastNotificationProps> = ({ toasts, onDismiss }) => {
  return (
    <div className="fixed top-20 right-6 z-50 flex flex-col gap-2 pointer-events-none max-w-sm w-full select-none">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
};

const ToastItem: React.FC<{ toast: ToastMessage; onDismiss: (id: string) => void }> = ({
  toast,
  onDismiss,
}) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 4000);
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const getIcon = () => {
    switch (toast.type) {
      case 'sparkles':
        return <Sparkles size={16} className="text-[#D85F79]" />;
      case 'warning':
        return <AlertCircle size={16} className="text-[#BD913C]" />;
      case 'info':
        return <Info size={16} className="text-[#4A879F]" />;
      default:
        return <CheckCircle2 size={16} className="text-[#5A9F76]" />;
    }
  };

  return (
    <div className="pointer-events-auto bg-white/95 backdrop-blur-md border border-[#E9DFDC] p-3.5 rounded-2xl shadow-xl flex items-start gap-3 animate-in fade-in slide-in-from-top-3 duration-200">
      <div className="shrink-0 mt-0.5">{getIcon()}</div>
      <div className="flex flex-col flex-1 min-w-0">
        <span className="text-xs font-bold text-[#40383A]">{toast.title}</span>
        {toast.description && (
          <span className="text-[11px] text-[#6D6366] mt-0.5 leading-snug">
            {toast.description}
          </span>
        )}
      </div>
      <button
        onClick={() => onDismiss(toast.id)}
        className="text-[#ADA3A5] hover:text-[#40383A] p-0.5 rounded-md cursor-pointer transition-colors"
      >
        <X size={14} />
      </button>
    </div>
  );
};
