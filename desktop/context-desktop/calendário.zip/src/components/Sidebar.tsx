import React, { useState, useEffect } from 'react';
import {
  Home,
  BookOpen,
  Calendar as CalendarIcon,
  FolderHeart,
  Brain,
  Megaphone,
  Inbox,
  Share2,
  Search,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  Plus,
  Check,
  Layers,
  Sparkle,
  Volume2,
  VolumeX,
  Target,
  Flame,
  CheckCircle2,
  Award,
} from 'lucide-react';
import { LayerConfig } from '../types';
import { ambientSound } from '../utils/ambientAudio';
import { parseDateSafe, isToday, getCurrentDateISO } from '../utils/dateUtils';

interface SidebarProps {
  activeNav: string;
  onNavChange: (nav: string) => void;
  layers: LayerConfig[];
  onToggleLayer: (layerId: string) => void;
  selectedDate: string;
  onSelectDate: (date: string) => void;
  onOpenSettings: () => void;
  onOpenSuggestions: () => void;
  suggestionsCount: number;
  onOpenNewItemModal: () => void;
  onOpenCommandPalette: () => void;
  onStartFocusSession?: () => void;
  onOpenHoursKnowledge?: () => void;
  completedHoursThisWeek?: number;
  goalHoursThisWeek?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeNav,
  onNavChange,
  layers,
  onToggleLayer,
  selectedDate,
  onSelectDate,
  onOpenSettings,
  onOpenSuggestions,
  suggestionsCount,
  onOpenNewItemModal,
  onOpenCommandPalette,
  onStartFocusSession,
  onOpenHoursKnowledge,
  completedHoursThisWeek = 14.5,
  goalHoursThisWeek = 20,
}) => {
  const [showLayers, setShowLayers] = useState(true);
  const [workspaceMenuOpen, setWorkspaceMenuOpen] = useState(false);
  const [activeWorkspace, setActiveWorkspace] = useState('Acadêmico');
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [audioMode, setAudioMode] = useState<'rain' | 'deep_focus' | 'cafe'>('rain');

  // Mini-calendar date state (synced with selectedDate initially)
  const initialDateObj = parseDateSafe(selectedDate);
  const [miniCalMonth, setMiniCalMonth] = useState(initialDateObj.getMonth());
  const [miniCalYear, setMiniCalYear] = useState(initialDateObj.getFullYear());

  useEffect(() => {
    const d = parseDateSafe(selectedDate);
    setMiniCalMonth(d.getMonth());
    setMiniCalYear(d.getFullYear());
  }, [selectedDate]);

  const mainNavItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'conhecimento', label: 'Base de Conhecimento', icon: BookOpen, badge: 'Horas' },
    { id: 'calendario', label: 'Calendário', icon: CalendarIcon },
    { id: 'tcc', label: 'Projetos & TCC', icon: FolderHeart },
    { id: 'estudos', label: 'Estudos', icon: Brain },
    { id: 'marketing', label: 'Marketing', icon: Megaphone },
  ];

  const workspaces = [
    { name: 'Acadêmico', desc: 'Faculdade, TCC e Horas AC', color: '#4A879F' },
    { name: 'Base de Conhecimento', desc: 'Banco de Horas & Matérias', color: '#D85F79' },
    { name: 'Pessoal & Rotina', desc: 'Hábitos e Saúde', color: '#5A9F76' },
    { name: 'Projetos Criativos', desc: 'Design e Portfólio', color: '#BD913C' },
  ];

  const toggleSound = () => {
    if (isAudioPlaying) {
      ambientSound.stop();
      setIsAudioPlaying(false);
    } else {
      ambientSound.play(audioMode, 0.2);
      setIsAudioPlaying(true);
    }
  };

  const changeAudioMode = (mode: 'rain' | 'deep_focus' | 'cafe') => {
    setAudioMode(mode);
    if (isAudioPlaying) {
      ambientSound.play(mode, 0.2);
    }
  };

  // Mini-calendar generator
  const daysInMonth = new Date(miniCalYear, miniCalMonth + 1, 0).getDate();
  const firstDayOfWeek = new Date(miniCalYear, miniCalMonth, 1).getDay(); // 0 = Sun
  const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

  const progressPercent = Math.min(100, Math.round((completedHoursThisWeek / goalHoursThisWeek) * 100));

  return (
    <aside
      id="app-sidebar"
      className="w-64 bg-[#FAF8F5] border-r border-[#E9DFDC] flex flex-col justify-between shrink-0 h-screen overflow-y-auto select-none"
    >
      <div className="p-3.5 flex flex-col gap-3">
        {/* Brand Header: cecistudy ♡ */}
        <div className="flex items-center justify-between px-2 py-1">
          <div
            onClick={() => onNavChange('calendario')}
            className="flex items-center gap-2.5 cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-[#FFE9EE] border border-[#FFD3DD] flex items-center justify-center text-[#D85F79] font-bold text-sm shadow-2xs">
              C
            </div>
            <span className="font-display font-semibold text-lg tracking-tight text-[#40383A]">
              cecistudy <span className="text-[#D85F79]">♡</span>
            </span>
          </div>

          <button
            onClick={onOpenCommandPalette}
            className="p-1 text-[#ADA3A5] hover:text-[#40383A] hover:bg-[#F2EBE8] rounded-md transition-colors cursor-pointer"
            title="Abrir busca global (⌘K)"
          >
            <Search size={15} />
          </button>
        </div>

        {/* Quick Search trigger */}
        <div className="relative px-1">
          <div
            onClick={onOpenCommandPalette}
            className="flex items-center justify-between bg-white border border-[#E9DFDC] rounded-xl px-3 py-2 text-xs text-[#918689] hover:border-[#DCCFCA] hover:bg-[#FFF8F1] transition-all cursor-pointer shadow-2xs"
          >
            <div className="flex items-center gap-2">
              <Search size={14} className="text-[#ADA3A5]" />
              <span className="text-[#ADA3A5]">buscar ou comando...</span>
            </div>
            <kbd className="bg-[#FAF8F5] text-[#918689] text-[10px] px-1.5 py-0.5 rounded border border-[#E9DFDC] font-mono">
              ⌘K
            </kbd>
          </div>
        </div>

        {/* Workspace Switcher Pill */}
        <div className="relative px-1">
          <button
            id="workspace-switcher-btn"
            onClick={() => setWorkspaceMenuOpen(!workspaceMenuOpen)}
            className="w-full flex items-center justify-between bg-white hover:bg-[#FFF8F1] border border-[#E9DFDC] rounded-xl p-2 transition-all shadow-2xs group text-left cursor-pointer"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-[#FFE9EE] text-[#D85F79] font-bold text-xs flex items-center justify-center shrink-0">
                {activeWorkspace[0]}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-semibold text-[#40383A] truncate leading-tight">
                  {activeWorkspace.toLowerCase()}
                </span>
                <span className="text-[10px] text-[#918689] truncate leading-tight">
                  workspace ativo
                </span>
              </div>
            </div>
            <ChevronDown
              size={14}
              className={`text-[#ADA3A5] group-hover:text-[#6D6366] shrink-0 transition-transform ${
                workspaceMenuOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {/* Workspace Dropdown Menu */}
          {workspaceMenuOpen && (
            <div className="absolute top-full left-1 right-1 mt-1 z-30 bg-white border border-[#E9DFDC] rounded-xl shadow-lg p-1 flex flex-col gap-0.5 animate-in fade-in zoom-in-95 duration-100">
              {workspaces.map((ws) => (
                <button
                  key={ws.name}
                  onClick={() => {
                    setActiveWorkspace(ws.name);
                    setWorkspaceMenuOpen(false);
                    if (ws.name === 'Base de Conhecimento') {
                      onNavChange('conhecimento');
                    }
                  }}
                  className={`flex items-center justify-between p-2 rounded-lg text-xs text-left transition-colors cursor-pointer ${
                    activeWorkspace === ws.name
                      ? 'bg-[#FFF5F7] text-[#D85F79] font-semibold'
                      : 'hover:bg-[#FAF8F5] text-[#40383A]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: ws.color }}
                    />
                    <div>
                      <div className="font-semibold leading-tight">{ws.name}</div>
                      <div className="text-[10px] text-[#918689] leading-tight">
                        {ws.desc}
                      </div>
                    </div>
                  </div>
                  {activeWorkspace === ws.name && <Check size={13} />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Knowledge Secondary Links */}
        <div className="flex flex-col gap-0.5 px-1 pt-0.5">
          <button
            onClick={() => onNavChange('conhecimento')}
            className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors text-left cursor-pointer ${
              activeNav === 'conhecimento'
                ? 'bg-[#FFE9EE] text-[#D85F79] font-semibold'
                : 'text-[#D85F79] hover:bg-[#FFF5F7]'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Award size={15} className="text-[#D85F79]" />
              <span>conhecimento & horas</span>
            </div>
            <span className="text-[10px] font-mono font-bold bg-[#FFF0CC] text-[#96702B] px-1.5 py-0.2 rounded-full">
              68h AC
            </span>
          </button>
        </div>

        {/* Section Label: NAVEGAÇÃO */}
        <div className="px-2 pt-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#ADA3A5]">
            Navegação
          </span>
        </div>

        {/* Main Navigation List */}
        <nav className="flex flex-col gap-0.5 px-1">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.id;
            return (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => onNavChange(item.id)}
                className={`flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-xs font-medium transition-all text-left cursor-pointer ${
                  isActive
                    ? 'bg-[#FFF5F7] text-[#D85F79] font-semibold shadow-2xs'
                    : 'text-[#6D6366] hover:bg-[#F3EEE8] hover:text-[#40383A]'
                }`}
              >
                <Icon
                  size={16}
                  className={isActive ? 'text-[#D85F79]' : 'text-[#918689]'}
                />
                <span className="flex-1">{item.label}</span>
                {item.id === 'calendario' && suggestionsCount > 0 && (
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenSuggestions();
                    }}
                    className="flex items-center gap-1 bg-[#FFE9EE] text-[#D85F79] text-[10px] font-bold px-1.5 py-0.5 rounded-full hover:bg-[#FFD3DD] transition-colors"
                    title={`${suggestionsCount} sugestões`}
                  >
                    <Sparkles size={10} />
                    <span>{suggestionsCount}</span>
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Mini Calendar Widget */}
        <div className="px-1 pt-1">
          <div className="bg-white border border-[#E9DFDC] rounded-xl p-2.5 shadow-2xs">
            <div className="flex items-center justify-between text-xs font-bold text-[#40383A] mb-2">
              <span className="text-[11px] uppercase tracking-wider font-display">
                {monthNames[miniCalMonth]} {miniCalYear}
              </span>
              <div className="flex items-center gap-0.5 text-[#918689]">
                <button
                  onClick={() => {
                    if (miniCalMonth === 0) {
                      setMiniCalMonth(11);
                      setMiniCalYear(miniCalYear - 1);
                    } else {
                      setMiniCalMonth(miniCalMonth - 1);
                    }
                  }}
                  className="p-1 hover:bg-[#FAF8F5] rounded transition-colors cursor-pointer"
                  title="Mês anterior"
                >
                  <ChevronLeft size={13} />
                </button>
                <button
                  onClick={() => {
                    if (miniCalMonth === 11) {
                      setMiniCalMonth(0);
                      setMiniCalYear(miniCalYear + 1);
                    } else {
                      setMiniCalMonth(miniCalMonth + 1);
                    }
                  }}
                  className="p-1 hover:bg-[#FAF8F5] rounded transition-colors cursor-pointer"
                  title="Próximo mês"
                >
                  <ChevronRight size={13} />
                </button>
              </div>
            </div>

            {/* Weekdays header */}
            <div className="grid grid-cols-7 text-center text-[10px] font-semibold text-[#ADA3A5] mb-1">
              <span>D</span>
              <span>S</span>
              <span>T</span>
              <span>Q</span>
              <span>Q</span>
              <span>S</span>
              <span>S</span>
            </div>

            {/* Days grid */}
            <div className="grid grid-cols-7 gap-y-1 text-center text-[11px]">
              {Array.from({ length: firstDayOfWeek }).map((_, i) => (
                <div key={`empty-${i}`} className="py-0.5" />
              ))}
              {Array.from({ length: daysInMonth }).map((_, i) => {
                const dayNum = i + 1;
                const dateStr = `${miniCalYear}-${String(miniCalMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
                const isSelected = selectedDate === dateStr;
                const isCurToday = isToday(dateStr);

                return (
                  <button
                    key={dayNum}
                    onClick={() => {
                      onSelectDate(dateStr);
                      onNavChange('calendario');
                    }}
                    className={`py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#D85F79] text-white font-bold shadow-2xs'
                        : isCurToday
                        ? 'bg-[#FFE9EE] text-[#D85F79] font-bold ring-1 ring-[#FFD3DD]'
                        : 'text-[#6D6366] hover:bg-[#FAF8F5]'
                    }`}
                  >
                    {dayNum}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Camadas Filter Toggle */}
        <div className="px-1 pt-1">
          <div className="bg-white border border-[#E9DFDC] rounded-xl p-2.5 shadow-2xs">
            <button
              onClick={() => setShowLayers(!showLayers)}
              className="flex items-center justify-between w-full text-[11px] font-bold text-[#6D6366] uppercase tracking-wider mb-2 cursor-pointer"
            >
              <span className="flex items-center gap-1.5">
                <Layers size={13} className="text-[#918689]" />
                Camadas
              </span>
              <ChevronDown
                size={13}
                className={`text-[#ADA3A5] transition-transform ${
                  showLayers ? '' : '-rotate-90'
                }`}
              />
            </button>

            {showLayers && (
              <div className="flex flex-col gap-1.5 pt-1">
                {layers.map((layer) => (
                  <button
                    key={layer.id}
                    id={`layer-toggle-${layer.id}`}
                    onClick={() => onToggleLayer(layer.id)}
                    className="flex items-center justify-between w-full text-xs font-medium text-[#6D6366] hover:text-[#40383A] py-0.5 group cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: layer.colorHex }}
                      />
                      <span className="truncate">{layer.label}</span>
                    </div>
                    <div
                      className={`w-3.5 h-3.5 rounded flex items-center justify-center transition-colors ${
                        layer.visible
                          ? 'text-[#D85F79]'
                          : 'text-[#DCCFCA]'
                      }`}
                    >
                      {layer.visible && <Check size={12} strokeWidth={3} />}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Meta Semanal / Weekly Progress Widget */}
        <div className="px-1 pt-1">
          <div
            onClick={onOpenHoursKnowledge}
            className="bg-white hover:bg-[#FFF8F1] border border-[#E9DFDC] rounded-xl p-2.5 shadow-2xs flex flex-col gap-1.5 cursor-pointer transition-colors"
            title="Clique para ver o relatório completo de horas"
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-[#40383A] flex items-center gap-1">
                <Target size={12} className="text-[#5A9F76]" />
                Meta de Estudos
              </span>
              <span className="text-[11px] font-mono text-[#5A9F76] font-bold">
                {completedHoursThisWeek}h / {goalHoursThisWeek}h
              </span>
            </div>
            {/* Progress bar */}
            <div className="w-full bg-[#FAF8F5] rounded-full h-2 border border-[#E9DFDC] overflow-hidden">
              <div
                className="bg-[#5A9F76] h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] text-[#918689]">
              <span>{progressPercent}% completado</span>
              <span className="text-[#356647] font-semibold">Ver horas →</span>
            </div>
          </div>
        </div>

        {/* Ambient Focus Audio Sound Generator */}
        <div className="px-1 pt-1">
          <div className="bg-[#FFF5F7] border border-[#FFD3DD] rounded-xl p-2.5 shadow-2xs flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#D85F79]">
                <Volume2 size={13} />
                <span>som ambiente para foco</span>
              </div>
              <button
                onClick={toggleSound}
                className={`p-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
                  isAudioPlaying
                    ? 'bg-[#D85F79] text-white shadow-2xs'
                    : 'bg-white text-[#D85F79] border border-[#FFD3DD] hover:bg-[#FFE9EE]'
                }`}
                title={isAudioPlaying ? 'Pausar som ambiente' : 'Tocar som ambiente'}
              >
                {isAudioPlaying ? <Volume2 size={12} /> : <VolumeX size={12} />}
              </button>
            </div>

            <div className="grid grid-cols-3 gap-1">
              <button
                onClick={() => changeAudioMode('rain')}
                className={`py-1 px-1 text-[10px] rounded-lg font-medium transition-colors cursor-pointer text-center ${
                  audioMode === 'rain'
                    ? 'bg-[#D85F79] text-white'
                    : 'bg-white text-[#6D6366] hover:bg-[#FFE9EE]'
                }`}
              >
                🌧 Chuva
              </button>
              <button
                onClick={() => changeAudioMode('deep_focus')}
                className={`py-1 px-1 text-[10px] rounded-lg font-medium transition-colors cursor-pointer text-center ${
                  audioMode === 'deep_focus'
                    ? 'bg-[#D85F79] text-white'
                    : 'bg-white text-[#6D6366] hover:bg-[#FFE9EE]'
                }`}
              >
                🌊 Mar
              </button>
              <button
                onClick={() => changeAudioMode('cafe')}
                className={`py-1 px-1 text-[10px] rounded-lg font-medium transition-colors cursor-pointer text-center ${
                  audioMode === 'cafe'
                    ? 'bg-[#D85F79] text-white'
                    : 'bg-white text-[#6D6366] hover:bg-[#FFE9EE]'
                }`}
              >
                ☕ Café
              </button>
            </div>
          </div>
        </div>

        {/* User profile card */}
        <div className="px-1">
          <div
            onClick={() => onNavChange('conhecimento')}
            className="flex items-center justify-between bg-white hover:bg-[#FFF8F1] border border-[#E9DFDC] rounded-xl p-2.5 cursor-pointer transition-colors shadow-2xs"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-base">🌷</span>
              <div className="flex flex-col text-left">
                <span className="text-xs font-semibold text-[#40383A]">Ceci</span>
                <span className="text-[10px] text-[#918689]">semestre 6 de 10 • 34 créditos</span>
              </div>
            </div>
            <ChevronRight size={14} className="text-[#ADA3A5]" />
          </div>
        </div>

        {/* + Novo Registro Primary Button */}
        <div className="px-1">
          <button
            id="sidebar-new-register-btn"
            onClick={onOpenNewItemModal}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-[#40383A] hover:bg-[#2D2728] text-white rounded-xl text-xs font-semibold shadow-xs transition-all active:scale-98 cursor-pointer"
          >
            <Plus size={14} strokeWidth={2.5} />
            <span>+ novo registro</span>
            <kbd className="bg-white/15 text-[10px] px-1.5 py-0.5 rounded font-mono ml-auto">
              ⌘N
            </kbd>
          </button>
        </div>

        {/* Dica do Cecinho Widget */}
        <div className="px-1 pb-2">
          <div className="bg-[#FFFDF0] border border-[#FCE4A8] rounded-xl p-3 flex flex-col gap-2 shadow-2xs text-left">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#BD913C]">
              <Sparkles size={13} className="text-[#BD913C]" />
              <span>dica do cecinho</span>
            </div>
            <p className="text-[11px] text-[#6D6366] leading-relaxed">
              uma sessão leve de foco já conta. começa devagar, sem cobrança excessiva.
            </p>
            <button
              onClick={onStartFocusSession || onOpenSuggestions}
              className="mt-0.5 w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-[#FFE9EE] hover:bg-[#FFD3DD] text-[#D85F79] rounded-full text-xs font-bold transition-colors cursor-pointer"
            >
              <Sparkle size={12} />
              <span>✨ bora focar?</span>
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};
