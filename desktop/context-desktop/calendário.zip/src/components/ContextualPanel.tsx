import React, { useState } from 'react';
import {
  X,
  Plus,
  Check,
  Play,
  Calendar as CalendarIcon,
  MoreHorizontal,
  FileText,
  Compass,
  GraduationCap,
  ExternalLink,
  Trash2,
  CheckCircle2,
  Clock,
  AlertCircle,
  Pause,
  RotateCcw,
} from 'lucide-react';
import { CalendarItem, LayerConfig, Etapa } from '../types';
import { formatDatePtBR, formatDuration } from '../utils/dateUtils';

interface ContextualPanelProps {
  item: CalendarItem | null;
  layers: LayerConfig[];
  onClose: () => void;
  onUpdateItem: (updatedItem: CalendarItem) => void;
  onDeleteItem: (itemId: string) => void;
  onStartTimer: (item: CalendarItem) => void;
  onOpenReschedule: (item: CalendarItem) => void;
  activeTimerItemId?: string | null;
  activeTimerSeconds?: number;
  onStopTimer?: () => void;
}

export const ContextualPanel: React.FC<ContextualPanelProps> = ({
  item,
  layers,
  onClose,
  onUpdateItem,
  onDeleteItem,
  onStartTimer,
  onOpenReschedule,
  activeTimerItemId,
  activeTimerSeconds = 0,
  onStopTimer,
}) => {
  const [newEtapaTitle, setNewEtapaTitle] = useState('');
  const [isAddingEtapa, setIsAddingEtapa] = useState(false);
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  const [notesText, setNotesText] = useState(item?.notes || '');
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  if (!item) return null;

  const currentLayer = layers.find((l) => l.id === item.layer) || layers[0];
  const completedEtapas = item.etapas.filter((e) => e.completed).length;
  const totalEtapas = item.etapas.length;
  const progressPercent = totalEtapas > 0 ? (completedEtapas / totalEtapas) * 100 : 0;
  const isTimerRunning = activeTimerItemId === item.id;

  // Toggle etapa checkbox
  const handleToggleEtapa = (etapaId: string) => {
    const updatedEtapas = item.etapas.map((et) =>
      et.id === etapaId ? { ...et, completed: !et.completed } : et
    );
    onUpdateItem({
      ...item,
      etapas: updatedEtapas,
    });
  };

  // Add new etapa
  const handleAddEtapa = () => {
    if (!newEtapaTitle.trim()) return;
    const newEtapa: Etapa = {
      id: `et-${Date.now()}`,
      title: newEtapaTitle.trim(),
      completed: false,
    };
    onUpdateItem({
      ...item,
      etapas: [...item.etapas, newEtapa],
    });
    setNewEtapaTitle('');
    setIsAddingEtapa(false);
  };

  // Save notes
  const handleSaveNotes = () => {
    onUpdateItem({
      ...item,
      notes: notesText,
    });
    setIsEditingNotes(false);
  };

  // Change status
  const handleToggleStatus = (status: CalendarItem['status']) => {
    onUpdateItem({
      ...item,
      status,
    });
  };

  const getCommitmentStyle = (commitment: CalendarItem['commitment']) => {
    switch (commitment) {
      case 'obrigatorio':
        return 'bg-[#F3F9FC] text-[#396D82] border-[#CEE7F0]';
      case 'importante':
        return 'bg-[#FFF5F7] text-[#B94862] border-[#FFD3DD]';
      case 'recomendado':
        return 'bg-[#F2FAF5] text-[#356647] border-[#C2E8D0]';
      case 'opcional':
        return 'bg-[#FAF8F5] text-[#6D6366] border-[#E9DFDC]';
      default:
        return 'bg-[#FAF8F5] text-[#6D6366] border-[#E9DFDC]';
    }
  };

  const getStatusStyle = (status: CalendarItem['status']) => {
    switch (status) {
      case 'concluido':
        return 'bg-[#F2FAF5] text-[#356647] border-[#C2E8D0]';
      case 'em_andamento':
        return 'bg-[#FFF5F7] text-[#D85F79] border-[#FFD3DD]';
      case 'planejado':
        return 'bg-[#FAF8F5] text-[#6D6366] border-[#E9DFDC]';
      case 'adiado':
        return 'bg-[#FFF9ED] text-[#96702B] border-[#FCE4A8]';
      case 'cancelado':
        return 'bg-[#FFF5F4] text-[#A8514B] border-[#FACCC8] line-through';
      case 'dispensado':
        return 'bg-[#FAF8F5] text-[#ADA3A5] border-[#E9DFDC] line-through';
      case 'nao_realizado':
        return 'bg-[#FFF5F4] text-[#A8514B] border-[#FACCC8]';
      default:
        return 'bg-[#FAF8F5] text-[#6D6366] border-[#E9DFDC]';
    }
  };

  const formatTimerDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  return (
    <aside
      id="contextual-panel"
      className="w-80 lg:w-96 bg-white border-l border-[#E9DFDC] flex flex-col justify-between shrink-0 h-screen overflow-y-auto z-20 shadow-md select-none"
    >
      {/* Panel Body */}
      <div className="p-6 flex flex-col gap-5">
        {/* Header Tag & Close Button */}
        <div className="flex items-center justify-between">
          <span
            className="text-[10px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full"
            style={{
              backgroundColor: currentLayer.badgeBg,
              color: currentLayer.badgeText,
            }}
          >
            {currentLayer.label} • {item.type.toUpperCase()}
          </span>
          <button
            id="btn-close-contextual-panel"
            onClick={onClose}
            className="p-1 text-[#ADA3A5] hover:text-[#40383A] hover:bg-[#FAF8F5] rounded-md transition-colors"
            title="Fechar painel"
          >
            <X size={18} />
          </button>
        </div>

        {/* Title */}
        <div>
          <h2 className="text-xl font-bold font-display text-[#40383A] tracking-tight leading-snug">
            {item.title}
          </h2>

          {/* Badges: Nível de Compromisso & Status */}
          <div className="flex items-center gap-2 mt-2">
            {/* Commitment Pill */}
            <span
              className={`inline-flex items-center text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${getCommitmentStyle(
                item.commitment
              )} capitalize`}
            >
              {item.commitment}
            </span>

            {/* Status Pill */}
            <span
              className={`inline-flex items-center text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${getStatusStyle(
                item.status
              )} capitalize`}
            >
              {item.status.replace('_', ' ')}
            </span>
          </div>
        </div>

        {/* Warning notification if any */}
        {item.hasWarning && (
          <div className="p-3 bg-[#FFF9ED] border border-[#FCE4A8] rounded-xl flex items-start gap-2.5 text-xs text-[#765824]">
            <AlertCircle size={15} className="text-[#BD913C] shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Aviso importante: </span>
              {item.warningText || 'Compromisso com data limite e peso relevante.'}
            </div>
          </div>
        )}

        {/* Planejado vs Realizado Comparison Section */}
        <div className="grid grid-cols-2 gap-3 p-3 bg-[#FAF8F5] border border-[#E9DFDC] rounded-xl text-xs">
          <div>
            <span className="text-[10px] font-bold text-[#918689] uppercase tracking-wider block mb-1">
              Planejado
            </span>
            <span className="font-semibold text-[#40383A] block text-xs">
              {formatDatePtBR(item.date)}
            </span>
            <span className="text-[#6D6366] text-[11px] block mt-0.5">
              {item.startTime} — {item.endTime} •{' '}
              {formatDuration(item.plannedDurationMinutes || 60)}
            </span>
          </div>

          <div className="border-l border-[#E9DFDC] pl-3">
            <span className="text-[10px] font-bold text-[#918689] uppercase tracking-wider block mb-1">
              Realizado
            </span>
            {item.actualExecution ? (
              <>
                <span className="font-semibold text-[#40383A] block text-xs">
                  {formatDatePtBR(item.actualExecution.date)}
                </span>
                <span className="text-[#6D6366] text-[11px] block mt-0.5">
                  {item.actualExecution.startTime} — {item.actualExecution.endTime} •{' '}
                  {formatDuration(item.actualExecution.durationMinutes)}
                </span>
              </>
            ) : isTimerRunning ? (
              <>
                <span className="font-semibold text-[#D85F79] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D85F79] animate-ping" />
                  Em execução
                </span>
                <span className="text-[#B94862] font-mono text-xs block mt-0.5">
                  {formatTimerDuration(activeTimerSeconds)}
                </span>
              </>
            ) : (
              <span className="text-[#ADA3A5] italic text-[11px] block mt-1">
                Ainda não registrado
              </span>
            )}
          </div>
        </div>

        {/* Progresso das etapas */}
        <div>
          <div className="flex items-center justify-between text-xs font-semibold text-[#6D6366] mb-1.5">
            <span className="text-[#918689] text-[11px]">Progresso das etapas</span>
            <span className="text-[#40383A] text-xs">
              {completedEtapas} / {totalEtapas}
            </span>
          </div>
          <div className="w-full h-1.5 bg-[#FAF8F5] border border-[#E9DFDC] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${progressPercent}%`,
                backgroundColor: currentLayer.colorHex,
              }}
            />
          </div>
        </div>

        {/* Etapas Checklist Section */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-[11px] font-bold text-[#40383A] uppercase tracking-wider">
              Etapas
            </h3>
            <button
              id="btn-add-etapa"
              onClick={() => setIsAddingEtapa(!isAddingEtapa)}
              className="text-xs font-semibold text-[#D85F79] hover:text-[#B94862] flex items-center gap-1"
            >
              <Plus size={13} />
              <span>Nova</span>
            </button>
          </div>

          {/* New Etapa input form */}
          {isAddingEtapa && (
            <div className="flex items-center gap-2 mb-2">
              <input
                type="text"
                placeholder="Nome da subtarefa..."
                value={newEtapaTitle}
                onChange={(e) => setNewEtapaTitle(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddEtapa()}
                className="flex-1 px-2.5 py-1 text-xs border border-[#FFD3DD] rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#FFB8C7]"
                autoFocus
              />
              <button
                onClick={handleAddEtapa}
                className="px-2.5 py-1 bg-[#D85F79] text-white rounded-lg text-xs font-semibold"
              >
                Adicionar
              </button>
            </div>
          )}

          {/* Etapas List */}
          <div className="flex flex-col gap-1.5">
            {item.etapas.map((etapa) => (
              <label
                key={etapa.id}
                className="flex items-start gap-2.5 p-1.5 hover:bg-[#FAF8F5] rounded-xl cursor-pointer transition-colors group"
              >
                <div
                  onClick={() => handleToggleEtapa(etapa.id)}
                  className={`w-4 h-4 rounded-md mt-0.5 flex items-center justify-center border transition-all ${
                    etapa.completed
                      ? 'bg-[#D85F79] border-[#D85F79] text-white'
                      : 'border-[#DCCFCA] hover:border-[#D85F79] bg-white'
                  }`}
                  style={{
                    backgroundColor: etapa.completed ? currentLayer.colorHex : 'white',
                    borderColor: etapa.completed ? currentLayer.colorHex : undefined,
                  }}
                >
                  {etapa.completed && <Check size={11} strokeWidth={3} />}
                </div>
                <span
                  className={`text-xs flex-1 transition-colors ${
                    etapa.completed
                      ? 'text-[#ADA3A5] line-through'
                      : 'text-[#40383A] font-medium'
                  }`}
                >
                  {etapa.title}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    const updated = item.etapas.filter((e) => e.id !== etapa.id);
                    onUpdateItem({ ...item, etapas: updated });
                  }}
                  className="text-[#DCCFCA] hover:text-[#D97A72] opacity-0 group-hover:opacity-100 transition-opacity p-0.5"
                  title="Remover etapa"
                >
                  <Trash2 size={12} />
                </button>
              </label>
            ))}
            {item.etapas.length === 0 && (
              <span className="text-xs text-[#ADA3A5] italic py-1">
                Nenhuma etapa cadastrada.
              </span>
            )}
          </div>
        </div>

        {/* Vínculos Section */}
        <div>
          <h3 className="text-[11px] font-bold text-[#40383A] uppercase tracking-wider mb-2">
            Vínculos
          </h3>
          <div className="flex flex-col gap-1.5">
            {item.links.map((link) => (
              <div
                key={link.id}
                className="flex items-center gap-2 px-2.5 py-1.5 bg-[#F3F9FC] hover:bg-[#E6F2F7] border border-[#CEE7F0] rounded-xl text-xs font-medium text-[#284955] transition-colors cursor-pointer group"
              >
                {link.type === 'tcc' ? (
                  <FileText size={14} className="text-[#D85F79] shrink-0" />
                ) : link.type === 'conhecimento' ? (
                  <Compass size={14} className="text-[#4A879F] shrink-0" />
                ) : (
                  <GraduationCap size={14} className="text-[#4A879F] shrink-0" />
                )}
                <span className="flex-1 truncate">{link.title}</span>
                <ExternalLink
                  size={12}
                  className="text-[#83BCD0] group-hover:text-[#4A879F] shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                />
              </div>
            ))}
            {item.links.length === 0 && (
              <span className="text-xs text-[#ADA3A5] italic py-1">
                Nenhum vínculo vinculado a módulos externos.
              </span>
            )}
          </div>
        </div>

        {/* Observações Section */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <h3 className="text-[11px] font-bold text-[#40383A] uppercase tracking-wider">
              Observações
            </h3>
            {!isEditingNotes ? (
              <button
                onClick={() => setIsEditingNotes(true)}
                className="text-[11px] font-semibold text-[#D85F79] hover:text-[#B94862]"
              >
                Editar
              </button>
            ) : (
              <button
                onClick={handleSaveNotes}
                className="text-[11px] font-semibold text-[#5A9F76] hover:text-[#43805B]"
              >
                Salvar
              </button>
            )}
          </div>

          {isEditingNotes ? (
            <textarea
              value={notesText}
              onChange={(e) => setNotesText(e.target.value)}
              className="w-full text-xs p-2.5 border border-[#E9DFDC] rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#FFD3DD] text-[#40383A] leading-relaxed"
              rows={3}
            />
          ) : (
            <p className="text-xs text-[#6D6366] bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E9DFDC] leading-relaxed">
              {item.notes || 'Nenhuma observação informada.'}
            </p>
          )}
        </div>
      </div>

      {/* Panel Footer Actions */}
      <div className="p-4 border-t border-[#E9DFDC] bg-[#FAF8F5] flex flex-col gap-2.5">
        {/* Primary Action: Iniciar / Parar Timer */}
        {isTimerRunning ? (
          <button
            id="btn-stop-timer"
            onClick={onStopTimer}
            className="w-full py-2.5 bg-[#D97A72] hover:bg-[#C5665E] text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2 shadow-xs transition-all active:scale-98"
          >
            <Pause size={15} />
            <span>Parar timer ({formatTimerDuration(activeTimerSeconds)})</span>
          </button>
        ) : (
          <button
            id="btn-start-timer"
            onClick={() => onStartTimer(item)}
            className="w-full py-2.5 bg-[#D85F79] hover:bg-[#B94862] text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2 shadow-xs transition-all active:scale-98 cursor-pointer"
          >
            <Play size={14} fill="currentColor" />
            <span>Iniciar timer</span>
          </button>
        )}

        {/* Secondary Actions: Reagendar & Mais */}
        <div className="grid grid-cols-2 gap-2 relative">
          <button
            id="btn-reschedule"
            onClick={() => onOpenReschedule(item)}
            className="py-2 border border-[#E9DFDC] bg-white hover:bg-[#FFF8F1] rounded-xl text-xs font-semibold text-[#40383A] flex items-center justify-center gap-1.5 shadow-2xs transition-colors"
          >
            <CalendarIcon size={14} className="text-[#918689]" />
            <span>Reagendar</span>
          </button>

          <div className="relative">
            <button
              id="btn-more-options"
              onClick={() => setShowMoreMenu(!showMoreMenu)}
              className="w-full py-2 border border-[#E9DFDC] bg-white hover:bg-[#FFF8F1] rounded-xl text-xs font-semibold text-[#40383A] flex items-center justify-center gap-1.5 shadow-2xs transition-colors"
            >
              <MoreHorizontal size={14} className="text-[#918689]" />
              <span>Mais</span>
            </button>

            {/* More Options Dropdown */}
            {showMoreMenu && (
              <div className="absolute right-0 bottom-full mb-2 w-48 bg-white border border-[#E9DFDC] rounded-xl shadow-lg py-1 z-30 flex flex-col text-xs">
                <button
                  onClick={() => {
                    handleToggleStatus(item.status === 'concluido' ? 'planejado' : 'concluido');
                    setShowMoreMenu(false);
                  }}
                  className="px-3 py-2 text-left hover:bg-[#FAF8F5] font-medium text-[#40383A] flex items-center gap-2"
                >
                  <CheckCircle2 size={14} className="text-[#5A9F76]" />
                  <span>
                    {item.status === 'concluido' ? 'Marcar como Pendente' : 'Marcar como Concluído'}
                  </span>
                </button>

                <button
                  onClick={() => {
                    handleToggleStatus('cancelado');
                    setShowMoreMenu(false);
                  }}
                  className="px-3 py-2 text-left hover:bg-[#FFF5F4] font-medium text-[#D97A72] flex items-center gap-2"
                >
                  <AlertCircle size={14} />
                  <span>Cancelar Ocorrência</span>
                </button>

                <button
                  onClick={() => {
                    handleToggleStatus('dispensado');
                    setShowMoreMenu(false);
                  }}
                  className="px-3 py-2 text-left hover:bg-[#FAF8F5] font-medium text-[#918689] flex items-center gap-2"
                >
                  <RotateCcw size={14} />
                  <span>Dispensar Atividade</span>
                </button>

                <div className="h-px bg-[#E9DFDC] my-1" />

                <button
                  onClick={() => {
                    onDeleteItem(item.id);
                    setShowMoreMenu(false);
                  }}
                  className="px-3 py-2 text-left hover:bg-[#FFF5F4] font-medium text-[#C5665E] flex items-center gap-2"
                >
                  <Trash2 size={14} />
                  <span>Excluir do Calendário</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
};
