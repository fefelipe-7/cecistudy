import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Search,
  Plus,
  RefreshCw,
  Sparkles,
  Target,
  Calendar as CalendarIcon,
  ChevronDown,
  Star,
  Users,
  CheckSquare,
  UserPlus,
  Share2,
  Filter,
  Check,
  MoreHorizontal,
} from 'lucide-react';
import { ViewMode, LayerConfig } from '../types';
import {
  formatHeaderTitle,
  getCurrentTimeHMS,
  getCurrentDateISO,
  isToday,
} from '../utils/dateUtils';

export type CategoryFilterType = 'all' | 'events' | 'meetings' | 'tasks';

interface TopHeaderProps {
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  selectedDate: string;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
  onSelectSpecificDate: (date: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  categoryFilter?: CategoryFilterType;
  onCategoryFilterChange?: (filter: CategoryFilterType) => void;
  itemsCount?: {
    all: number;
    events: number;
    meetings: number;
    tasks: number;
  };
  onOpenNewItemModal: () => void;
  onOpenSyncModal: () => void;
  onOpenSuggestionsModal: () => void;
  onOpenHoursModal: () => void;
  isSyncing: boolean;
  suggestionsCount: number;
  completedHoursThisWeek?: number;
  goalHoursThisWeek?: number;
  layers?: LayerConfig[];
  onToggleLayer?: (layerId: string) => void;
  onInviteClick?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  viewMode,
  onViewModeChange,
  selectedDate,
  onPrev,
  onNext,
  onToday,
  onSelectSpecificDate,
  searchQuery,
  onSearchChange,
  categoryFilter = 'all',
  onCategoryFilterChange,
  itemsCount = { all: 12, events: 4, meetings: 2, tasks: 6 },
  onOpenNewItemModal,
  onOpenSyncModal,
  onOpenSuggestionsModal,
  onOpenHoursModal,
  isSyncing,
  suggestionsCount,
  completedHoursThisWeek = 14.5,
  goalHoursThisWeek = 20,
  layers = [],
  onToggleLayer,
  onInviteClick,
}) => {
  const [liveTime, setLiveTime] = useState(getCurrentTimeHMS());
  const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  const datePickerRef = useRef<HTMLDivElement>(null);
  const filterDropdownRef = useRef<HTMLDivElement>(null);
  const moreMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setLiveTime(getCurrentTimeHMS());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Close dropdowns when clicked outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (datePickerRef.current && !datePickerRef.current.contains(event.target as Node)) {
        setIsDatePickerOpen(false);
      }
      if (filterDropdownRef.current && !filterDropdownRef.current.contains(event.target as Node)) {
        setIsFilterDropdownOpen(false);
      }
      if (moreMenuRef.current && !moreMenuRef.current.contains(event.target as Node)) {
        setIsMoreMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const headerInfo = formatHeaderTitle(viewMode, selectedDate);
  const isSelectedToday = isToday(selectedDate);
  const completedBlocks = Math.round(completedHoursThisWeek * 2);

  // Month & Year extraction
  const [selYear, selMonth] = selectedDate.split('-');
  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];
  const monthLabel = monthNames[parseInt(selMonth, 10) - 1] || 'Janeiro';
  const monthYearDisplay = `${monthLabel} ${selYear}`;

  const tabs: { id: CategoryFilterType; label: string; icon: React.ReactNode; count: number }[] = [
    {
      id: 'all',
      label: 'Todos',
      icon: <CalendarIcon size={13} />,
      count: itemsCount.all,
    },
    {
      id: 'events',
      label: 'Aulas & Provas',
      icon: <Star size={13} />,
      count: itemsCount.events,
    },
    {
      id: 'meetings',
      label: 'Orientações',
      icon: <Users size={13} />,
      count: itemsCount.meetings,
    },
    {
      id: 'tasks',
      label: 'TCC & Entregas',
      icon: <CheckSquare size={13} />,
      count: itemsCount.tasks,
    },
  ];

  return (
    <header
      id="compact-dashboard-header"
      className="bg-[#FFFCF8] border-b border-[#E9DFDC] flex flex-col shrink-0 select-none z-20 shadow-2xs"
    >
      {/* ─────────────────────────────────────────────────────────────
          ROW 1: TITLE, CATEGORY TABS & MAIN ACTION SUITE (COMPACT)
      ───────────────────────────────────────────────────────────── */}
      <div className="h-12 px-4 lg:px-6 flex items-center justify-between gap-2.5 border-b border-[#F2EBE8] bg-[#FFFCF8]">
        {/* Left: App/View Identity & Collaborators */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <h1 className="text-base font-bold font-display text-[#40383A] tracking-tight">
              Calendário
            </h1>
            <span className="hidden xl:inline text-xs text-[#D8CFCC]">/</span>
            <span className="hidden xl:inline text-[11px] font-medium text-[#918689]">
              cecistudy
            </span>
          </div>

          {/* Collaborators Avatar Stack */}
          <div className="hidden lg:flex items-center gap-1.5 pl-1.5 border-l border-[#E9DFDC]">
            <div className="flex items-center -space-x-1.5">
              <div
                className="w-6 h-6 rounded-full bg-[#FFE9EE] border-2 border-white flex items-center justify-center text-[9px] font-bold text-[#D85F79] shadow-2xs"
                title="Ana Luísa (Colega TCC)"
              >
                AL
              </div>
              <div
                className="w-6 h-6 rounded-full bg-[#E6F2F7] border-2 border-white flex items-center justify-center text-[9px] font-bold text-[#4A879F] shadow-2xs"
                title="Ceci AI (Mentora Pedagógica)"
              >
                <Sparkles size={11} />
              </div>
              <div
                className="w-6 h-6 rounded-full bg-[#FAF8F5] border-2 border-white flex items-center justify-center text-[9px] font-bold text-[#6D6366] shadow-2xs"
                title="Prof. Daniel T. (Orientador)"
              >
                DT
              </div>
            </div>

            <button
              onClick={onInviteClick || onOpenSyncModal}
              className="p-1 hover:bg-[#FAF8F5] text-[#918689] hover:text-[#40383A] rounded-lg transition-colors cursor-pointer"
              title="Conectar colegas ou orientador"
            >
              <UserPlus size={13} />
            </button>
          </div>
        </div>

        {/* Center: Category Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
          {tabs.map((tab) => {
            const isActive = categoryFilter === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-filter-${tab.id}`}
                onClick={() => onCategoryFilterChange && onCategoryFilterChange(tab.id)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  isActive
                    ? 'bg-[#FAF8F5] text-[#40383A] shadow-2xs border border-[#E9DFDC] font-bold'
                    : 'text-[#918689] hover:text-[#40383A] hover:bg-[#FAF8F5]/60'
                }`}
              >
                <span className={isActive ? 'text-[#D85F79]' : 'text-[#ADA3A5]'}>
                  {tab.icon}
                </span>
                <span className="hidden sm:inline">{tab.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                    isActive
                      ? 'bg-[#FFE9EE] text-[#D85F79]'
                      : 'bg-[#F2EBE8] text-[#918689]'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right: Integrated Actions (Search, Filters, Sync, Ceci, Metas, + Novo) */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Search Input */}
          <div className="relative">
            <Search
              size={12}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#ADA3A5] pointer-events-none"
            />
            <input
              id="calendar-search-input"
              type="text"
              placeholder="Buscar..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-24 sm:w-36 focus:w-48 transition-all pl-7 pr-7 py-1 text-xs bg-white border border-[#E9DFDC] rounded-xl focus:outline-hidden focus:border-[#D85F79] text-[#40383A] placeholder:text-[#ADA3A5] shadow-2xs"
            />
            <kbd className="hidden sm:inline absolute right-2 top-1/2 -translate-y-1/2 text-[9px] text-[#ADA3A5] font-mono pointer-events-none">
              ⌘K
            </kbd>
          </div>

          {/* Filter Layers Button */}
          <div className="relative" ref={filterDropdownRef}>
            <button
              id="btn-header-filter"
              onClick={() => setIsFilterDropdownOpen(!isFilterDropdownOpen)}
              className={`p-1.5 sm:px-2 sm:py-1 rounded-xl text-xs font-semibold border flex items-center gap-1 transition-all cursor-pointer shadow-2xs ${
                isFilterDropdownOpen
                  ? 'bg-[#FFF5F7] border-[#FFD3DD] text-[#D85F79]'
                  : 'bg-white hover:bg-[#FAF8F5] border-[#E9DFDC] text-[#6D6366]'
              }`}
              title="Filtrar camadas de estudo"
            >
              <Filter size={13} />
              <span className="hidden md:inline text-[11px]">Camadas</span>
            </button>

            {isFilterDropdownOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-56 bg-white border border-[#E9DFDC] rounded-2xl shadow-xl p-2.5 z-50 animate-in fade-in zoom-in-95">
                <div className="flex items-center justify-between pb-1.5 border-b border-[#F2EBE8] mb-1.5">
                  <span className="text-[10px] font-bold text-[#40383A] uppercase tracking-wider">
                    Camadas Visíveis
                  </span>
                  <span className="text-[10px] text-[#918689] font-mono">
                    {layers.filter((l) => l.visible).length}/{layers.length}
                  </span>
                </div>

                <div className="flex flex-col gap-1">
                  {layers.map((layer) => (
                    <button
                      key={layer.id}
                      onClick={() => onToggleLayer && onToggleLayer(layer.id)}
                      className="flex items-center justify-between p-1.5 rounded-xl hover:bg-[#FAF8F5] text-xs text-left cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: layer.color }}
                        />
                        <span className="font-medium text-[#40383A] truncate">{layer.name}</span>
                      </div>
                      {layer.visible && <Check size={13} className="text-[#5A9F76] shrink-0" />}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Google Sync */}
          <button
            onClick={onOpenSyncModal}
            className="p-1.5 rounded-xl border border-[#E9DFDC] bg-white hover:bg-[#FAF8F5] text-[#6D6366] hover:text-[#40383A] transition-all cursor-pointer shadow-2xs"
            title="Sincronizar com Google Agenda"
          >
            {isSyncing ? (
              <RefreshCw size={13} className="text-[#D85F79] animate-spin" />
            ) : (
              <Share2 size={13} />
            )}
          </button>

          {/* Ceci AI Suggestions Pill */}
          {suggestionsCount > 0 && (
            <button
              onClick={onOpenSuggestionsModal}
              className="hidden sm:flex items-center gap-1 px-2 py-1 bg-[#FFFDF0] hover:bg-[#FFF8E9] border border-[#FCE4A8] text-[#BD913C] rounded-xl text-[11px] font-bold transition-all cursor-pointer shadow-2xs"
              title="Sugestões pedagógicas da Ceci"
            >
              <Sparkles size={12} />
              <span>{suggestionsCount}</span>
            </button>
          )}

          {/* Banco de Horas Metric Pill */}
          <button
            id="btn-hours-analytics"
            onClick={onOpenHoursModal}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1 bg-[#F2FAF5] hover:bg-[#DDF3E5] border border-[#C2E8D0] rounded-xl text-xs font-semibold text-[#356647] shadow-2xs transition-all cursor-pointer"
            title="Ver análise completa do banco de horas acadêmicas"
          >
            <Target size={12} className="text-[#5A9F76]" />
            <span className="font-mono">{completedHoursThisWeek}h/{goalHoursThisWeek}h</span>
          </button>

          {/* + Novo Action Button */}
          <button
            id="btn-header-new-item"
            onClick={onOpenNewItemModal}
            className="flex items-center gap-1 px-3 py-1 bg-[#40383A] hover:bg-[#252021] text-white rounded-xl text-xs font-bold transition-all shadow-xs active:scale-95 cursor-pointer shrink-0"
          >
            <Plus size={13} strokeWidth={2.5} />
            <span>+ Novo</span>
          </button>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          ROW 2: CALENDAR TIMELINE NAVIGATION & VIEW SELECTOR (COMPACT)
      ───────────────────────────────────────────────────────────── */}
      <div className="h-10 px-4 lg:px-6 flex items-center justify-between gap-3 bg-[#FAF8F5]/50">
        {/* Left: Month Year Picker, Today, Prev/Next, Date Range Title */}
        <div className="flex items-center gap-2">
          {/* Month & Year Title Dropdown */}
          <div className="relative" ref={datePickerRef}>
            <button
              onClick={() => setIsDatePickerOpen(!isDatePickerOpen)}
              className="flex items-center gap-1 text-sm font-bold font-display text-[#40383A] hover:text-[#D85F79] transition-colors cursor-pointer group"
            >
              <span>{monthYearDisplay}</span>
              <ChevronDown size={13} className="text-[#ADA3A5] group-hover:text-[#D85F79]" />
            </button>

            {/* Quick Date Jump Popover */}
            {isDatePickerOpen && (
              <div className="absolute top-full left-0 mt-1 z-50 bg-white border border-[#E9DFDC] rounded-2xl shadow-xl p-2.5 flex flex-col gap-1.5 min-w-[220px] animate-in fade-in zoom-in-95 duration-100">
                <div className="text-[9px] font-bold uppercase tracking-wider text-[#918689] px-1">
                  Navegar rapidamente:
                </div>
                <button
                  onClick={() => {
                    onToday();
                    setIsDatePickerOpen(false);
                  }}
                  className="flex items-center justify-between p-1.5 rounded-xl text-xs font-semibold hover:bg-[#FFF5F7] text-[#D85F79] transition-colors text-left cursor-pointer"
                >
                  <span>📅 Ir para Hoje</span>
                </button>
                <button
                  onClick={() => {
                    onSelectSpecificDate('2025-01-15');
                    setIsDatePickerOpen(false);
                  }}
                  className="flex items-center justify-between p-1.5 rounded-xl text-xs font-semibold hover:bg-[#FAF8F5] text-[#40383A] transition-colors text-left cursor-pointer"
                >
                  <span>🎓 Semana Letiva Demo (Jan 2025)</span>
                </button>
                <div className="pt-1 border-t border-[#F2EBE8] flex flex-col gap-1">
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      if (e.target.value) {
                        onSelectSpecificDate(e.target.value);
                        setIsDatePickerOpen(false);
                      }
                    }}
                    className="w-full px-2 py-1 text-xs bg-[#FAF8F5] border border-[#E9DFDC] rounded-xl text-[#40383A] focus:outline-hidden focus:border-[#D85F79]"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Today Button */}
          <button
            id="btn-today"
            onClick={onToday}
            className={`px-2.5 py-0.5 text-xs font-semibold rounded-xl transition-all cursor-pointer shadow-2xs ${
              isSelectedToday
                ? 'bg-[#FFE9EE] border border-[#FFD3DD] text-[#D85F79] font-bold'
                : 'bg-white hover:bg-[#FAF8F5] border border-[#E9DFDC] text-[#6D6366]'
            }`}
            title="Ir para hoje"
          >
            Hoje
          </button>

          {/* Prev / Next Arrows */}
          <div className="flex items-center gap-0.5 border-l border-[#E9DFDC] pl-1.5 text-[#6D6366]">
            <button
              id="btn-prev"
              onClick={onPrev}
              className="p-1 hover:bg-white rounded-lg transition-colors text-[#918689] hover:text-[#40383A] cursor-pointer"
              title="Período anterior"
            >
              <ChevronLeft size={15} />
            </button>
            <button
              id="btn-next"
              onClick={onNext}
              className="p-1 hover:bg-white rounded-lg transition-colors text-[#918689] hover:text-[#40383A] cursor-pointer"
              title="Próximo período"
            >
              <ChevronRight size={15} />
            </button>
          </div>

          {/* Formatted Period Subtitle */}
          <span className="hidden sm:inline text-xs text-[#918689] font-medium border-l border-[#E9DFDC] pl-2 truncate max-w-[280px]">
            {headerInfo.title} · {headerInfo.subtitle}
          </span>
        </div>

        {/* Right: View Switcher (Dia / Semana / Mês / Agenda) & System Clock */}
        <div className="flex items-center gap-2">
          {/* Real-time System Clock */}
          <div
            className="hidden xl:flex items-center gap-1 text-[11px] font-mono text-[#918689] pr-1"
            title="Horário do sistema"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#5A9F76] animate-pulse" />
            <span>{liveTime}</span>
          </div>

          {/* View Mode Segmented Control */}
          <div className="flex items-center bg-white p-0.5 rounded-xl border border-[#E9DFDC] shadow-2xs">
            {(['dia', 'semana', 'mes', 'agenda'] as ViewMode[]).map((mode) => {
              const isActive = viewMode === mode;
              const labels: Record<ViewMode, string> = {
                dia: 'Dia',
                semana: 'Semana',
                mes: 'Mês',
                agenda: 'Agenda',
              };
              return (
                <button
                  key={mode}
                  id={`view-mode-tab-${mode}`}
                  onClick={() => onViewModeChange(mode)}
                  className={`px-2.5 py-0.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#FAF8F5] text-[#40383A] shadow-2xs font-bold border border-[#E9DFDC]'
                      : 'text-[#918689] hover:text-[#40383A] hover:bg-[#FAF8F5]/60'
                  }`}
                >
                  {labels[mode]}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
};
