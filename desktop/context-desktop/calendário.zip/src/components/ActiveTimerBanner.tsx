import React, { useState } from 'react';
import { Play, Pause, Square, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { CalendarItem } from '../types';
import { ambientSound } from '../utils/ambientAudio';

interface ActiveTimerBannerProps {
  activeItem: CalendarItem | null;
  seconds: number;
  isRunning: boolean;
  onTogglePlay: () => void;
  onStopSession: () => void;
}

export const ActiveTimerBanner: React.FC<ActiveTimerBannerProps> = ({
  activeItem,
  seconds,
  isRunning,
  onTogglePlay,
  onStopSession,
}) => {
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);

  if (!activeItem) return null;

  const formatTimer = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;

    if (hours > 0) {
      return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(
        2,
        '0'
      )}:${String(secs).padStart(2, '0')}`;
    }
    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const toggleSound = () => {
    if (isAudioPlaying) {
      ambientSound.stop();
      setIsAudioPlaying(false);
    } else {
      ambientSound.play('rain', 0.2);
      setIsAudioPlaying(true);
    }
  };

  return (
    <div
      id="active-timer-banner"
      className="fixed bottom-6 right-6 lg:right-96 z-40 bg-[#40383A] text-white px-4 py-3 rounded-2xl shadow-xl border border-[#6D6366] flex items-center gap-4 animate-in fade-in slide-in-from-bottom-4 duration-200 select-none"
    >
      <div className="flex items-center gap-3">
        <div className="relative flex items-center justify-center">
          <div
            className={`w-3.5 h-3.5 rounded-full ${
              isRunning ? 'bg-[#5A9F76] animate-ping opacity-75' : 'bg-[#BD913C]'
            }`}
          />
          <div
            className={`w-3.5 h-3.5 rounded-full absolute ${
              isRunning ? 'bg-[#5A9F76]' : 'bg-[#BD913C]'
            }`}
          />
        </div>

        <div className="flex flex-col">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#DCCFCA] flex items-center gap-1">
            <span>Sessão de Foco</span>
            {isRunning && <span className="text-[#A8D8B9] font-mono text-[9px]">● LIVE</span>}
          </span>
          <span className="text-xs font-bold text-white max-w-[160px] truncate">
            {activeItem.title}
          </span>
        </div>
      </div>

      {/* Stopwatch Counter */}
      <div className="font-mono text-base font-bold text-[#A8D8B9] bg-[#2E2829] px-3 py-1 rounded-xl border border-[#564C4E] shadow-inner">
        {formatTimer(seconds)}
      </div>

      {/* Ambient Sound Toggle in timer */}
      <button
        onClick={toggleSound}
        className={`p-2 rounded-xl transition-colors cursor-pointer ${
          isAudioPlaying
            ? 'bg-[#D85F79] text-white'
            : 'bg-[#564C4E] hover:bg-[#6D6366] text-[#DCCFCA]'
        }`}
        title={isAudioPlaying ? 'Pausar som ambiente de chuva' : 'Tocar som de chuva suave'}
      >
        {isAudioPlaying ? <Volume2 size={15} /> : <VolumeX size={15} />}
      </button>

      {/* Controls */}
      <div className="flex items-center gap-1.5 border-l border-[#564C4E] pl-3">
        <button
          onClick={onTogglePlay}
          className="p-2 bg-[#564C4E] hover:bg-[#6D6366] text-white rounded-xl transition-colors cursor-pointer"
          title={isRunning ? 'Pausar' : 'Continuar'}
        >
          {isRunning ? <Pause size={15} /> : <Play size={15} fill="currentColor" />}
        </button>

        <button
          onClick={onStopSession}
          className="p-2 bg-[#5A9F76] hover:bg-[#43805B] text-white rounded-xl transition-colors flex items-center gap-1.5 text-xs font-bold px-3 shadow-xs cursor-pointer active:scale-95"
          title="Finalizar e Registrar Execução"
        >
          <Square size={13} fill="currentColor" />
          <span>Concluir</span>
        </button>
      </div>
    </div>
  );
};
