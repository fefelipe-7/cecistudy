import React, { useState } from 'react';
import {
  X,
  RefreshCw,
  CheckCircle2,
  Calendar as CalendarIcon,
  ShieldCheck,
} from 'lucide-react';

interface GoogleSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerSync: () => void;
  isSyncing: boolean;
  lastSyncedAt: string;
}

export const GoogleSyncModal: React.FC<GoogleSyncModalProps> = ({
  isOpen,
  onClose,
  onTriggerSync,
  isSyncing,
  lastSyncedAt,
}) => {
  if (!isOpen) return null;

  const [autoSyncEnabled, setAutoSyncEnabled] = useState(true);

  return (
    <div
      id="google-sync-modal-overlay"
      className="fixed inset-0 z-50 bg-[#40383A]/40 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-[#E9DFDC] overflow-hidden select-none">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#E9DFDC] flex items-center justify-between bg-[#FAF8F5]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#BD913C] text-white flex items-center justify-center font-bold text-sm shadow-xs">
              <CalendarIcon size={16} />
            </div>
            <div>
              <h3 className="font-bold text-sm font-display text-[#40383A]">
                Integração Google Calendar
              </h3>
              <p className="text-[11px] text-[#918689]">
                Sincronização bidirecional do cecistudy
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#918689] hover:text-[#40383A] rounded-lg cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-6 flex flex-col gap-4 text-xs">
          {/* Status Box */}
          <div className="p-4 bg-[#F2FAF5] border border-[#C2E8D0] rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 size={18} className="text-[#5A9F76] shrink-0" />
              <div>
                <span className="font-bold text-[#2A513A] block text-xs">
                  Conexão Ativa e Sincronizada
                </span>
                <span className="text-[11px] text-[#356647]">
                  Calendário: <strong>cecistudy — Acadêmico</strong>
                </span>
              </div>
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-[#5A9F76] ring-4 ring-[#C2E8D0]" />
          </div>

          {/* Sync details */}
          <div className="flex flex-col gap-2.5 bg-[#FAF8F5] p-4 rounded-xl border border-[#E9DFDC]">
            <div className="flex items-center justify-between text-[#40383A]">
              <span className="font-medium text-[#918689]">Última sincronização:</span>
              <span className="font-mono font-semibold">{lastSyncedAt}</span>
            </div>
            <div className="flex items-center justify-between text-[#40383A]">
              <span className="font-medium text-[#918689]">Permissão de escrita:</span>
              <span className="text-[#356647] font-semibold flex items-center gap-1">
                <ShieldCheck size={14} /> Bidirecional
              </span>
            </div>
            <div className="flex items-center justify-between text-[#40383A]">
              <span className="font-medium text-[#918689]">Eventos externos:</span>
              <span className="text-[#40383A] font-semibold">
                Somente leitura (como bloqueios)
              </span>
            </div>
          </div>

          {/* Auto-sync Toggle */}
          <label className="flex items-center justify-between p-3 bg-white border border-[#E9DFDC] rounded-xl cursor-pointer hover:bg-[#FAF8F5] transition-colors">
            <div className="flex flex-col">
              <span className="font-bold text-[#40383A]">Sincronização em tempo real</span>
              <span className="text-[11px] text-[#918689]">
                Propagar imediatamente alterações para o Google Agenda
              </span>
            </div>
            <input
              type="checkbox"
              checked={autoSyncEnabled}
              onChange={(e) => setAutoSyncEnabled(e.target.checked)}
              className="w-4 h-4 rounded text-[#D85F79] focus:ring-[#FFD3DD]"
            />
          </label>

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-3 border-t border-[#E9DFDC] mt-1">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-[#E9DFDC] hover:bg-[#FAF8F5] text-[#6D6366] rounded-xl font-semibold cursor-pointer"
            >
              Fechar
            </button>

            <button
              onClick={onTriggerSync}
              disabled={isSyncing}
              className="px-4 py-2 bg-[#D85F79] hover:bg-[#B94862] disabled:opacity-50 text-white rounded-xl font-semibold flex items-center gap-2 shadow-xs transition-all cursor-pointer"
            >
              <RefreshCw
                size={14}
                className={isSyncing ? 'animate-spin' : ''}
              />
              <span>{isSyncing ? 'Sincronizando...' : 'Sincronizar Agora'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
