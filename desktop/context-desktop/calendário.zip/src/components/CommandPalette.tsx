import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Calendar as CalendarIcon,
  Plus,
  Play,
  Layers,
  Sparkles,
  RefreshCw,
  Clock,
  BookOpen,
  FolderHeart,
  Brain,
  Home,
  CheckCircle2,
  X,
} from 'lucide-react';
import { CalendarItem, LayerConfig, ViewMode, CeciSuggestion } from '../types';
import { formatDatePtBR } from '../utils/dateUtils';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  items: CalendarItem[];
  layers: LayerConfig[];
  suggestions: CeciSuggestion[];
  onSelectItem: (item: CalendarItem) => void;
  onOpenNewItem: () => void;
  onViewModeChange: (mode: ViewMode) => void;
  onOpenSuggestions: () => void;
  onToggleLayer: (layerId: string) => void;
  onStartTimer: (item: CalendarItem) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  items,
  layers,
  suggestions,
  onSelectItem,
  onOpenNewItem,
  onViewModeChange,
  onOpenSuggestions,
  onToggleLayer,
  onStartTimer,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Filter items
  const matchedItems = items.filter((item) => {
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.categoryLabel.toLowerCase().includes(q) ||
      item.layer.toLowerCase().includes(q)
    );
  }).slice(0, 5);

  const actions = [
    {
      id: 'act-new',
      title: 'Criar novo registro / bloco de foco',
      category: 'Ação rápida',
      icon: Plus,
      action: () => {
        onClose();
        onOpenNewItem();
      },
    },
    {
      id: 'act-sug',
      title: `Ver sugestões da Ceci (${suggestions.length} pendentes)`,
      category: 'Ceci IA',
      icon: Sparkles,
      action: () => {
        onClose();
        onOpenSuggestions();
      },
    },
    {
      id: 'act-view-week',
      title: 'Mudar para visualização: Semana',
      category: 'Visualização',
      icon: CalendarIcon,
      action: () => {
        onClose();
        onViewModeChange('semana');
      },
    },
    {
      id: 'act-view-day',
      title: 'Mudar para visualização: Dia',
      category: 'Visualização',
      icon: Clock,
      action: () => {
        onClose();
        onViewModeChange('dia');
      },
    },
    {
      id: 'act-view-month',
      title: 'Mudar para visualização: Mês',
      category: 'Visualização',
      icon: CalendarIcon,
      action: () => {
        onClose();
        onViewModeChange('mes');
      },
    },
    {
      id: 'act-view-agenda',
      title: 'Mudar para visualização: Agenda',
      category: 'Visualização',
      icon: BookOpen,
      action: () => {
        onClose();
        onViewModeChange('agenda');
      },
    },
  ].filter((act) => {
    if (!query.trim()) return true;
    return act.title.toLowerCase().includes(query.toLowerCase());
  });

  const totalResults = matchedItems.length + actions.length;

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(totalResults, 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + Math.max(totalResults, 1)) % Math.max(totalResults, 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (selectedIndex < matchedItems.length) {
        const item = matchedItems[selectedIndex];
        onClose();
        onSelectItem(item);
      } else {
        const act = actions[selectedIndex - matchedItems.length];
        if (act) act.action();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  return (
    <div
      id="command-palette-overlay"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-[#40383A]/40 backdrop-blur-xs flex items-start justify-center pt-20 p-4 transition-all duration-200"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-[#E9DFDC] overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150 select-none"
      >
        {/* Search Bar Input */}
        <div className="flex items-center px-4 py-3.5 border-b border-[#E9DFDC] bg-[#FAF8F5] gap-3">
          <Search size={18} className="text-[#D85F79] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Buscar atividade, bloco de foco, atalho ou comando... (↑↓ para navegar)"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
            className="w-full bg-transparent text-sm text-[#40383A] placeholder:text-[#ADA3A5] focus:outline-hidden"
          />
          <kbd className="bg-white border border-[#E9DFDC] text-[#918689] text-[10px] px-1.5 py-0.5 rounded-md font-mono shadow-2xs">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-80 overflow-y-auto p-2 flex flex-col gap-1">
          {matchedItems.length > 0 && (
            <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-[#918689]">
              Atividades & Blocos no Calendário
            </div>
          )}

          {matchedItems.map((item, idx) => {
            const isSelected = idx === selectedIndex;
            return (
              <div
                key={item.id}
                onClick={() => {
                  onClose();
                  onSelectItem(item);
                }}
                className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs cursor-pointer transition-colors ${
                  isSelected
                    ? 'bg-[#FFF5F7] text-[#D85F79] font-medium'
                    : 'hover:bg-[#FAF8F5] text-[#40383A]'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{
                      backgroundColor:
                        item.layer === 'faculdade'
                          ? '#4A879F'
                          : item.layer === 'tcc'
                          ? '#D85F79'
                          : item.layer === 'estudos'
                          ? '#5A9F76'
                          : '#BD913C',
                    }}
                  />
                  <div className="flex flex-col min-w-0">
                    <span className="truncate font-semibold">{item.title}</span>
                    <span className="text-[10px] text-[#918689]">
                      {formatDatePtBR(item.date)} • {item.startTime} — {item.endTime}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onClose();
                      onStartTimer(item);
                    }}
                    className="p-1 hover:bg-[#FFE9EE] text-[#D85F79] rounded-md transition-colors"
                    title="Iniciar foco"
                  >
                    <Play size={12} fill="currentColor" />
                  </button>
                  <span className="text-[10px] font-mono text-[#ADA3A5]">Abrir ↵</span>
                </div>
              </div>
            );
          })}

          {actions.length > 0 && (
            <div className="px-3 pt-3 pb-1 text-[10px] font-bold uppercase tracking-wider text-[#918689]">
              Comandos & Navegação
            </div>
          )}

          {actions.map((act, idx) => {
            const actualIdx = matchedItems.length + idx;
            const isSelected = actualIdx === selectedIndex;
            const Icon = act.icon;
            return (
              <div
                key={act.id}
                onClick={act.action}
                className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs cursor-pointer transition-colors ${
                  isSelected
                    ? 'bg-[#FFF5F7] text-[#D85F79] font-medium'
                    : 'hover:bg-[#FAF8F5] text-[#40383A]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-6 h-6 rounded-lg flex items-center justify-center ${
                      isSelected
                        ? 'bg-[#FFE9EE] text-[#D85F79]'
                        : 'bg-[#FAF8F5] text-[#918689]'
                    }`}
                  >
                    <Icon size={13} />
                  </div>
                  <span>{act.title}</span>
                </div>
                <span className="text-[10px] text-[#ADA3A5] font-mono">Executar ↵</span>
              </div>
            );
          })}

          {totalResults === 0 && (
            <div className="text-center py-8 text-xs text-[#918689]">
              Nenhum item ou comando correspondente a "{query}".
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2 border-t border-[#E9DFDC] bg-[#FAF8F5] flex items-center justify-between text-[11px] text-[#918689]">
          <span>cecistudy command engine</span>
          <div className="flex items-center gap-3">
            <span>↑↓ navegar</span>
            <span>↵ selecionar</span>
            <span>ESC fechar</span>
          </div>
        </div>
      </div>
    </div>
  );
};
