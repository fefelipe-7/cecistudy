import React, { useState } from 'react';
import {
  BookOpen,
  Award,
  Clock,
  Target,
  CheckCircle2,
  Plus,
  TrendingUp,
  Download,
  Calendar,
  Sparkles,
  Layers,
  GraduationCap,
  FileCheck,
  Flame,
  FileText,
  Check,
} from 'lucide-react';
import {
  CalendarItem,
  SubjectHoursProgress,
  ComplementaryActivity,
  LayerConfig,
} from '../types';
import {
  INITIAL_SUBJECTS,
  INITIAL_COMPLEMENTARY_ACTIVITIES,
  calculateHoursStats,
} from '../data/hoursData';
import { formatDuration } from '../utils/dateUtils';

interface HoursKnowledgeViewProps {
  items: CalendarItem[];
  layers: LayerConfig[];
  selectedDate: string;
  onBackToCalendar: () => void;
  onStartFocusOnSubject?: (subjectName: string) => void;
}

export const HoursKnowledgeView: React.FC<HoursKnowledgeViewProps> = ({
  items,
  layers,
  selectedDate,
  onBackToCalendar,
  onStartFocusOnSubject,
}) => {
  const [activeTab, setActiveTab] = useState<'materias' | 'complementares' | 'relatorio'>('materias');
  const [subjects, setSubjects] = useState<SubjectHoursProgress[]>(INITIAL_SUBJECTS);
  const [activities, setActivities] = useState<ComplementaryActivity[]>(INITIAL_COMPLEMENTARY_ACTIVITIES);

  // New AC Modal state
  const [isAddingAcModalOpen, setIsAddingAcModalOpen] = useState(false);
  const [newAcTitle, setNewAcTitle] = useState('');
  const [newAcHours, setNewAcHours] = useState(10);
  const [newAcCategory, setNewAcCategory] = useState<ComplementaryActivity['category']>('extensao');
  const [newAcInstitution, setNewAcInstitution] = useState('');

  const stats = calculateHoursStats(items, selectedDate);

  // Complementary hours totals
  const validatedAcHours = activities
    .filter((a) => a.validated)
    .reduce((sum, a) => sum + a.hours, 0);
  const pendingAcHours = activities
    .filter((a) => !a.validated)
    .reduce((sum, a) => sum + a.hours, 0);
  const totalRequiredAcHours = 120;
  const acProgressPercent = Math.min(100, Math.round((validatedAcHours / totalRequiredAcHours) * 100));

  // Total Semester Subject hours
  const totalSubjectRequiredHours = subjects.reduce((sum, s) => sum + s.totalRequiredHours, 0);
  const totalSubjectCompletedHours = subjects.reduce((sum, s) => sum + s.completedHours, 0);
  const subjectProgressPercent = Math.round((totalSubjectCompletedHours / totalSubjectRequiredHours) * 100);

  const handleAddAc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAcTitle.trim()) return;

    const newActivity: ComplementaryActivity = {
      id: `ac-${Date.now()}`,
      title: newAcTitle.trim(),
      category: newAcCategory,
      categoryLabel:
        newAcCategory === 'pesquisa'
          ? 'Pesquisa / IC'
          : newAcCategory === 'extensao'
          ? 'Extensão Universitária'
          : newAcCategory === 'ensino'
          ? 'Ensino / Monitoria'
          : 'Curso Extracurricular',
      hours: Number(newAcHours) || 5,
      date: new Date().toISOString().split('T')[0],
      institution: newAcInstitution.trim() || 'Instituição de Ensino',
      validated: true,
    };

    setActivities([newActivity, ...activities]);
    setIsAddingAcModalOpen(false);
    setNewAcTitle('');
    setNewAcInstitution('');
    setNewAcHours(10);
  };

  return (
    <div id="hours-knowledge-view" className="flex-1 flex flex-col h-full bg-[#FFFCF8] overflow-y-auto select-none p-6 lg:p-8">
      <div className="max-w-6xl mx-auto w-full flex flex-col gap-6">
        {/* Top Header Card */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-[#E9DFDC] p-5 rounded-2xl shadow-2xs">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#FFE9EE] border border-[#FFD3DD] flex items-center justify-center text-[#D85F79] shadow-2xs">
              <BookOpen size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold font-display text-[#40383A]">
                  Base de Conhecimento & Banco de Horas
                </h1>
                <span className="bg-[#E6F2F7] text-[#396D82] text-[11px] font-bold px-2 py-0.5 rounded-full border border-[#CEE7F0]">
                  Semestre 2025.1
                </span>
              </div>
              <p className="text-xs text-[#918689] mt-0.5">
                Acompanhamento da carga horária acadêmica, horas complementares e progresso de disciplinas.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onBackToCalendar}
              className="px-3.5 py-2 bg-white hover:bg-[#FAF8F5] border border-[#E9DFDC] text-[#40383A] text-xs font-semibold rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Calendar size={14} className="text-[#918689]" />
              <span>Ver no Calendário</span>
            </button>
            <button
              onClick={() => setIsAddingAcModalOpen(true)}
              className="px-3.5 py-2 bg-[#D85F79] hover:bg-[#B94862] text-white text-xs font-semibold rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <Plus size={14} />
              <span>+ Atividade / Horas</span>
            </button>
          </div>
        </div>

        {/* 4 Summary Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Card 1: Horas de Disciplinas */}
          <div className="bg-white border border-[#E9DFDC] p-4 rounded-2xl shadow-2xs flex flex-col justify-between gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#918689] uppercase tracking-wider">
                Carga de Disciplinas
              </span>
              <div className="w-8 h-8 rounded-xl bg-[#E6F2F7] text-[#396D82] flex items-center justify-center">
                <GraduationCap size={16} />
              </div>
            </div>
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold font-mono text-[#40383A]">
                  {totalSubjectCompletedHours}h
                </span>
                <span className="text-xs font-mono text-[#918689]">
                  / {totalSubjectRequiredHours}h
                </span>
              </div>
              <div className="w-full bg-[#FAF8F5] rounded-full h-2 border border-[#E9DFDC] overflow-hidden mt-2">
                <div
                  className="bg-[#4A879F] h-full rounded-full transition-all duration-500"
                  style={{ width: `${subjectProgressPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-[#918689] mt-1.5">
                <span>{subjectProgressPercent}% cumprido</span>
                <span className="text-[#396D82] font-semibold">5 matérias ativas</span>
              </div>
            </div>
          </div>

          {/* Card 2: Atividades Complementares */}
          <div className="bg-white border border-[#E9DFDC] p-4 rounded-2xl shadow-2xs flex flex-col justify-between gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#918689] uppercase tracking-wider">
                Horas Complementares (AC)
              </span>
              <div className="w-8 h-8 rounded-xl bg-[#FFE9EE] text-[#D85F79] flex items-center justify-center">
                <Award size={16} />
              </div>
            </div>
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold font-mono text-[#D85F79]">
                  {validatedAcHours}h
                </span>
                <span className="text-xs font-mono text-[#918689]">
                  / {totalRequiredAcHours}h req.
                </span>
              </div>
              <div className="w-full bg-[#FAF8F5] rounded-full h-2 border border-[#E9DFDC] overflow-hidden mt-2">
                <div
                  className="bg-[#D85F79] h-full rounded-full transition-all duration-500"
                  style={{ width: `${acProgressPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-[#918689] mt-1.5">
                <span>{acProgressPercent}% validado</span>
                <span className="text-[#D85F79] font-semibold">+{pendingAcHours}h em análise</span>
              </div>
            </div>
          </div>

          {/* Card 3: Horas Dedicadas na Semana */}
          <div className="bg-white border border-[#E9DFDC] p-4 rounded-2xl shadow-2xs flex flex-col justify-between gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#918689] uppercase tracking-wider">
                Horas na Semana
              </span>
              <div className="w-8 h-8 rounded-xl bg-[#DDF3E5] text-[#356647] flex items-center justify-center">
                <Clock size={16} />
              </div>
            </div>
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold font-mono text-[#356647]">
                  {stats.completedHours}h
                </span>
                <span className="text-xs font-mono text-[#918689]">
                  / {stats.plannedHours}h planejado
                </span>
              </div>
              <div className="w-full bg-[#FAF8F5] rounded-full h-2 border border-[#E9DFDC] overflow-hidden mt-2">
                <div
                  className="bg-[#5A9F76] h-full rounded-full transition-all duration-500"
                  style={{ width: `${stats.efficiencyRate}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-[#918689] mt-1.5">
                <span>{stats.efficiencyRate}% taxa de execução</span>
                <span className="text-[#356647] font-semibold">{stats.focusSessionsCount} blocos de foco</span>
              </div>
            </div>
          </div>

          {/* Card 4: Foco & TCC */}
          <div className="bg-white border border-[#E9DFDC] p-4 rounded-2xl shadow-2xs flex flex-col justify-between gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#918689] uppercase tracking-wider">
                Dedicação TCC
              </span>
              <div className="w-8 h-8 rounded-xl bg-[#FFF0CC] text-[#96702B] flex items-center justify-center">
                <Flame size={16} />
              </div>
            </div>
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold font-mono text-[#96702B]">
                  48.0h
                </span>
                <span className="text-xs font-mono text-[#918689]">
                  / 120h meta TCC
                </span>
              </div>
              <div className="w-full bg-[#FAF8F5] rounded-full h-2 border border-[#E9DFDC] overflow-hidden mt-2">
                <div
                  className="bg-[#BD913C] h-full rounded-full transition-all duration-500"
                  style={{ width: `40%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-[#918689] mt-1.5">
                <span>Capítulo 2 em revisão</span>
                <span className="text-[#96702B] font-semibold">8 créditos</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation Controls */}
        <div className="flex items-center gap-2 border-b border-[#E9DFDC] pb-2">
          <button
            onClick={() => setActiveTab('materias')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'materias'
                ? 'bg-[#40383A] text-white shadow-2xs'
                : 'bg-white hover:bg-[#FFF8F1] text-[#6D6366] border border-[#E9DFDC]'
            }`}
          >
            Disciplinas do Semestre ({subjects.length})
          </button>
          <button
            onClick={() => setActiveTab('complementares')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'complementares'
                ? 'bg-[#40383A] text-white shadow-2xs'
                : 'bg-white hover:bg-[#FFF8F1] text-[#6D6366] border border-[#E9DFDC]'
            }`}
          >
            Horas Complementares ({activities.length})
          </button>
          <button
            onClick={() => setActiveTab('relatorio')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'relatorio'
                ? 'bg-[#40383A] text-white shadow-2xs'
                : 'bg-white hover:bg-[#FFF8F1] text-[#6D6366] border border-[#E9DFDC]'
            }`}
          >
            Balanço & Relatório Geral
          </button>
        </div>

        {/* TAB 1: Disciplinas do Semestre */}
        {activeTab === 'materias' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {subjects.map((sub) => {
              const pct = Math.round((sub.completedHours / sub.totalRequiredHours) * 100);
              return (
                <div
                  key={sub.id}
                  className="bg-white border border-[#E9DFDC] p-5 rounded-2xl shadow-2xs flex flex-col justify-between gap-4 hover:border-[#DCCFCA] transition-all"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: sub.colorHex }}
                        />
                        <span className="text-[11px] font-mono font-bold text-[#918689]">
                          {sub.code}
                        </span>
                        <span className="text-[10px] font-semibold bg-[#FAF8F5] px-2 py-0.5 rounded-md border border-[#E9DFDC] text-[#6D6366]">
                          {sub.credits} créditos
                        </span>
                      </div>
                      <h3 className="text-sm font-bold text-[#40383A] mt-1">
                        {sub.name}
                      </h3>
                      {sub.professor && (
                        <p className="text-[11px] text-[#918689] mt-0.5">
                          {sub.professor}
                        </p>
                      )}
                    </div>

                    <div className="text-right">
                      <div className="text-base font-mono font-bold text-[#40383A]">
                        {sub.completedHours}h{' '}
                        <span className="text-xs text-[#918689]">/ {sub.totalRequiredHours}h</span>
                      </div>
                      <span className="text-[11px] font-semibold text-[#5A9F76]">
                        {pct}% concluído
                      </span>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="flex flex-col gap-1.5">
                    <div className="w-full bg-[#FAF8F5] rounded-full h-2.5 border border-[#E9DFDC] overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${pct}%`,
                          backgroundColor: sub.colorHex,
                        }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-[#918689]">
                      <span>{sub.totalRequiredHours - sub.completedHours}h restantes no semestre</span>
                      <span>+{sub.plannedHoursThisWeek}h programadas esta semana</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-[#F2EBE8]">
                    <div className="flex items-center gap-1.5 text-xs text-[#6D6366]">
                      <Sparkles size={13} className="text-[#D85F79]" />
                      <span>{sub.layer === 'tcc' ? 'Cap. 2 em escrita' : '2 aulas / semana'}</span>
                    </div>
                    {onStartFocusOnSubject && (
                      <button
                        onClick={() => onStartFocusOnSubject(sub.name)}
                        className="px-3 py-1.5 bg-[#FFF5F7] hover:bg-[#FFE9EE] text-[#D85F79] rounded-xl text-xs font-bold transition-colors cursor-pointer"
                      >
                        Iniciar Foco
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 2: Horas Complementares (AC) */}
        {activeTab === 'complementares' && (
          <div className="flex flex-col gap-4">
            <div className="bg-[#FFFDF0] border border-[#FCE4A8] p-4 rounded-2xl flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Award size={20} className="text-[#BD913C]" />
                <div>
                  <h4 className="text-xs font-bold text-[#5E471F]">
                    Exigência Curricular de Atividades Complementares
                  </h4>
                  <p className="text-[11px] text-[#8C6B26] mt-0.5">
                    Você já cumpriu {validatedAcHours}h de 120h obrigatórias. Faltam {Math.max(0, totalRequiredAcHours - validatedAcHours)}h para cumprir o requisito de formatura.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAddingAcModalOpen(true)}
                className="px-3 py-1.5 bg-[#BD913C] hover:bg-[#96702B] text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0"
              >
                + Enviar Certificado
              </button>
            </div>

            {/* List of AC activities */}
            <div className="bg-white border border-[#E9DFDC] rounded-2xl overflow-hidden shadow-2xs">
              <div className="p-4 border-b border-[#E9DFDC] flex items-center justify-between">
                <h3 className="text-xs font-bold text-[#40383A] uppercase tracking-wider">
                  Histórico de Atividades & Certificados Homologados
                </h3>
                <span className="text-xs font-mono text-[#918689]">
                  Total: {validatedAcHours + pendingAcHours}h cadastradas
                </span>
              </div>

              <div className="divide-y divide-[#F2EBE8]">
                {activities.map((act) => (
                  <div key={act.id} className="p-4 flex items-center justify-between gap-4 hover:bg-[#FFF8F1]/40 transition-colors">
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                          act.validated
                            ? 'bg-[#DDF3E5] text-[#356647]'
                            : 'bg-[#FFF0CC] text-[#96702B]'
                        }`}
                      >
                        {act.hours}h
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-[#40383A]">{act.title}</h4>
                          <span className="text-[10px] font-semibold bg-[#FAF8F5] border border-[#E9DFDC] text-[#6D6366] px-2 py-0.2 rounded-md">
                            {act.categoryLabel}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#918689] mt-0.5">
                          {act.institution} • {act.date}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      {act.validated ? (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-[#5A9F76] bg-[#DDF3E5] px-2.5 py-1 rounded-full">
                          <CheckCircle2 size={13} />
                          <span>Homologado</span>
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-[#BD913C] bg-[#FFF0CC] px-2.5 py-1 rounded-full">
                          <Clock size={13} />
                          <span>Em Análise</span>
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Balanço & Relatório Geral */}
        {activeTab === 'relatorio' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Left: Distribution by Layer */}
            <div className="bg-white border border-[#E9DFDC] p-5 rounded-2xl shadow-2xs flex flex-col gap-4">
              <h3 className="text-xs font-bold text-[#40383A] uppercase tracking-wider">
                Distribuição de Tempo por Camadas
              </h3>

              <div className="flex flex-col gap-3">
                {layers.map((l) => {
                  const layerData = stats.byLayer[l.id] || { planned: 0, completed: 0, count: 0 };
                  const hoursComp = Number((layerData.completed / 60).toFixed(1));
                  const hoursPlan = Number((layerData.planned / 60).toFixed(1));
                  const pct = stats.completedMinutes > 0 ? Math.round((layerData.completed / stats.completedMinutes) * 100) : 0;

                  return (
                    <div key={l.id} className="flex flex-col gap-1">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: l.colorHex }}
                          />
                          <span className="font-semibold text-[#40383A]">{l.label}</span>
                        </div>
                        <span className="font-mono text-[#918689] text-[11px]">
                          {hoursComp}h / {hoursPlan}h ({pct}%)
                        </span>
                      </div>
                      <div className="w-full bg-[#FAF8F5] rounded-full h-2 border border-[#E9DFDC] overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${pct}%`,
                            backgroundColor: l.colorHex,
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right: Academic Productivity Summary & Export */}
            <div className="lg:col-span-2 bg-white border border-[#E9DFDC] p-5 rounded-2xl shadow-2xs flex flex-col justify-between gap-4">
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-[#40383A] uppercase tracking-wider">
                    Resumo Semestral de Desempenho
                  </h3>
                  <span className="text-xs text-[#5A9F76] font-bold bg-[#DDF3E5] px-2.5 py-1 rounded-full">
                    Ritmo Adequado
                  </span>
                </div>

                <p className="text-xs text-[#6D6366] leading-relaxed">
                  Com base no histórico dos seus blocos de foco e aulas cadastradas, você cumpre em média <strong>14.5 horas líquidas semanais</strong> de estudo concentrado. Mantendo esse ritmo, você concluirá todos os requisitos de TCC e créditos do 6º semestre com 10 dias de antecedência antes do período de finais.
                </p>

                <div className="grid grid-cols-3 gap-3 pt-2">
                  <div className="bg-[#FAF8F5] border border-[#E9DFDC] p-3 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-[#918689]">Média Diária</span>
                    <div className="text-lg font-mono font-bold text-[#40383A] mt-0.5">2.9h/dia</div>
                  </div>
                  <div className="bg-[#FAF8F5] border border-[#E9DFDC] p-3 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-[#918689]">Blocos de Foco</span>
                    <div className="text-lg font-mono font-bold text-[#40383A] mt-0.5">18 sessões</div>
                  </div>
                  <div className="bg-[#FAF8F5] border border-[#E9DFDC] p-3 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-[#918689]">Aproveitamento</span>
                    <div className="text-lg font-mono font-bold text-[#5A9F76] mt-0.5">92%</div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#F2EBE8] flex items-center justify-between">
                <span className="text-[11px] text-[#918689]">
                  Relatório gerado automaticamente para comprovação acadêmica.
                </span>
                <button
                  onClick={() => alert('Relatório de horas exportado com sucesso em formato PDF!')}
                  className="px-4 py-2 bg-[#40383A] hover:bg-[#2D2728] text-white rounded-xl text-xs font-semibold shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Download size={14} />
                  <span>Exportar Relatório PDF</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modal to register new Complementary Activity */}
      {isAddingAcModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#E9DFDC] rounded-2xl max-w-md w-full p-6 shadow-xl flex flex-col gap-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-[#E9DFDC] pb-3">
              <div className="flex items-center gap-2 text-sm font-bold text-[#40383A]">
                <Award size={18} className="text-[#D85F79]" />
                <span>Registrar Atividade Complementar</span>
              </div>
              <button
                onClick={() => setIsAddingAcModalOpen(false)}
                className="text-[#918689] hover:text-[#40383A] text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddAc} className="flex flex-col gap-3">
              <div>
                <label className="text-[11px] font-bold text-[#6D6366] uppercase">
                  Título da Atividade / Curso
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Simpósio Nacional de Computação"
                  value={newAcTitle}
                  onChange={(e) => setNewAcTitle(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E9DFDC] rounded-xl text-[#40383A] focus:outline-hidden focus:border-[#D85F79]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-[#6D6366] uppercase">
                    Horas Comprovadas
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    required
                    value={newAcHours}
                    onChange={(e) => setNewAcHours(Number(e.target.value))}
                    className="w-full mt-1 px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E9DFDC] rounded-xl text-[#40383A] focus:outline-hidden focus:border-[#D85F79]"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[#6D6366] uppercase">
                    Modalidade
                  </label>
                  <select
                    value={newAcCategory}
                    onChange={(e) => setNewAcCategory(e.target.value as any)}
                    className="w-full mt-1 px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E9DFDC] rounded-xl text-[#40383A] focus:outline-hidden focus:border-[#D85F79]"
                  >
                    <option value="extensao">Extensão</option>
                    <option value="pesquisa">Pesquisa / IC</option>
                    <option value="ensino">Ensino / Monitoria</option>
                    <option value="outro">Curso Extracurricular</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#6D6366] uppercase">
                  Instituição / Emissor
                </label>
                <input
                  type="text"
                  placeholder="Ex: USP, Coursera, Alura, Coordenação"
                  value={newAcInstitution}
                  onChange={(e) => setNewAcInstitution(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E9DFDC] rounded-xl text-[#40383A] focus:outline-hidden focus:border-[#D85F79]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#E9DFDC] mt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingAcModalOpen(false)}
                  className="px-3.5 py-2 text-xs font-semibold text-[#6D6366] hover:bg-[#FAF8F5] rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#D85F79] hover:bg-[#B94862] text-white text-xs font-bold rounded-xl shadow-xs"
                >
                  Salvar Atividade
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
