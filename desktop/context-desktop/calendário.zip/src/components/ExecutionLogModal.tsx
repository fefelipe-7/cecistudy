import React, { useState } from 'react';
import { X, CheckCircle2, Award } from 'lucide-react';
import { CalendarItem, ExecutionRecord } from '../types';
import { formatDuration } from '../utils/dateUtils';

interface ExecutionLogModalProps {
  isOpen: boolean;
  item: CalendarItem | null;
  durationSeconds: number;
  onClose: () => void;
  onSaveExecution: (item: CalendarItem, record: ExecutionRecord) => void;
}

export const ExecutionLogModal: React.FC<ExecutionLogModalProps> = ({
  isOpen,
  item,
  durationSeconds,
  onClose,
  onSaveExecution,
}) => {
  if (!isOpen || !item) return null;

  const durationMins = Math.max(Math.round(durationSeconds / 60), 1);
  const now = new Date();
  const endTimeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
    now.getMinutes()
  ).padStart(2, '0')}`;
  
  // Estimate start time based on duration
  const startTotalMinutes = now.getHours() * 60 + now.getMinutes() - durationMins;
  const safeStartMin = Math.max(startTotalMinutes, 0);
  const startTimeStr = `${String(Math.floor(safeStartMin / 60)).padStart(
    2,
    '0'
  )}:${String(safeStartMin % 60).padStart(2, '0')}`;

  const [notes, setNotes] = useState(item.notes || '');
  const [actualMinutes, setActualMinutes] = useState(durationMins);
  const [etapas, setEtapas] = useState(item.etapas);

  const handleToggleEtapa = (id: string) => {
    setEtapas(
      etapas.map((et) => (et.id === id ? { ...et, completed: !et.completed } : et))
    );
  };

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    const record: ExecutionRecord = {
      date: item.date,
      startTime: startTimeStr,
      endTime: endTimeStr,
      durationMinutes: actualMinutes,
      notes: notes.trim(),
      completed: true,
      recordedAt: new Date().toISOString(),
    };

    onSaveExecution(
      {
        ...item,
        status: 'concluido',
        etapas,
        notes: notes.trim() || item.notes,
      },
      record
    );
    onClose();
  };

  return (
    <div
      id="execution-log-modal-overlay"
      className="fixed inset-0 z-50 bg-[#40383A]/40 backdrop-blur-xs flex items-center justify-center p-4 select-none"
    >
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-[#E9DFDC] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#E9DFDC] flex items-center justify-between bg-[#F2FAF5]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#5A9F76] text-white flex items-center justify-center shadow-xs">
              <Award size={16} />
            </div>
            <div>
              <h3 className="font-bold text-sm font-display text-[#2A513A]">
                Sessão Concluída!
              </h3>
              <p className="text-[11px] text-[#356647]">
                Registro de execução real do cecistudy
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#918689] hover:text-[#40383A] rounded-lg cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleConfirm} className="p-6 flex flex-col gap-4 text-xs">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#918689]">
              Atividade
            </span>
            <h4 className="text-base font-bold text-[#40383A] mt-0.5">
              {item.title}
            </h4>
          </div>

          {/* Planejado vs Realizado Comparison Box */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-[#FAF8F5] border border-[#E9DFDC] rounded-xl">
            <div>
              <span className="text-[10px] text-[#918689] font-bold uppercase block">
                Planejado
              </span>
              <span className="text-xs font-semibold text-[#40383A] block mt-0.5">
                {item.startTime} — {item.endTime}
              </span>
              <span className="text-[11px] text-[#6D6366]">
                {formatDuration(item.plannedDurationMinutes)}
              </span>
            </div>

            <div className="border-l border-[#E9DFDC] pl-3">
              <span className="text-[10px] text-[#5A9F76] font-bold uppercase block">
                Realizado (Timer)
              </span>
              <span className="text-xs font-bold text-[#40383A] block mt-0.5">
                {startTimeStr} — {endTimeStr}
              </span>
              <span className="text-[11px] font-semibold text-[#356647]">
                {formatDuration(actualMinutes)}
              </span>
            </div>
          </div>

          {/* Actual Duration Input */}
          <div className="flex flex-col gap-1">
            <label className="font-semibold text-[#40383A]">
              Duração Real (minutos)
            </label>
            <input
              type="number"
              min={1}
              max={600}
              value={actualMinutes}
              onChange={(e) => setActualMinutes(parseInt(e.target.value, 10) || 1)}
              className="px-3 py-2 border border-[#E9DFDC] rounded-xl text-xs bg-white text-[#40383A]"
            />
          </div>

          {/* Etapas checklist */}
          {etapas.length > 0 && (
            <div className="flex flex-col gap-1.5">
              <label className="font-semibold text-[#40383A]">
                Quais etapas foram concluídas nesta sessão?
              </label>
              <div className="flex flex-col gap-1 max-h-32 overflow-y-auto">
                {etapas.map((et) => (
                  <label
                    key={et.id}
                    className="flex items-center gap-2 p-1.5 hover:bg-[#FAF8F5] rounded-xl cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={et.completed}
                      onChange={() => handleToggleEtapa(et.id)}
                      className="rounded text-[#D85F79] focus:ring-[#FFD3DD]"
                    />
                    <span
                      className={`text-xs ${
                        et.completed ? 'line-through text-[#ADA3A5]' : 'text-[#40383A]'
                      }`}
                    >
                      {et.title}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Observations */}
          <div className="flex flex-col gap-1">
            <label className="font-semibold text-[#40383A]">
              Observações & O que aconteceu:
            </label>
            <textarea
              rows={3}
              placeholder="Descreva o progresso, dificuldades ou tópicos abordados..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="px-3 py-2 border border-[#E9DFDC] rounded-xl text-xs bg-white text-[#40383A]"
            />
          </div>

          {/* Submit */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E9DFDC] mt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-[#E9DFDC] hover:bg-[#FAF8F5] text-[#6D6366] rounded-xl font-semibold cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#5A9F76] hover:bg-[#43805B] text-white rounded-xl font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 size={14} />
              <span>Salvar Registro</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
