import React from 'react';
import {
  X,
  BookOpen,
  Award,
  Clock,
  Target,
  GraduationCap,
  TrendingUp,
  CheckCircle2,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { CalendarItem, LayerConfig } from '../types';
import { INITIAL_SUBJECTS, INITIAL_COMPLEMENTARY_ACTIVITIES, calculateHoursStats } from '../data/hoursData';

interface HoursAnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CalendarItem[];
  layers: LayerConfig[];
  selectedDate: string;
  onGoToKnowledgeView: () => void;
}

export const HoursAnalyticsModal: React.FC<HoursAnalyticsModalProps> = ({
  isOpen,
  onClose,
  items,
  layers,
  selectedDate,
  onGoToKnowledgeView,
}) => {
  if (!isOpen) return null;

  const stats = calculateHoursStats(items, selectedDate);
  const subjects = INITIAL_SUBJECTS;
  const activities = INITIAL_COMPLEMENTARY_ACTIVITIES;

  const validatedAcHours = activities
    .filter((a) => a.validated)
    .reduce((sum, a) => sum + a.hours, 0);

  return (
    <div
      id="hours-analytics-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 select-none"
      onClick={onClose}
    >
      <div
        id="hours-analytics-modal"
        className="bg-white border border-[#E9DFDC] rounded-3xl max-w-2xl w-full p-6 shadow-2xl flex flex-col gap-5 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-[#E9DFDC] pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#FFE9EE] border border-[#FFD3DD] flex items-center justify-center text-[#D85F79] shadow-2xs">
              <Clock size={20} />
            </div>
            <div>
              <h2 className="text-base font-bold font-display text-[#40383A]">
                Banco de Horas & Desempenho
              </h2>
              <p className="text-xs text-[#918689]">
                Semana atual e balanço acumulado de créditos acadêmicos.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#ADA3A5] hover:text-[#40383A] hover:bg-[#FAF8F5] rounded-xl transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* 3 Main KPIs */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-[#F3F9FC] border border-[#CEE7F0] p-3.5 rounded-2xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#396D82]">
              Dedicadas na Semana
            </span>
            <div className="text-xl font-mono font-bold text-[#284955] mt-1">
              {stats.completedHours}h
            </div>
            <div className="flex items-center justify-between mt-1 text-[10px]">
              <span className="text-[#4A879F]">de {stats.plannedHours}h previstas</span>
              <span className="font-mono font-bold text-[#284955] bg-white/80 px-1.5 py-0.5 rounded border border-[#CEE7F0]">
                {stats.completed30mBlocks}/{stats.planned30mBlocks} blocos (30m)
              </span>
            </div>
          </div>

          <div className="bg-[#FFF5F7] border border-[#FFD3DD] p-3.5 rounded-2xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#B94862]">
              Horas Complementares
            </span>
            <div className="text-xl font-mono font-bold text-[#71303F] mt-1">
              {validatedAcHours}h
            </div>
            <div className="flex items-center justify-between mt-1 text-[10px]">
              <span className="text-[#D85F79]">de 120h obrigatórias</span>
              <span className="font-mono font-bold text-[#B94862] bg-white/80 px-1.5 py-0.5 rounded border border-[#FFD3DD]">
                {validatedAcHours * 2} blocos
              </span>
            </div>
          </div>

          <div className="bg-[#F2FAF5] border border-[#C2E8D0] p-3.5 rounded-2xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#356647]">
              Taxa de Cumprimento
            </span>
            <div className="text-xl font-mono font-bold text-[#2A513A] mt-1">
              {stats.efficiencyRate}%
            </div>
            <div className="flex items-center justify-between mt-1 text-[10px]">
              <span className="text-[#5A9F76]">eficiência de estudo</span>
              <span className="font-mono font-bold text-[#356647] bg-white/80 px-1.5 py-0.5 rounded border border-[#C2E8D0]">
                {stats.focusSessionsCount} sessões
              </span>
            </div>
          </div>
        </div>

        {/* Carga Horária por Matéria */}
        <div className="flex flex-col gap-2.5">
          <h3 className="text-xs font-bold text-[#40383A] uppercase tracking-wider">
            Progresso por Disciplina
          </h3>
          <div className="flex flex-col gap-2 bg-[#FAF8F5] border border-[#E9DFDC] p-3.5 rounded-2xl">
            {subjects.map((sub) => {
              const pct = Math.round((sub.completedHours / sub.totalRequiredHours) * 100);
              return (
                <div key={sub.id} className="flex flex-col gap-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: sub.colorHex }}
                      />
                      <span className="font-semibold text-[#40383A]">{sub.name}</span>
                    </div>
                    <span className="font-mono text-[#918689] text-[11px]">
                      {sub.completedHours}h / {sub.totalRequiredHours}h ({pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-white rounded-full h-1.5 border border-[#E9DFDC] overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${pct}%`, backgroundColor: sub.colorHex }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-[#E9DFDC]">
          <span className="text-[11px] text-[#918689]">
            Matrícula ativa • 34 créditos completados
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onGoToKnowledgeView();
              }}
              className="px-4 py-2 bg-[#D85F79] hover:bg-[#B94862] text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              Abrir Base de Conhecimento Completa
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
