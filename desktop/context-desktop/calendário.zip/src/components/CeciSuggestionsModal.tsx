import React from 'react';
import { X, Sparkles, Check, XCircle, Info } from 'lucide-react';
import { CeciSuggestion } from '../types';
import { formatDatePtBR } from '../utils/dateUtils';

interface CeciSuggestionsModalProps {
  isOpen: boolean;
  suggestions: CeciSuggestion[];
  onClose: () => void;
  onAcceptSuggestion: (suggestion: CeciSuggestion) => void;
  onRejectSuggestion: (suggestionId: string) => void;
}

export const CeciSuggestionsModal: React.FC<CeciSuggestionsModalProps> = ({
  isOpen,
  suggestions,
  onClose,
  onAcceptSuggestion,
  onRejectSuggestion,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="ceci-suggestions-modal-overlay"
      className="fixed inset-0 z-50 bg-[#40383A]/40 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-[#E9DFDC] overflow-hidden select-none">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#E9DFDC] flex items-center justify-between bg-[#FFF5F7]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#D85F79] text-white flex items-center justify-center shadow-xs">
              <Sparkles size={16} />
            </div>
            <div>
              <h2 className="text-sm font-bold font-display text-[#40383A]">
                Sugestões Acadêmicas da Ceci
              </h2>
              <p className="text-[11px] text-[#918689]">
                Blocos de estudo e revisões sugeridos para otimizar sua semana
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#918689] hover:text-[#40383A] rounded-lg cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content list */}
        <div className="p-6 flex flex-col gap-4 max-h-[70vh] overflow-y-auto">
          <div className="p-3 bg-[#F3F9FC] border border-[#CEE7F0] rounded-xl text-xs text-[#284955] flex items-start gap-2">
            <Info size={16} className="text-[#4A879F] shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Regra de autonomia:</strong> As sugestões da Ceci são sempre
              <strong> recomendadas</strong>. Você decide se deseja aceitar, ajustar ou
              recusar sem qualquer penalização.
            </p>
          </div>

          {suggestions.length === 0 ? (
            <div className="text-center py-8 text-[#918689] text-xs">
              Nenhuma nova sugestão pendente no momento. Você está em dia!
            </div>
          ) : (
            suggestions.map((sug) => (
              <div
                key={sug.id}
                className="p-4 bg-[#FAF8F5] rounded-xl border border-[#E9DFDC] flex flex-col gap-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-[#FFF9ED] text-[#96702B] border border-[#FCE4A8] rounded-md">
                      {sug.layer.toUpperCase()} • {sug.category.toUpperCase()}
                    </span>
                    <h3 className="text-sm font-bold text-[#40383A] mt-1">
                      {sug.title}
                    </h3>
                  </div>

                  <span className="text-xs font-mono text-[#40383A] bg-white px-2 py-1 rounded-md border border-[#E9DFDC] font-semibold shrink-0">
                    {sug.suggestedStartTime} — {sug.suggestedEndTime}
                  </span>
                </div>

                <p className="text-xs text-[#6D6366] leading-relaxed">
                  {sug.description}
                </p>

                <div className="p-2.5 bg-white rounded-xl border border-[#E9DFDC] text-[11px] text-[#6D6366] flex items-center gap-1.5">
                  <Sparkles size={12} className="text-[#BD913C] shrink-0" />
                  <span>
                    <strong>Motivo pedagógico:</strong> {sug.reason}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#E9DFDC]">
                  <span className="text-xs text-[#918689] font-medium">
                    📅 {formatDatePtBR(sug.targetDate)}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onRejectSuggestion(sug.id)}
                      className="px-3 py-1.5 hover:bg-[#F2EBE8] text-[#6D6366] rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <XCircle size={13} />
                      <span>Recusar</span>
                    </button>
                    <button
                      onClick={() => onAcceptSuggestion(sug)}
                      className="px-3.5 py-1.5 bg-[#D85F79] hover:bg-[#B94862] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <Check size={13} strokeWidth={2.5} />
                      <span>Aceitar Bloco</span>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
