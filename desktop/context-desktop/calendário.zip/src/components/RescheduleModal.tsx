import React, { useState } from 'react';
import { X, Calendar as CalendarIcon, Clock } from 'lucide-react';
import { CalendarItem } from '../types';
import { parseTimeToMinutes, minutesToTime, formatDurationWithBlocks } from '../utils/dateUtils';

interface RescheduleModalProps {
  isOpen: boolean;
  item: CalendarItem | null;
  onClose: () => void;
  onConfirm: (item: CalendarItem, newDate: string, newStartTime: string, newEndTime: string) => void;
}

export const RescheduleModal: React.FC<RescheduleModalProps> = ({
  isOpen,
  item,
  onClose,
  onConfirm,
}) => {
  if (!isOpen || !item) return null;

  const [newDate, setNewDate] = useState(item.date);
  const [newStartTime, setNewStartTime] = useState(item.startTime);
  const [newEndTime, setNewEndTime] = useState(item.endTime);

  const durationMins = Math.max(parseTimeToMinutes(newEndTime) - parseTimeToMinutes(newStartTime), 30);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm(item, newDate, newStartTime, newEndTime);
    onClose();
  };

  return (
    <div
      id="reschedule-modal-overlay"
      className="fixed inset-0 z-50 bg-[#40383A]/40 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-2xl max-w-sm w-full shadow-2xl border border-[#E9DFDC] overflow-hidden select-none">
        <div className="px-5 py-4 border-b border-[#E9DFDC] flex items-center justify-between bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <CalendarIcon size={16} className="text-[#D85F79]" />
            <h3 className="font-bold text-sm font-display text-[#40383A]">Reagendar Atividade</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#918689] hover:text-[#40383A] rounded-md cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-5 flex flex-col gap-4 text-xs">
          <div>
            <span className="text-[10px] font-bold text-[#918689] uppercase tracking-wider block mb-1">
              Atividade
            </span>
            <p className="font-bold text-[#40383A] text-sm">{item.title}</p>
            <span className="text-[11px] text-[#5A9F76] font-mono font-semibold">
              {formatDurationWithBlocks(durationMins)}
            </span>
          </div>

          <div className="flex flex-col gap-1">
            <label className="font-semibold text-[#40383A]">Nova Data</label>
            <input
              type="date"
              required
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              className="px-3 py-2 border border-[#E9DFDC] rounded-xl text-xs bg-white text-[#40383A]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1">
              <label className="font-semibold text-[#40383A]">Início</label>
              <input
                type="time"
                step="1800"
                required
                value={newStartTime}
                onChange={(e) => {
                  const s = e.target.value;
                  setNewStartTime(s);
                  setNewEndTime(minutesToTime(parseTimeToMinutes(s) + durationMins));
                }}
                className="px-3 py-2 border border-[#E9DFDC] rounded-xl text-xs bg-white text-[#40383A] font-mono"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="font-semibold text-[#40383A]">Término</label>
              <input
                type="time"
                step="1800"
                required
                value={newEndTime}
                onChange={(e) => setNewEndTime(e.target.value)}
                className="px-3 py-2 border border-[#E9DFDC] rounded-xl text-xs bg-white text-[#40383A] font-mono"
              />
            </div>
          </div>

          {/* Quick Duration Buttons (30m, 60m, 90m, 120m) */}
          <div className="flex flex-col gap-1 bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E9DFDC]">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#918689]">
              Duração da Faixa:
            </span>
            <div className="grid grid-cols-4 gap-1">
              {[
                { label: '30m', mins: 30 },
                { label: '1h', mins: 60 },
                { label: '1h30', mins: 90 },
                { label: '2h', mins: 120 },
              ].map((d) => (
                <button
                  key={d.mins}
                  type="button"
                  onClick={() => {
                    const startM = parseTimeToMinutes(newStartTime);
                    setNewEndTime(minutesToTime(startM + d.mins));
                  }}
                  className={`py-1 rounded-lg text-center text-[10px] font-semibold transition-all cursor-pointer ${
                    durationMins === d.mins
                      ? 'bg-[#D85F79] text-white shadow-2xs'
                      : 'bg-white hover:bg-[#FFF5F7] text-[#6D6366] border border-[#E9DFDC]'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E9DFDC] mt-1">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 border border-[#E9DFDC] hover:bg-[#FAF8F5] text-[#6D6366] rounded-xl font-semibold cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-[#D85F79] hover:bg-[#B94862] text-white rounded-xl font-semibold shadow-xs cursor-pointer"
            >
              Confirmar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
