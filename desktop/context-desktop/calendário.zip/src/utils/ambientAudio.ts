// Client-side Web Audio API Sound Synthesizer for Focus & Study (Rain, Ocean, Brown Noise, Cozy Cafe Ambience)

class AmbientAudioEngine {
  private ctx: AudioContext | null = null;
  private noiseNode: AudioNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private gainNode: GainNode | null = null;
  private isPlaying = false;
  private currentMode: 'rain' | 'waves' | 'cafe' | 'deep_focus' = 'rain';

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public play(mode: 'rain' | 'waves' | 'cafe' | 'deep_focus' = 'rain', volume = 0.15) {
    try {
      this.stop();
      this.initContext();
      if (!this.ctx) return;

      this.currentMode = mode;
      const bufferSize = 2 * this.ctx.sampleRate;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);

      // Generate brown / pink noise
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        if (mode === 'rain') {
          // Pink/Rain noise
          output[i] = (lastOut + 0.02 * white) / 1.02;
          lastOut = output[i];
          output[i] *= 3.5;
        } else if (mode === 'deep_focus') {
          // Brown noise (deep rumble)
          output[i] = (lastOut + 0.015 * white) / 1.015;
          lastOut = output[i];
          output[i] *= 4.0;
        } else {
          // Soft ambient noise
          output[i] = (lastOut + 0.04 * white) / 1.04;
          lastOut = output[i];
          output[i] *= 2.5;
        }
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      // Filter for warm soft rain/ambience
      this.filterNode = this.ctx.createBiquadFilter();
      this.filterNode.type = mode === 'deep_focus' ? 'lowpass' : 'bandpass';
      this.filterNode.frequency.value = mode === 'deep_focus' ? 320 : mode === 'rain' ? 850 : 1200;
      this.filterNode.Q.value = 1.0;

      // Gain / Volume
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.setValueAtTime(volume, this.ctx.currentTime);

      whiteNoise.connect(this.filterNode);
      this.filterNode.connect(this.gainNode);
      this.gainNode.connect(this.ctx.destination);

      whiteNoise.start(0);
      this.noiseNode = whiteNoise;
      this.isPlaying = true;
    } catch {
      // Graceful fallback if audio context fails
      this.isPlaying = false;
    }
  }

  public stop() {
    try {
      if (this.noiseNode) {
        (this.noiseNode as AudioBufferSourceNode).stop();
        this.noiseNode.disconnect();
        this.noiseNode = null;
      }
      this.isPlaying = false;
    } catch {
      this.isPlaying = false;
    }
  }

  public setVolume(vol: number) {
    if (this.gainNode && this.ctx) {
      this.gainNode.gain.setValueAtTime(Math.max(0, Math.min(1, vol)), this.ctx.currentTime);
    }
  }

  public getIsPlaying() {
    return this.isPlaying;
  }

  public getMode() {
    return this.currentMode;
  }
}

export const ambientSound = new AmbientAudioEngine();
