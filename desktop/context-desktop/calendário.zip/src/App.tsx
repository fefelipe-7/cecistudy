/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopHeader } from './components/TopHeader';
import { CalendarWeekView } from './components/CalendarWeekView';
import { CalendarDayView } from './components/CalendarDayView';
import { CalendarMonthView } from './components/CalendarMonthView';
import { CalendarAgendaView } from './components/CalendarAgendaView';
import { HoursKnowledgeView } from './components/HoursKnowledgeView';
import { HoursAnalyticsModal } from './components/HoursAnalyticsModal';
import { EventDetailModal } from './components/EventDetailModal';
import { ItemModal } from './components/ItemModal';
import { RescheduleModal } from './components/RescheduleModal';
import { CeciSuggestionsModal } from './components/CeciSuggestionsModal';
import { GoogleSyncModal } from './components/GoogleSyncModal';
import { ActiveTimerBanner } from './components/ActiveTimerBanner';
import { ExecutionLogModal } from './components/ExecutionLogModal';
import { CommandPalette } from './components/CommandPalette';
import { ToastNotification, ToastMessage } from './components/ToastNotification';
import {
  CalendarItem,
  LayerConfig,
  ViewMode,
  CeciSuggestion,
  ExecutionRecord,
} from './types';
import {
  INITIAL_LAYERS,
  INITIAL_ITEMS,
  INITIAL_SUGGESTIONS,
} from './data/initialData';
import { calculateHoursStats } from './data/hoursData';
import {
  getCurrentDateISO,
  addDays,
  addWeeks,
  addMonths,
  formatDatePtBR,
} from './utils/dateUtils';

export default function App() {
  // App Shell Navigation State ('calendario' | 'conhecimento' | 'tcc' | 'estudos' | 'marketing' | 'home' | 'inbox' | 'grafo')
  const [activeNav, setActiveNav] = useState('calendario');

  // Calendar Views State
  const [viewMode, setViewMode] = useState<ViewMode>('semana');
  // Default to 2025-01-15 which matches the rich demo semester dataset, with instant jump to real today via button
  const [selectedDate, setSelectedDate] = useState('2025-01-15');

  // Items & Layers State
  const [items, setItems] = useState<CalendarItem[]>(() => {
    const saved = localStorage.getItem('cecistudy_calendar_items');
    return saved ? JSON.parse(saved) : INITIAL_ITEMS;
  });

  const [layers, setLayers] = useState<LayerConfig[]>(() => {
    const saved = localStorage.getItem('cecistudy_calendar_layers');
    return saved ? JSON.parse(saved) : INITIAL_LAYERS;
  });

  // Selected item for Event Detail Modal
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);

  // Ceci AI suggestions state
  const [suggestions, setSuggestions] = useState<CeciSuggestion[]>(INITIAL_SUGGESTIONS);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'events' | 'meetings' | 'tasks'>('all');

  // Command Palette State
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  // Toast Notifications State
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Google Calendar Sync State
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState('15 jan 2025, 08:00');

  // Active Live Study Timer State
  const [activeTimerItemId, setActiveTimerItemId] = useState<string | null>(null);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  // Hours Knowledge Analytics Modal State
  const [isHoursModalOpen, setIsHoursModalOpen] = useState(false);

  // Modals Visibility State
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [modalInitialDate, setModalInitialDate] = useState(selectedDate);
  const [modalInitialTime, setModalInitialTime] = useState('08:00');
  const [editingItem, setEditingItem] = useState<CalendarItem | null>(null);

  const [isRescheduleModalOpen, setIsRescheduleModalOpen] = useState(false);
  const [rescheduleTargetItem, setRescheduleTargetItem] = useState<CalendarItem | null>(null);

  const [isSuggestionsModalOpen, setIsSuggestionsModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);

  const [isExecutionLogModalOpen, setIsExecutionLogModalOpen] = useState(false);
  const [finishingItem, setFinishingItem] = useState<CalendarItem | null>(null);
  const [finishingDuration, setFinishingDuration] = useState(0);

  // Toast helper
  const addToast = useCallback((title: string, description?: string, type?: ToastMessage['type']) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    setToasts((prev) => [...prev, { id, title, description, type }]);
  }, []);

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Persist items & layers
  useEffect(() => {
    localStorage.setItem('cecistudy_calendar_items', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem('cecistudy_calendar_layers', JSON.stringify(layers));
  }, [layers]);

  // Active Timer Interval
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isInput =
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        (e.target as HTMLElement).isContentEditable;

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        setEditingItem(null);
        setModalInitialDate(selectedDate);
        setModalInitialTime('08:00');
        setIsItemModalOpen(true);
        return;
      }

      if (e.key === 'Escape') {
        if (isCommandPaletteOpen) {
          setIsCommandPaletteOpen(false);
        } else if (isHoursModalOpen) {
          setIsHoursModalOpen(false);
        } else if (isItemModalOpen) {
          setIsItemModalOpen(false);
        } else if (isRescheduleModalOpen) {
          setIsRescheduleModalOpen(false);
        } else if (isSuggestionsModalOpen) {
          setIsSuggestionsModalOpen(false);
        } else if (isSyncModalOpen) {
          setIsSyncModalOpen(false);
        } else if (isExecutionLogModalOpen) {
          setIsExecutionLogModalOpen(false);
        } else if (selectedItemId) {
          setSelectedItemId(null);
        }
        return;
      }

      if (!isInput) {
        if (e.key === '1') {
          setViewMode('semana');
          setActiveNav('calendario');
        } else if (e.key === '2') {
          setViewMode('dia');
          setActiveNav('calendario');
        } else if (e.key === '3') {
          setViewMode('mes');
          setActiveNav('calendario');
        } else if (e.key === '4') {
          setViewMode('agenda');
          setActiveNav('calendario');
        } else if (e.key.toLowerCase() === 't') {
          const today = getCurrentDateISO();
          setSelectedDate(today);
          addToast('Navegado para Hoje', formatDatePtBR(today), 'info');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isCommandPaletteOpen,
    isHoursModalOpen,
    isItemModalOpen,
    isRescheduleModalOpen,
    isSuggestionsModalOpen,
    isSyncModalOpen,
    isExecutionLogModalOpen,
    selectedItemId,
    selectedDate,
    addToast,
  ]);

  // Filter items by active layer, category tab, and search query
  const filteredItems = items.filter((item) => {
    // 1. Layer visibility check
    const itemLayer = layers.find((l) => l.id === item.layer);
    if (itemLayer && !itemLayer.visible) return false;

    // 2. Category Tab filter check
    if (categoryFilter === 'events' && !['aula', 'prova', 'apresentacao'].includes(item.category)) {
      return false;
    }
    if (categoryFilter === 'meetings' && item.category !== 'reuniao' && item.layer !== 'google_calendar') {
      return false;
    }
    if (categoryFilter === 'tasks' && !['bloco_tcc', 'entrega', 'estudo', 'revisao', 'leitura'].includes(item.category)) {
      return false;
    }

    // 3. Search query check
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.categoryLabel.toLowerCase().includes(q) ||
      (item.notes && item.notes.toLowerCase().includes(q))
    );
  });

  // Calculate items count by category for header tabs
  const categoryCounts = {
    all: items.length,
    events: items.filter((i) => ['aula', 'prova', 'apresentacao'].includes(i.category)).length,
    meetings: items.filter((i) => i.category === 'reuniao' || i.layer === 'google_calendar').length,
    tasks: items.filter((i) => ['bloco_tcc', 'entrega', 'estudo', 'revisao', 'leitura'].includes(i.category)).length,
  };

  const selectedItem = items.find((i) => i.id === selectedItemId) || null;
  const activeTimerItem = items.find((i) => i.id === activeTimerItemId) || null;

  // Real-time Hours Calculation
  const hoursStats = calculateHoursStats(items, selectedDate);

  // Toggle Layer visibility
  const handleToggleLayer = (layerId: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === layerId ? { ...l, visible: !l.visible } : l))
    );
  };

  // Item selection
  const handleSelectItem = (item: CalendarItem) => {
    setSelectedItemId(item.id);
  };

  // Close event detail modal
  const handleCloseDetailModal = () => {
    setSelectedItemId(null);
  };

  // Update item date/time via Drag and Drop or Resize
  const handleUpdateItemTime = useCallback(
    (itemId: string, newDate: string, newStartTime: string, newEndTime: string) => {
      setItems((prevItems) => {
        const targetItem = prevItems.find((i) => i.id === itemId);
        const updated = prevItems.map((item) =>
          item.id === itemId
            ? {
                ...item,
                date: newDate,
                startTime: newStartTime,
                endTime: newEndTime,
              }
            : item
        );
        localStorage.setItem('cecistudy_calendar_items', JSON.stringify(updated));

        if (targetItem) {
          addToast(
            'Horário Atualizado',
            `"${targetItem.title}" ajustado para ${formatDatePtBR(newDate)} (${newStartTime} — ${newEndTime})`,
            'info'
          );
        }
        return updated;
      });
    },
    [addToast]
  );

  // Slot click to open create modal
  const handleSlotClick = (date: string, time: string) => {
    setModalInitialDate(date);
    setModalInitialTime(time);
    setEditingItem(null);
    setIsItemModalOpen(true);
  };

  // Save / Update item
  const handleSaveItem = (savedItem: CalendarItem) => {
    setItems((prev) => {
      const exists = prev.some((i) => i.id === savedItem.id);
      if (exists) {
        return prev.map((i) => (i.id === savedItem.id ? savedItem : i));
      }
      return [...prev, savedItem];
    });
    setSelectedItemId(savedItem.id);
    addToast('Registro salvo', `"${savedItem.title}" foi atualizado com sucesso.`, 'success');
  };

  // Delete item
  const handleDeleteItem = (itemId: string) => {
    const itemToDelete = items.find((i) => i.id === itemId);
    setItems((prev) => prev.filter((i) => i.id !== itemId));
    if (selectedItemId === itemId) {
      setSelectedItemId(null);
    }
    if (activeTimerItemId === itemId) {
      setActiveTimerItemId(null);
      setIsTimerRunning(false);
      setTimerSeconds(0);
    }
    addToast('Item excluído', itemToDelete ? `"${itemToDelete.title}" removido.` : undefined, 'info');
  };

  // Reagendar handler
  const handleOpenReschedule = (item: CalendarItem) => {
    setRescheduleTargetItem(item);
    setIsRescheduleModalOpen(true);
  };

  const handleConfirmReschedule = (
    item: CalendarItem,
    newDate: string,
    newStartTime: string,
    newEndTime: string
  ) => {
    const updated: CalendarItem = {
      ...item,
      date: newDate,
      startTime: newStartTime,
      endTime: newEndTime,
      status: item.status === 'nao_realizado' ? 'planejado' : item.status,
    };
    handleSaveItem(updated);
    addToast('Atividade reagendada', `Movido para ${formatDatePtBR(newDate)} às ${newStartTime}`, 'success');
  };

  // Timer Start
  const handleStartTimer = (item: CalendarItem) => {
    setActiveTimerItemId(item.id);
    setTimerSeconds(0);
    setIsTimerRunning(true);
    setSelectedItemId(item.id);
    addToast('Sessão de foco iniciada', `Focando em "${item.title}"`, 'sparkles');
  };

  // Stop Timer / Finish session
  const handleStopTimer = () => {
    if (!activeTimerItem) return;
    setIsTimerRunning(false);
    setFinishingItem(activeTimerItem);
    setFinishingDuration(timerSeconds);
    setIsExecutionLogModalOpen(true);
  };

  // Save Execution Record
  const handleSaveExecution = (item: CalendarItem, record: ExecutionRecord) => {
    const updated: CalendarItem = {
      ...item,
      status: 'concluido',
      actualExecution: record,
    };
    handleSaveItem(updated);
    setActiveTimerItemId(null);
    setTimerSeconds(0);
    setIsTimerRunning(false);
    addToast('Execução registrada! 🎉', `${record.durationMinutes} minutos dedicados.`, 'success');
  };

  // Accept Ceci Suggestion
  const handleAcceptSuggestion = (suggestion: CeciSuggestion) => {
    const newItem: CalendarItem = {
      id: `sug-item-${Date.now()}`,
      title: suggestion.title,
      type: 'bloco',
      category: suggestion.category,
      categoryLabel: suggestion.category === 'revisao' ? 'Revisão' : 'Estudo',
      layer: suggestion.layer,
      commitment: suggestion.commitment,
      status: 'planejado',
      date: suggestion.targetDate,
      startTime: suggestion.suggestedStartTime,
      endTime: suggestion.suggestedEndTime,
      plannedDurationMinutes: 75,
      etapas: [{ id: `et-${Date.now()}`, title: suggestion.description, completed: false }],
      links: [
        {
          id: `lnk-${Date.now()}`,
          type: suggestion.layer === 'tcc' ? 'tcc' : 'estudos',
          title: suggestion.layer === 'tcc' ? 'TCC • Sugestão' : 'Estudos • Sugestão',
        },
      ],
      notes: `Sugerido pela Ceci: ${suggestion.reason}`,
      googleCalendarSync: {
        synced: true,
        lastSyncedAt: new Date().toISOString(),
        source: 'cecistudy',
      },
    };

    handleSaveItem(newItem);
    setSuggestions((prev) => prev.filter((s) => s.id !== suggestion.id));
    setIsSuggestionsModalOpen(false);
    addToast('Sugestão aplicada', `"${suggestion.title}" adicionado ao seu calendário.`, 'sparkles');
  };

  // Reject Ceci Suggestion
  const handleRejectSuggestion = (suggestionId: string) => {
    setSuggestions((prev) => prev.filter((s) => s.id !== suggestionId));
    addToast('Sugestão dispensada', undefined, 'info');
  };

  // Trigger Google Sync
  const handleTriggerSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setLastSyncedAt('Agora mesmo');
      addToast('Sincronização concluída', 'Eventos do Google Calendar sincronizados.', 'success');
    }, 1200);
  };

  // Intelligent Date Navigation handlers based on active view mode
  const handlePrev = () => {
    if (viewMode === 'semana' || viewMode === 'agenda') {
      setSelectedDate((prev) => addWeeks(prev, -1));
    } else if (viewMode === 'dia') {
      setSelectedDate((prev) => addDays(prev, -1));
    } else if (viewMode === 'mes') {
      setSelectedDate((prev) => addMonths(prev, -1));
    }
  };

  const handleNext = () => {
    if (viewMode === 'semana' || viewMode === 'agenda') {
      setSelectedDate((prev) => addWeeks(prev, 1));
    } else if (viewMode === 'dia') {
      setSelectedDate((prev) => addDays(prev, 1));
    } else if (viewMode === 'mes') {
      setSelectedDate((prev) => addMonths(prev, 1));
    }
  };

  const handleToday = () => {
    const today = getCurrentDateISO();
    setSelectedDate(today);
    addToast('Data atual selecionada', formatDatePtBR(today), 'info');
  };

  // Toggle item status from agenda
  const handleToggleItemStatus = (item: CalendarItem) => {
    const newStatus = item.status === 'concluido' ? 'planejado' : 'concluido';
    handleSaveItem({
      ...item,
      status: newStatus,
    });
  };

  // Copy sample demo items to current week if user is on today and week is empty
  const handlePopulateCurrentWeek = () => {
    const today = getCurrentDateISO();
    const [y, m, d] = today.split('-').map(Number);
    const dayOfWeek = new Date(y, m - 1, d).getDay();
    const distanceToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
    const monday = new Date(y, m - 1, d);
    monday.setDate(monday.getDate() + distanceToMonday);

    const newGeneratedItems: CalendarItem[] = INITIAL_ITEMS.map((item, idx) => {
      const origDayNum = parseInt(item.date.split('-')[2], 10);
      const dayOffset = (origDayNum - 13); // 13 is Monday in initialData
      const targetDate = new Date(monday);
      targetDate.setDate(monday.getDate() + dayOffset);
      const targetISO = `${targetDate.getFullYear()}-${String(targetDate.getMonth() + 1).padStart(2, '0')}-${String(targetDate.getDate()).padStart(2, '0')}`;

      return {
        ...item,
        id: `cur-${targetISO}-${idx}`,
        date: targetISO,
      };
    });

    setItems((prev) => [...prev, ...newGeneratedItems]);
    addToast('Semana populada', 'Estrutura de disciplinas copiada para a semana atual.', 'sparkles');
  };

  return (
    <div id="cecistudy-app" className="flex h-screen w-screen overflow-hidden bg-[#FFFCF8] font-sans antialiased text-[#40383A]">
      {/* 1. Left App Sidebar */}
      <Sidebar
        activeNav={activeNav}
        onNavChange={setActiveNav}
        layers={layers}
        onToggleLayer={handleToggleLayer}
        selectedDate={selectedDate}
        onSelectDate={(date) => {
          setSelectedDate(date);
          if (viewMode === 'mes') {
            setViewMode('dia');
          }
          if (activeNav !== 'calendario') {
            setActiveNav('calendario');
          }
        }}
        onOpenSettings={() => setIsSyncModalOpen(true)}
        onOpenSuggestions={() => setIsSuggestionsModalOpen(true)}
        suggestionsCount={suggestions.length}
        onOpenNewItemModal={() => {
          setEditingItem(null);
          setModalInitialDate(selectedDate);
          setModalInitialTime('08:00');
          setIsItemModalOpen(true);
        }}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenHoursKnowledge={() => setIsHoursModalOpen(true)}
        completedHoursThisWeek={hoursStats.completedHours}
        goalHoursThisWeek={20}
        onStartFocusSession={() => {
          const firstPending = items.find((i) => i.status !== 'concluido' && !i.isAllDay) || items[0];
          if (firstPending) {
            handleStartTimer(firstPending);
          }
        }}
      />

      {/* 2. Main Center Content Area */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden bg-[#FFFCF8]">
        {/* Top Header */}
        <TopHeader
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          selectedDate={selectedDate}
          onPrev={handlePrev}
          onNext={handleNext}
          onToday={handleToday}
          onSelectSpecificDate={(date) => setSelectedDate(date)}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          categoryFilter={categoryFilter}
          onCategoryFilterChange={setCategoryFilter}
          itemsCount={categoryCounts}
          layers={layers}
          onToggleLayer={handleToggleLayer}
          onInviteClick={() => {
            addToast('Compartilhamento acadêmico', 'Link de sincronização copiado para a área de transferência!', 'sparkles');
          }}
          onOpenNewItemModal={() => {
            setEditingItem(null);
            setModalInitialDate(selectedDate);
            setModalInitialTime('08:00');
            setIsItemModalOpen(true);
          }}
          onOpenSyncModal={() => setIsSyncModalOpen(true)}
          onOpenSuggestionsModal={() => setIsSuggestionsModalOpen(true)}
          onOpenHoursModal={() => setIsHoursModalOpen(true)}
          isSyncing={isSyncing}
          suggestionsCount={suggestions.length}
          completedHoursThisWeek={hoursStats.completedHours}
          goalHoursThisWeek={20}
        />

        {/* Calendar / Knowledge View Area */}
        <div className="flex-1 flex min-w-0 overflow-hidden relative">
          {activeNav === 'conhecimento' ? (
            /* Dedicated Knowledge of Hours & Academic Progress View */
            <HoursKnowledgeView
              items={items}
              layers={layers}
              selectedDate={selectedDate}
              onBackToCalendar={() => setActiveNav('calendario')}
              onStartFocusOnSubject={(subjectName) => {
                const subItem = items.find((i) => i.title.toLowerCase().includes(subjectName.toLowerCase()));
                if (subItem) {
                  handleStartTimer(subItem);
                  setActiveNav('calendario');
                } else {
                  setEditingItem(null);
                  setModalInitialDate(selectedDate);
                  setModalInitialTime('10:00');
                  setIsItemModalOpen(true);
                }
              }}
            />
          ) : activeNav === 'calendario' ? (
            <>
              {viewMode === 'semana' && (
                <CalendarWeekView
                  items={filteredItems}
                  layers={layers}
                  selectedDate={selectedDate}
                  selectedItem={selectedItem}
                  onSelectItem={handleSelectItem}
                  onSlotClick={handleSlotClick}
                  onUpdateItemTime={handleUpdateItemTime}
                  activeTimerItemId={activeTimerItemId}
                />
              )}

              {viewMode === 'dia' && (
                <CalendarDayView
                  items={filteredItems}
                  layers={layers}
                  selectedDate={selectedDate}
                  selectedItem={selectedItem}
                  onSelectItem={handleSelectItem}
                  onSlotClick={handleSlotClick}
                  onStartTimer={handleStartTimer}
                  onUpdateItemTime={handleUpdateItemTime}
                  activeTimerItemId={activeTimerItemId}
                />
              )}

              {viewMode === 'mes' && (
                <CalendarMonthView
                  items={filteredItems}
                  layers={layers}
                  selectedDate={selectedDate}
                  selectedItem={selectedItem}
                  onSelectItem={handleSelectItem}
                  onSelectDate={(date) => {
                    setSelectedDate(date);
                    setViewMode('dia');
                  }}
                />
              )}

              {viewMode === 'agenda' && (
                <CalendarAgendaView
                  items={filteredItems}
                  layers={layers}
                  selectedItem={selectedItem}
                  onSelectItem={handleSelectItem}
                  onToggleStatus={handleToggleItemStatus}
                  onStartTimer={handleStartTimer}
                />
              )}
            </>
          ) : (
            /* Dedicated view for other workspace sections */
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#FAF8F5]">
              <div className="w-14 h-14 rounded-2xl bg-[#FFE9EE] text-[#D85F79] flex items-center justify-center text-2xl font-bold mb-4 shadow-sm">
                ♡
              </div>
              <h2 className="text-xl font-bold font-display text-[#40383A] capitalize">
                Módulo de {activeNav}
              </h2>
              <p className="text-xs text-[#918689] max-w-md mt-1 mb-5 leading-relaxed">
                Este espaço está conectado diretamente com suas camadas do calendário acadêmico e banco de horas.
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveNav('conhecimento')}
                  className="px-4 py-2 bg-white hover:bg-[#FAF8F5] border border-[#E9DFDC] text-[#40383A] rounded-xl text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                >
                  Ver Banco de Horas
                </button>
                <button
                  onClick={() => setActiveNav('calendario')}
                  className="px-4 py-2 bg-[#D85F79] hover:bg-[#B94862] text-white rounded-xl text-xs font-semibold shadow-xs transition-all cursor-pointer"
                >
                  Voltar ao Calendário
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Central Event Detail Modal (Replaces side panel) */}
      {selectedItem && (
        <EventDetailModal
          item={selectedItem}
          layers={layers}
          onClose={handleCloseDetailModal}
          onUpdateItem={handleSaveItem}
          onDeleteItem={handleDeleteItem}
          onStartTimer={handleStartTimer}
          onOpenReschedule={handleOpenReschedule}
          onOpenEditModal={(item) => {
            setEditingItem(item);
            setIsItemModalOpen(true);
          }}
          activeTimerItemId={activeTimerItemId}
          activeTimerSeconds={timerSeconds}
          onStopTimer={handleStopTimer}
        />
      )}

      {/* Floating Active Study Timer Banner */}
      <ActiveTimerBanner
        activeItem={activeTimerItem}
        seconds={timerSeconds}
        isRunning={isTimerRunning}
        onTogglePlay={() => setIsTimerRunning(!isTimerRunning)}
        onStopSession={handleStopTimer}
      />

      {/* Command Palette (⌘K) */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        items={items}
        onSelectItem={(item) => {
          setSelectedItemId(item.id);
          setActiveNav('calendario');
        }}
        onViewChange={(view) => {
          setViewMode(view);
          setActiveNav('calendario');
        }}
        onOpenNewItem={() => {
          setEditingItem(null);
          setModalInitialDate(selectedDate);
          setModalInitialTime('08:00');
          setIsItemModalOpen(true);
        }}
        onOpenSuggestions={() => setIsSuggestionsModalOpen(true)}
        onOpenSync={() => setIsSyncModalOpen(true)}
        onNavChange={setActiveNav}
      />

      {/* Toast Notifications */}
      <ToastNotification toasts={toasts} onDismiss={handleDismissToast} />

      {/* Hours Knowledge Analytics Modal */}
      <HoursAnalyticsModal
        isOpen={isHoursModalOpen}
        onClose={() => setIsHoursModalOpen(false)}
        items={items}
        layers={layers}
        selectedDate={selectedDate}
        onGoToKnowledgeView={() => setActiveNav('conhecimento')}
      />

      {/* Modals */}
      <ItemModal
        isOpen={isItemModalOpen}
        initialDate={modalInitialDate}
        initialTime={modalInitialTime}
        editItem={editingItem}
        onClose={() => {
          setIsItemModalOpen(false);
          setEditingItem(null);
        }}
        onSave={handleSaveItem}
      />

      <RescheduleModal
        isOpen={isRescheduleModalOpen}
        item={rescheduleTargetItem}
        onClose={() => {
          setIsRescheduleModalOpen(false);
          setRescheduleTargetItem(null);
        }}
        onConfirm={handleConfirmReschedule}
      />

      <CeciSuggestionsModal
        isOpen={isSuggestionsModalOpen}
        suggestions={suggestions}
        onClose={() => setIsSuggestionsModalOpen(false)}
        onAcceptSuggestion={handleAcceptSuggestion}
        onRejectSuggestion={handleRejectSuggestion}
      />

      <GoogleSyncModal
        isOpen={isSyncModalOpen}
        onClose={() => setIsSyncModalOpen(false)}
        onTriggerSync={handleTriggerSync}
        isSyncing={isSyncing}
        lastSyncedAt={lastSyncedAt}
      />

      <ExecutionLogModal
        isOpen={isExecutionLogModalOpen}
        item={finishingItem}
        durationSeconds={finishingDuration}
        onClose={() => {
          setIsExecutionLogModalOpen(false);
          setFinishingItem(null);
        }}
        onSaveExecution={handleSaveExecution}
      />
    </div>
  );
}
