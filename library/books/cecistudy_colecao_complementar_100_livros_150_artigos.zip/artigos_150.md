# Artigos científicos selecionados — CeciStudy

Coleção de 150 referências científicas, com **15 artigos por família de psicoterapia**. Os resumos são sínteses editoriais em português brasileiro; o campo `link_direto` prioriza DOI e, quando necessário, URL de registro OpenAlex.

## Psicanalítica e psicodinâmica
### 1. Psychosomatic Medicine in Germany: More Timely than Ever

**Autores:** Stephan Zipfel; Wolfgang Herzog; Johannes Kruse; Peter Henningsen  
**Ano:** 2016  
**Periódico:** Psychotherapy and Psychosomatics  
**Classificação:** atual  
**DOI:** https://doi.org/10.1159/000447701  
**Link direto:** [https://doi.org/10.1159/000447701](https://doi.org/10.1159/000447701)

**Resumo:** O artigo descreve a singularidade institucional e histórica da medicina psicossomática na Alemanha, destacando sua autonomia em relação à psiquiatria e seu papel no desenvolvimento acadêmico e clínico da psicoterapia. Examina como departamentos de medicina psicossomática se integraram em contextos médicos e propiciaram modelos de cuidado integrados, em grande parte devido à resistência da psiquiatria alemã em incorporar a psicoterapia como método central. Discute implicações para formação, pesquisa e práticas clínicas contemporâneas.

**Relevância:** Contextualiza institucional e historicamente a presença de abordagens psicodinâmicas e psicoterápicas na prática médica alemã, relevante para a família.

### 2. REBUS and the Anarchic Brain: Toward a Unified Model of the Brain Action of Psychedelics

**Autores:** Robin Carhart‐Harris; Karl Friston  
**Ano:** 2019  
**Periódico:** Pharmacological Reviews  
**Classificação:** atual  
**DOI:** https://doi.org/10.1124/pr.118.017160  
**Link direto:** [https://doi.org/10.1124/pr.118.017160](https://doi.org/10.1124/pr.118.017160)

**Resumo:** Os autores propõem o modelo REBUS (Relaxed Beliefs Under Psychedelics), integrando a hipótese do cérebro entrópico e o princípio de energia livre para explicar como psicodélicos relaxam a precisão de priors de alto nível, permitindo maior influência de sinalizações bottom-up. O artigo reúne evidências neurofisiológicas e fenomenológicas para explicar alterações na consciência e discute implicações terapêuticas, sugerindo que esses estados podem facilitar a revisão de crenças patológicas no contexto de psicoterapias guiadas.

**Relevância:** Relaciona modelos neurobiológicos contemporâneos a conceitos psicanalíticos sobre crenças e representação, relevante para psicodinâmica e processos terapêuticos.

### 3. Therapeutic Alliance and Outcome of Psychotherapy: Historical Excursus, Measurements, and Prospects for Research

**Autores:** Rita B. Ardito; Daniela Rabellino  
**Ano:** 2011  
**Periódico:** Frontiers in Psychology  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.3389/fpsyg.2011.00270  
**Link direto:** [https://doi.org/10.3389/fpsyg.2011.00270](https://doi.org/10.3389/fpsyg.2011.00270)

**Resumo:** Este trabalho faz um percurso histórico sobre o conceito de aliança terapêutica, revisando as principais medidas utilizadas e a relação entre aliança e desfecho psicoterapêutico. Argumenta que a qualidade da aliança é preditora robusta de resultados, independente da abordagem teórica, e propõe atenção às dinâmicas temporais da aliança e à comparação entre avaliações de pacientes e terapeutas. Finaliza com recomendações metodológicas para pesquisas futuras sobre mecanismos relacionais em psicoterapia.

**Relevância:** Explora a aliança terapêutica, conceito central em abordagens psicodinâmicas e psicanalíticas, vinculando processo relacional e resultado clínico.

### 4. The default-mode, ego-functions and free-energy: a neurobiological account of Freudian ideas

**Autores:** Robin Carhart‐Harris; Karl Friston  
**Ano:** 2010  
**Periódico:** Brain  
**Classificação:** clássico/atual  
**DOI:** https://doi.org/10.1093/brain/awq010  
**Link direto:** [https://doi.org/10.1093/brain/awq010](https://doi.org/10.1093/brain/awq010)

**Resumo:** Os autores propõem uma síntese entre conceitos freudianos e neurobiologia contemporânea, sugerindo que processos primários e secundários freudianos correspondem a atividades auto-organizadas em hierarquias corticais e que o ego se relaciona às funções da rede de modo padrão (default mode). A discussão enquadra o cérebro como máquina inferencial que minimiza energia livre, oferecendo um framework neurocomputacional para reinterpretar fenômenos clínicos psicanalíticos como sonhos, psicose e estados alucinógenos.

**Relevância:** Fornece uma ponte teórica entre psicanálise clássica e neurociência, fundamental para integrar modelos psicodinâmicos com evidências biológicas.

### 5. Synchrony in Psychotherapy: A Review and an Integrative Framework for the Therapeutic Alliance

**Autores:** Sander L. Koole; Wolfgang Tschacher  
**Ano:** 2016  
**Periódico:** Frontiers in Psychology  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.3389/fpsyg.2016.00862  
**Link direto:** [https://doi.org/10.3389/fpsyg.2016.00862](https://doi.org/10.3389/fpsyg.2016.00862)

**Resumo:** A revisão sintetiza pesquisas sobre sincronias interpessoais (movimento, voz, fisiologia) entre paciente e terapeuta e propõe o modelo In-Sync para explicar como essas sincronias sustentam a aliança terapêutica. Argumenta que a sincronização comportamental facilita acoplamento inter-cerebral, entendimento mútuo e partilha emocional, o que ao longo do tratamento pode melhorar a regulação afetiva do paciente e os resultados clínicos. O artigo também discute métodos empíricos para avaliar sincronias em contextos terapêuticos.

**Relevância:** Aborda processos de interação e empatia entre terapeuta e paciente, centrais nas teorias psicodinâmicas sobre relação transferencial.

### 6. The effectiveness of psychodynamic psychotherapies: An update

**Autores:** Peter Fonagy  
**Ano:** 2015  
**Periódico:** World Psychiatry  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1002/wps.20235  
**Link direto:** [https://doi.org/10.1002/wps.20235](https://doi.org/10.1002/wps.20235)

**Resumo:** Esta atualização revisa estudos de desfecho e meta-análises sobre psicoterapia psicodinâmica (PDT) em diversos transtornos, apontando eficácia frente a controles inativos em depressão, certos transtornos de ansiedade e alguns problemas somáticos, e forte evidência para tratamentos prolongados de transtornos de personalidade, especialmente borderline. Analisa limitações metodológicas, efeitos de aliança e sugere novas direções integrando biociência e modelos computacionais para modular componentes terapêuticos específicos.

**Relevância:** Revisão-chave sobre evidência de eficácia de intervenções psicodinâmicas, essencial para a família temática.

### 7. Pragmatic randomized controlled trial of long‐term psychoanalytic psychotherapy for treatment‐resistant depression: the Tavistock Adult Depression Study (TADS)

**Autores:** Peter Fonagy; Felicitas Rost; J. B. W. Carlyle; Susan McPherson; Rachel Thomas; Pasco Fearon; David Goldberg; David Taylor  
**Ano:** 2015  
**Periódico:** World Psychiatry  
**Classificação:** ensaio clínico  
**DOI:** https://doi.org/10.1002/wps.20267  
**Link direto:** [https://doi.org/10.1002/wps.20267](https://doi.org/10.1002/wps.20267)

**Resumo:** Este ensaio clínico pragmático randomizado avaliou psicoterapia psicanalítica de longa duração (LTPP) como adjunto ao tratamento usual em depressão resistente, comparando desfechos ao longo de 18 meses de tratamento e seguimento até 42 meses. Embora remissão completa fosse rara ao final do tratamento, diferenças significativas emergiram durante o seguimento favorável ao LTPP em remissão parcial e melhora funcional. O estudo ressalta benefícios tardios da psicoterapia psicanalítica em depressão crônica.

**Relevância:** Ensaio clínico randomizado avaliando psicoterapia psicanalítica de longa duração em depressão resistente, evidência direta para a família.

### 8. Parent-child interaction in the etiology of dependent and self-critical depression

**Autores:** Sidney J. Blatt; Erika Homann  
**Ano:** 1992  
**Periódico:** Clinical Psychology Review  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1016/0272-7358(92)90091-l  
**Link direto:** [https://doi.org/10.1016/0272-7358(92)90091-l](https://doi.org/10.1016/0272-7358(92)90091-l)

**Resumo:** Este trabalho clássico explora como padrões de interação pais-filhos contribuem para a emergência de dois estilos depressivos: dependente e autocrítico. Analisa hipóteses teóricas e evidências empíricas sobre a formação de representações internas e estilos relacionais que predispõem a vulnerabilidades depressivas distintas, com implicações para formulação de caso e intervenções terapêuticas. O artigo influencia práticas psicodinâmicas ao enfatizar trajetórias de desenvolvimento e diferenças individuais na expressão da depressão.

**Relevância:** Clássico sobre gênese psicodinâmica da depressão, fundamental para formulações psicodinâmicas e intervenções.

### 9. Psychological therapies for generalised anxiety disorder

**Autores:** Vivien Hunot; Rachel Churchill; Vanessa Andina Teixeira; Maurício Silva de Lima  
**Ano:** 2007  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1002/14651858.cd001848.pub4  
**Link direto:** [https://doi.org/10.1002/14651858.CD001848.pub4](https://doi.org/10.1002/14651858.CD001848.pub4)

**Resumo:** Esta revisão sistemática Cochrane avaliou ensaios de terapias psicológicas para transtorno de ansiedade generalizada (TAG), comparando CBT, terapia psicodinâmica e terapias de suporte contra tratamento usual e entre si. Concluiu que intervenções baseadas em CBT têm evidência consistente de eficácia a curto prazo; a comparação entre modelos não-CBT é limitada e heterogênea, não permitindo conclusões firmes sobre superioridade de abordagens psicodinâmicas. Destaca necessidade de estudos comparativos de maior qualidade.

**Relevância:** Revisão sistemática que inclui e compara evidência para terapias psicodinâmicas em TAG, relevante para avaliação de eficácia na família.

### 10. Death anxiety and its role in psychopathology: Reviewing the status of a transdiagnostic construct

**Autores:** Lisa Iverach; Ross G. Menzies; Rachel E. Menzies  
**Ano:** 2014  
**Periódico:** Clinical Psychology Review  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1016/j.cpr.2014.09.002  
**Link direto:** [https://doi.org/10.1016/j.cpr.2014.09.002](https://doi.org/10.1016/j.cpr.2014.09.002)

**Resumo:** Esta revisão examina a ansiedade da morte como construto transdiagnóstico, integrando teorias (Terror Management Theory e psicologia existencial), instrumentos de avaliação e estudos sobre tratamento em populações clínicas e não clínicas. Argumenta que a ansiedade da morte é um componente crucial em diversos transtornos (pânico, hipocondria, depressão), e que abordagens terapêuticas específicas podem ser desenvolvidas para tratar este núcleo. Propõe pesquisas controladas em larga escala sobre intervenções direcionadas à ansiedade da morte.

**Relevância:** Discute um tema existencial central em teoria psicodinâmica, útil para formulações e intervenções psicodinâmicas transdiagnósticas.

### 11. Psychedelic-Assisted Psychotherapy: A Paradigm Shift in Psychiatric Research and Development

**Autores:** Eduardo Ekman Schenberg  
**Ano:** 2018  
**Periódico:** Frontiers in Pharmacology  
**Classificação:** estudo brasileiro/atual  
**DOI:** https://doi.org/10.3389/fphar.2018.00733  
**Link direto:** [https://doi.org/10.3389/fphar.2018.00733](https://doi.org/10.3389/fphar.2018.00733)

**Resumo:** O artigo revisa evidências emergentes sobre psicoterapias assistidas por psicodélicos (PAP) como inovação no tratamento de transtornos psiquiátricos, destacando resultados promissores em condições refratárias. Discute implicações para diagnóstico, modelos explicativos e a integração de estados não ordinários de consciência na prática clínica. Aborda segurança, desenho de protocolos e a importância do setting terapêutico, defendendo que PAP pode reconfigurar abordagens psicoterápicas e suscitar diálogos entre neurociência, psicologia e práticas psicoterápicas tradicionais.

**Relevância:** Reúne uma perspectiva contemporânea e nacional sobre psicoterapias assistidas por substâncias, conectando processos psicodinâmicos e experiências profundas terapêuticas.

### 12. Mindfulness and Emotion Regulation: Insights from Neurobiological, Psychological, and Clinical Studies

**Autores:** Simón Guendelman; Sebastián Medeiros; Hagen Rampes  
**Ano:** 2017  
**Periódico:** Frontiers in Psychology  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.3389/fpsyg.2017.00220  
**Link direto:** [https://doi.org/10.3389/fpsyg.2017.00220](https://doi.org/10.3389/fpsyg.2017.00220)

**Resumo:** A revisão integra achados neurobiológicos, psicológicos e clínicos sobre mindfulness e estratégias de regulação emocional. Diferencia mecanismos top-down e bottom-up associados a intervenções baseadas em mindfulness, discute alterações funcionais e estruturais em regiões ligadas à atenção, regulação afetiva e processamento autorreferencial, e propõe um quadro de regulação emocional incorporada. O artigo coloca MBIs em diálogo com outras estratégias psicoterápicas e discute implicações para intervenção clínica em transtornos de regulação emocional.

**Relevância:** Oferece perspectivas sobre regulação emocional que complementam formulações psicodinâmicas sobre afeto, defesa e integração self/outros.

### 13. “Third‐wave” cognitive and behavioral therapies and the emergence of a process‐based approach to intervention in psychiatry

**Autores:** Steven C. Hayes; Stefan G. Hofmann  
**Ano:** 2021  
**Periódico:** World Psychiatry  
**Classificação:** atual  
**DOI:** https://doi.org/10.1002/wps.20884  
**Link direto:** [https://doi.org/10.1002/wps.20884](https://doi.org/10.1002/wps.20884)

**Resumo:** O artigo revisa a evolução das terapias de "terceira onda" e defende uma mudança para intervenções baseadas em processos, em lugar de protocolos categóricos por síndrome. Discute cinco características centrais dessas abordagens (foco em contexto e função, integração com CBT anterior, ampliação para repertórios flexíveis, aplicação ao clínico e expansão para temas mais complexos) e propõe uma taxonomia de processos de mudança. Argumenta que esse movimento favorece análises idiográficas e personalização terapêutica em psiquiatria.

**Relevância:** Promove um enfoque por processos que dialoga com a atenção psicodinâmica a mecanismos terapêuticos e personalização clínica.

### 14. Borderline personality disorder: a comprehensive review of diagnosis and clinical presentation, etiology, treatment, and current controversies

**Autores:** Falk Leichsenring; Peter Fonagy; Nikolas Heim; Otto F. Kernberg; Frank Leweke; Patrick Luyten; Simone Salzer; Carsten Spitzer  
**Ano:** 2024  
**Periódico:** World Psychiatry  
**Classificação:** revisão sistemática/atual  
**DOI:** https://doi.org/10.1002/wps.21156  
**Link direto:** [https://doi.org/10.1002/wps.21156](https://doi.org/10.1002/wps.21156)

**Resumo:** Esta revisão abrangente atualiza critérios diagnósticos, apresentação clínica, etiologia e opções de tratamento para transtorno de personalidade borderline (TPB). Sintetiza evidências sobre terapias com suporte empírico (DBT, MBT, transference-focused therapy, schema therapy), destaca a influência de fatores genéticos e adversidades na infância e discute lacunas no conhecimento, incluindo respostas heterogêneas ao tratamento e necessidade de estudos comparativos. Enfatiza o papel central da psicoterapia como tratamento de escolha.

**Relevância:** Revisão essencial sobre TPB que integra e discute várias terapias psicodinâmicas e suas evidências, diretamente relevante à família.

### 15. Why Cognitive Behavioral Therapy Is the Current Gold Standard of Psychotherapy

**Autores:** Daniel David; Ioana A. Cristea; Stefan G. Hofmann  
**Ano:** 2018  
**Periódico:** Frontiers in Psychiatry  
**Classificação:** atual  
**DOI:** https://doi.org/10.3389/fpsyt.2018.00004  
**Link direto:** [https://doi.org/10.3389/fpsyt.2018.00004](https://doi.org/10.3389/fpsyt.2018.00004)

**Resumo:** Artigo de opinião que discute razões históricas, metodológicas e empíricas pelas quais a terapia cognitivo-comportamental (TCC) se consolidou como padrão-ouro na psicoterapia. Aborda fatores como padronização de protocolos, evidência a partir de ECRs e disseminação em serviços de saúde. Também reflete sobre limitações e aponta para a necessidade de integrar processos comuns e avanços teóricos para ampliar eficácia e aplicabilidade terapêutica.

**Relevância:** Oferece contraponto crítico e contextualiza debates sobre evidência e protocolos, relevante para avaliação comparativa de abordagens psicodinâmicas.

## Existencial e humanista
### 1. Outcomes of religious and spiritual adaptations to psychotherapy: A meta-analytic review

**Autores:** Timothy B. Smith, Jeremy D. Bartz, P. Scott Richards  
**Ano:** 2007  
**Periódico:** Psychotherapy Research  
**Classificação:** meta-análise; atual  
**DOI:** https://doi.org/10.1080/10503300701250347  
**Link direto:** [https://doi.org/10.1080/10503300701250347](https://doi.org/10.1080/10503300701250347)

**Resumo:** Meta-análise de 31 estudos (1984–2005) que avaliou adaptações religiosas e espirituais em psicoterapias para diversos quadros clínicos, encontrando tamanho de efeito médio ponderado de 0,56. O trabalho conclui que intervenções psicoterapêuticas com ênfase espiritual podem beneficiar pacientes com depressão, ansiedade, estresse e transtornos alimentares, e descreve limitações metodológicas e recomendações para pesquisas futuras que integrem dimensão espiritual de forma controlada e sistemática.

**Relevância:** Meta-análise relevante por articular espiritualidade e prática clínica, tema central nas abordagens existencial-humanistas.

### 2. Research on experiential psychotherapies

**Autores:** Robert Elliott, Leslie S. Greenberg, Germain Lietaer  
**Ano:** 2004  
**Periódico:** Strathprints: The University of Strathclyde institutional repository  
**Classificação:** revisão sistemática; clássico  
**DOI:** não informado  
**Link direto:** [https://openalex.org/W1761179631](https://openalex.org/W1761179631)

**Resumo:** Revisão ampla sobre psicoterapias experiencial ou humanistas, incluindo análise de resultados e processos de mudança. Relata grandes efeitos pré-pós e efeitos controlados comparáveis a outras abordagens, e discute evidências a favor da equivalência terapêutica entre HEP (humanistic-experiential psychotherapies) e terapias não-experienciais. Aponta lacunas metodológicas e prioridades para pesquisa futura sobre mecanismos de mudança experiencial.

**Relevância:** Revisão seminal que sintetiza evidências de psicoterapias experiencial/humanistas, base para a família existencial-humanista.

### 3. Research on Humanistic- Experiential Psychotherapies

**Autores:** Robert Elliott, Leslie S. Greenberg, Jeanne C. Watson, Ladislav Timulák, Elizabeth Freire  
**Ano:** 2013  
**Periódico:** Strathprints: The University of Strathclyde institutional repository  
**Classificação:** revisão sistemática/meta-análise; estudo brasileiro  
**DOI:** não informado  
**Link direto:** [https://openalex.org/W2131061793](https://openalex.org/W2131061793)

**Resumo:** Capítulo revisional com meta-análise de quase 200 estudos até 2008, oferecendo síntese sobre eficácia, grupos clínicos atendidos, pesquisa qualitativa e processos de mudança em psicoterapias humanísticas-experienciais. Integra achados anteriores, avalia evidências sobre diferentes modalidades e discute implicações para formação, prática e políticas. Fornece visão abrangente e atualizada da literatura HEP, incluindo sugestões metodológicas para avanços futuros.

**Relevância:** Meta-análise extensa que consolida a evidência sobre psicoterapias humanísticas-experienciais, incluindo contribuição de autor(a) brasileiro(a).

### 4. Therapists’ experiences of relational depth: A qualitative interview study

**Autores:** Mick Cooper  
**Ano:** 2005  
**Periódico:** Counselling and Psychotherapy Research  
**Classificação:** clássico; atual  
**DOI:** https://doi.org/10.1080/17441690500211130  
**Link direto:** [https://doi.org/10.1080/17441690500211130](https://doi.org/10.1080/17441690500211130)

**Resumo:** Estudo qualitativo que explora a experiência de terapeutas ao atingirem 'profundidade relacional' — sentimento de contato profundo, empatia e aceitação mútua. Realizadas entrevistas não estruturadas com terapeuta-centristas experientes, o trabalho descreve estados de imersão, clareza perceptual, reciprocidade e satisfação clínica, discutindo relações com conceitos como presença e flow. Oferece implicações para compreensão fenomenológica da relação terapêutica em abordagens humanistas.

**Relevância:** Analisa aprofundamento relacional central às terapias centradas na pessoa e outras abordagens humanistas.

### 5. Humanizing Psychotherapy

**Autores:** Mick Cooper  
**Ano:** 2006  
**Periódico:** Journal of Contemporary Psychotherapy  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1007/s10879-006-9029-6  
**Link direto:** [https://doi.org/10.1007/s10879-006-9029-6](https://doi.org/10.1007/s10879-006-9029-6)

**Resumo:** Artigo que argumenta pela importância de humanizar práticas psicoterapêuticas, enfatizando condições relacionais, autenticidade e foco na singularidade do cliente. Discute crítica às abordagens tecnicistas e propõe retorno a valores humanísticos como centralidade da pessoa, presença terapêutica e ética. Oferece reflexões teóricas e implicações práticas para formação e prática clínica na tradição existencial-humanista.

**Relevância:** Posicionamento teórico que reitera princípios centrais da família existencial-humanista e sua aplicabilidade clínica.

### 6. An adjudicated hermeneutic single-case efficacy design study of experiential therapy for panic/phobia

**Autores:** Robert Elliott, Rhea Partyka, Rebecca Alperin, Robert Dobrenski, John A. Wagner, Stanley B. Messer, Jeanne C. Watson, Louis G. Castonguay  
**Ano:** 2009  
**Periódico:** Psychotherapy Research  
**Classificação:** atual  
**DOI:** https://doi.org/10.1080/10503300902905947  
**Link direto:** [https://doi.org/10.1080/10503300902905947](https://doi.org/10.1080/10503300902905947)

**Resumo:** Estudo de caso único com design hermenêutico-adjudicado que avaliou 23 sessões de terapia processual-experiencial para um paciente com pânico/fobia. Equipes afirmativas e céticas elaboraram argumentos sobre mudança terapêutica; juízes independentes avaliaram e favoreceram a evidência de mudança atribuível à terapia. O trabalho ilustra metodologia interpretativa rigorosa para inferir eficácia em estudos clínicos intensivos e destaca processos experiencial-emocionais como motores de mudança.

**Relevância:** Exemplo metodológico e empírico de avaliação de terapias experiencial/emocionais típicas da família existencial-humanista.

### 7. Phenomenological psychology and qualitative research

**Autores:** Magnus Englander, James Morley  
**Ano:** 2021  
**Periódico:** Phenomenology and the Cognitive Sciences  
**Classificação:** atual; revisão sistemática (metodologia)  
**DOI:** https://doi.org/10.1007/s11097-021-09781-8  
**Link direto:** [https://doi.org/10.1007/s11097-021-09781-8](https://doi.org/10.1007/s11097-021-09781-8)

**Resumo:** Artigo metodológico que apresenta a tradição fenomenológica em pesquisa psicológica, especialmente o método desenvolvido por Amedeo Giorgi. Descreve a racionalidade de coleta de dados adaptativa, o procedimento de análise 'todo-parte-todo' em cinco passos e exemplifica com análise de um devaneio ansioso relacionado à pandemia. Discute como a fenomenologia sustenta uma psicologia humana autônoma e fornece guia prático para estudos qualitativos em abordagens existenciais-humanistas.

**Relevância:** Fornece metodologia qualitativa fenomenológica essencial para investigar experiências e processos centrais às terapias existencial-humanistas.

### 8. Emotional Processing, Interaction Process, and Outcome in Clarification-Oriented Psychotherapy for Personality Disorders: A Process-Outcome Analysis

**Autores:** Uëli Kramer, Antonio Pascual‐Leone, Kristina Rohde, Rainer Sachse  
**Ano:** 2015  
**Periódico:** Journal of Personality Disorders  
**Classificação:** atual  
**DOI:** https://doi.org/10.1521/pedi_2015_29_204  
**Link direto:** [https://doi.org/10.1521/pedi_2015_29_204](https://doi.org/10.1521/pedi_2015_29_204)

**Resumo:** Análise de processo–resultado em 39 pacientes com transtornos de personalidade submetidos à Clarification-Oriented Psychotherapy (COP). Avaliou processamento emocional (CAMS) e qualidade da interação terapeuta-paciente (BIBS) na sessão 25, correlacionando com mudança sintomática. Casos com bom desfecho mostraram maior autocompaixão, raiva rejeitora e melhor responsividade terapêutica; processamento emocional previu 18% da variação sintomática, sugerindo mecanismos emocionais centrais nas terapias experiencial-humanistas.

**Relevância:** Estudo empírico sobre mecanismos emocionais em terapia experiencial, esclarecendo processos relevantes para a família existencial-humanista.

### 9. Personal Therapy for Future Therapists: Reflections on a Still Debated Issue

**Autores:** Maria Malikiosi‐Loizos  
**Ano:** 2013  
**Periódico:** The European Journal of Counselling Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.5964/ejcop.v2i1.4  
**Link direto:** [https://doi.org/10.5964/ejcop.v2i1.4](https://doi.org/10.5964/ejcop.v2i1.4)

**Resumo:** Revisão crítica sobre a exigência e o papel da terapia pessoal na formação de conselheiros e psicólogos. Examina argumentos pró e contra, define conceitos de desenvolvimento pessoal versus terapia, resume evidências disponíveis e discute formas de garantir profundidade adequada do trabalho pessoal em programas de formação. Oferece reflexão importante sobre ética, competência e preparo emocional de futuros terapeutas nas tradições humanistas e experiencialistas.

**Relevância:** Discussão sobre terapia pessoal na formação é central para preservação dos valores humanistas e competências relacionais na família.

### 10. Using the Developmental Counseling and Therapy Model to Work With a Client in Spiritual Bypass: Some Preliminary Considerations

**Autores:** Craig S. Cashwell, Jane E. Myers, W. Matthew Shurts  
**Ano:** 2004  
**Periódico:** Journal of Counseling & Development  
**Classificação:** atual  
**DOI:** https://doi.org/10.1002/j.1556-6678.2004.tb00327.x  
**Link direto:** [https://doi.org/10.1002/j.1556-6678.2004.tb00327.x](https://doi.org/10.1002/j.1556-6678.2004.tb00327.x)

**Resumo:** Artigo que define o conceito de 'spiritual bypass' — uso da espiritualidade para evitar questões emocionais — e propõe o Modelo de Desenvolvimento em Counseling e Terapia para avaliar e intervir. Discute riscos de validar bypass espiritual em contextos clínicos e fornece orientações práticas para conduzir avaliação, fomentar desenvolvimento emocional autêntico e integrar espiritualidade de forma saudável na intervenção terapêutica, tema relevante para práticas existencial-humanistas sensíveis ao sagrado.

**Relevância:** Aponta interseção entre espiritualidade e intervenção terapêutica, importante para abordagens existenciais e humanistas.

### 11. Current Perspective on the Therapeutic Preset for Substance-Assisted Psychotherapy

**Autores:** Sascha Thal, Stephen Bright, Jason M. Sharbanee, Tobias Wenge, Petra Skeffington  
**Ano:** 2021  
**Periódico:** Frontiers in Psychology  
**Classificação:** atual; revisão sistemática (narrativa)  
**DOI:** https://doi.org/10.3389/fpsyg.2021.617224  
**Link direto:** [https://doi.org/10.3389/fpsyg.2021.617224](https://doi.org/10.3389/fpsyg.2021.617224)

**Resumo:** Revisão narrativa que sintetiza pré-condições, fundamentos teóricos e práticas recomendadas para condução de psicoterapias assistidas por substâncias (SAPT). Discute ênfase espiritual, considerações éticas, modelos terapêuticos e potenciais mediadores (intra- e interpessoais) da eficácia, argumentando que o contexto terapêutico e variáveis relacionais podem ser determinantes. Oferece base para desenvolvimento de modelos e formação clínica integrando dimensões existenciais e humanistas.

**Relevância:** Relaciona práticas terapêuticas com ênfase espiritual/relacional às tradições existencial-humanistas; relevante para novas modalidades clínicas.

### 12. Drawing on the Arts to Enhance Salutogenic Coping With Health-Related Stress and Loss

**Autores:** Ephrat Huss, Tali Samson  
**Ano:** 2018  
**Periódico:** Frontiers in Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.3389/fpsyg.2018.01612  
**Link direto:** [https://doi.org/10.3389/fpsyg.2018.01612](https://doi.org/10.3389/fpsyg.2018.01612)

**Resumo:** Estudo qualitativo em grupo de apoio para pacientes oncológicos que mapeia processos arteterapêuticos segundo o modelo salutogênico (sentido, manejabilidade, compreensibilidade). Analisou 50 horas de processos e 100 obras, mostrando que as artes promovem integração e concretização de significado e capacidade de enfrentamento corpóreo e relacional. Propõe protocolo e discute implicações teóricas para uso das artes como método terapêutico na promoção de bem-estar em contextos existenciais.

**Relevância:** Mostra como práticas artísticas encarnam mecanismos de sentido e coping, centrais à abordagem existencial-humanista.

### 13. The Effectiveness of Trauma-Focused Psychodrama in the Treatment of PTSD in Inpatient Substance Abuse Treatment

**Autores:** Scott Giacomucci, Joshua Marquit  
**Ano:** 2020  
**Periódico:** Frontiers in Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.3389/fpsyg.2020.00896  
**Link direto:** [https://doi.org/10.3389/fpsyg.2020.00896](https://doi.org/10.3389/fpsyg.2020.00896)

**Resumo:** Estudo pré–pós sem grupo controle que avaliou modelos de psicodrama focado em trauma (Therapeutic Spiral Model, Relational Trauma Repair) em ambiente residencial de dependência. Relatou reduções clinicamente significativas (>25%) nos sintomas de PTSD e em seus clusters, além de alta satisfação e relatos de segurança emocional e coesão grupal. Embora promissor, reconhecimento das limitações metodológicas (ausência de controle) e necessidade de replicação controlada são enfatizados.

**Relevância:** Exemplo contemporâneo de intervenção experiencial-emocional (psicodrama) aplicável a contextos clínicos humanistas.

### 14. Effects of Rational-Emotive Hospice Care Therapy on Problematic Assumptions, Death Anxiety, and Psychological Distress in a Sample of Cancer Patients and Their Family Caregivers in Nigeria

**Autores:** Kay Chinonyelum Nwamaka Onyechi, Liziana N. Onuigbo, Chiedu Eseadi, Amaka B. Ikechukwu-Ilomuanya, Okechukwu O. Nwaubani, Prince Christian Ifeanachor Umoke, Fedinand U. Agu, Mkpoikanke Sunday Otu  
**Ano:** 2016  
**Periódico:** International Journal of Environmental Research and Public Health  
**Classificação:** ensaio clínico; atual  
**DOI:** https://doi.org/10.3390/ijerph13090929  
**Link direto:** [https://doi.org/10.3390/ijerph13090929](https://doi.org/10.3390/ijerph13090929)

**Resumo:** Ensaio randomizado preliminar que testou a terapia racional-emotiva aplicada a cuidados paliativos (REHCT) em pacientes com câncer e seus cuidadores comunitários na Nigéria. Dez semanas de intervenção reduziram pressupostos disfuncionais, ansiedade diante da morte e sofrimento psicológico, mantendo ganhos no follow-up. O estudo demonstra aplicabilidade de intervenções psicoterapêuticas focadas em significado e ansiedade existencial em contextos culturais diversos.

**Relevância:** Aborda ansiedade existencial e cuidado paliativo, temas centrais à família existencial-humanista, com evidência controlada.

### 15. Some Applied Implications of a Contemporary Behavior-Analytic Account of Verbal Events

**Autores:** Steven C. Hayes, Kelly G. Wilson  
**Ano:** 1993  
**Periódico:** The Behavior Analyst  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1007/bf03392637  
**Link direto:** [https://doi.org/10.1007/bf03392637](https://doi.org/10.1007/bf03392637)

**Resumo:** Texto clássico que discute implicações aplicadas de uma análise comportamental contemporânea de eventos verbais, alicerçando princípios que mais tarde sustentariam terapias de 'terceira onda' como ACT. Explora relações entre linguagem, função contextual e intervenção clínica, oferecendo bases teóricas para integrar aceitação, valores e presença — conceitos que dialogam com dimensões existenciais e humanistas na prática terapêutica contemporânea.

**Relevância:** Marco teórico que influencia abordagens contextuais/aceitação conectadas a temas existenciais relevantes para a família.

## Comportamental
### 1. Rethinking Rumination

**Autores:** Susan Nolen–Hoeksema, Blair E. Wisco, Sonja Lyubomirsky  
**Ano:** 2008  
**Periódico:** Perspectives on Psychological Science  
**Classificação:** clássico; atual  
**DOI:** https://doi.org/10.1111/j.1745-6924.2008.00088.x  
**Link direto:** [https://doi.org/10.1111/j.1745-6924.2008.00088.x](https://doi.org/10.1111/j.1745-6924.2008.00088.x)

**Resumo:** Este artigo revisita a teoria dos estilos de resposta e sintetiza evidências de que a ruminação exacerba a depressão, amplia pensamentos negativos, prejudica resolução de problemas e reduz suporte social. Discute achados contraditórios, diferenças entre ruminação e reflexão adaptativa, e associações transdiagnósticas (ansiedade, comportamento alimentar, abuso de substâncias e automutilação). Aborda também mecanismos cognitivos, correlatos neurais e possíveis intervenções para reduzir ruminação, oferecendo direções para pesquisa aplicada e clínica.

**Relevância:** Fundamental para compreender processos transdiagnósticos de regulação emocional e alvos interventivos comportamentais.

### 2. On psychological growth and vulnerability: Basic psychological need satisfaction and need frustration as a unifying principle.

**Autores:** Maarten Vansteenkiste, Richard M. Ryan  
**Ano:** 2013  
**Periódico:** Journal of Psychotherapy Integration  
**Classificação:** atual  
**DOI:** https://doi.org/10.1037/a0032359  
**Link direto:** [https://doi.org/10.1037/a0032359](https://doi.org/10.1037/a0032359)

**Resumo:** Este trabalho integra a Teoria da Autodeterminação ao propor que a satisfação das necessidades básicas (autonomia, competência, relacionamento) promove bem-estar e resiliência, enquanto a frustração dessas necessidades favorece vulnerabilidade psicopatológica. Revisam evidências experimentais e correlacionais, diferenciando efeitos imediatos e de longo prazo, e discutem mecanismos como autorregulação e atenção plena. Oferece um enquadramento teórico útil para intervenções comportamentais que visam apoiar contextos e práticas terapêuticas que favorecem a internalização e o crescimento.

**Relevância:** Fornece base teórica para intervenções comportamentais que visam promover motivação e regulação adaptativa.

### 3. Mindfulness Interventions

**Autores:** J. David Creswell  
**Ano:** 2016  
**Periódico:** Annual Review of Psychology  
**Classificação:** atual; revisão sistemática  
**DOI:** https://doi.org/10.1146/annurev-psych-042716-051139  
**Link direto:** [https://doi.org/10.1146/annurev-psych-042716-051139](https://doi.org/10.1146/annurev-psych-042716-051139)

**Resumo:** Revisão abrangente das intervenções baseadas em mindfulness, avaliando efeitos em saúde física e mental, mecanismos psicológicos e neurobiológicos, dosagem e riscos potenciais. Sintetiza evidência de ensaios controlados randomizados que mostram benefícios para dor crônica, prevenção de recaída depressiva e dependência, e discute aplicações em contextos como escolas e local de trabalho. Identifica lacunas metodológicas e orienta prioridades futuras em pesquisa translacional e implementação clínica.

**Relevância:** Revisa evidências e mecanismos de intervenções comportamentais contemplativas amplamente usadas em práticas clínicas.

### 4. Mind the Hype: A Critical Evaluation and Prescriptive Agenda for Research on Mindfulness and Meditation

**Autores:** Nicholas T. Van Dam, Marieke K. van Vugt, David R. Vago, Laura Schmalzl, Clifford D. Saron, Andrew Olendzki, Ted Meissner, Sara W. Lazar  
**Ano:** 2017  
**Periódico:** Perspectives on Psychological Science  
**Classificação:** atual  
**DOI:** https://doi.org/10.1177/1745691617709589  
**Link direto:** [https://doi.org/10.1177/1745691617709589](https://doi.org/10.1177/1745691617709589)

**Resumo:** Artigo crítico que avalia limitações metodológicas e alegações excessivas sobre benefícios da mindfulness e meditação. Discute problemas de definição, instrumentos de medida, desenhos experimentais frágeis, possíveis efeitos adversos e interpretações exageradas de neuroimagem. Propõe uma agenda prescritiva para fortalecer a pesquisa contemplativa, incluindo melhores medidas, protocolos controlados, avaliação de riscos e maior transparência. Visa orientar cientistas, mídia e público para reduzir danos e melhorar a qualidade das evidências.

**Relevância:** Crítica metodológica essencial para avaliar validade e implementação de intervenções comportamentais baseadas em mindfulness.

### 5. Psychological therapies for the management of chronic pain (excluding headache) in adults

**Autores:** Amanda C de C Williams, Christopher Eccleston, Stephen Morley  
**Ano:** 2012  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1002/14651858.cd007407.pub3  
**Link direto:** [https://doi.org/10.1002/14651858.cd007407.pub3](https://doi.org/10.1002/14651858.cd007407.pub3)

**Resumo:** Revisão sistemática Cochrane que sintetiza 75 ECRs sobre tratamentos psicológicos para dor crônica em adultos. Compara TCC, terapia comportamental e ACT contra controles ativos e TAU, avaliando dor, incapacidade e sofrimento. Encontra benefícios pequenos a moderados para TCC versus TAU, resultados variados para BT e evidência limitada para ACT. Discute qualidade metodológica, heterogeneidade e sub-regiões clínicas, além da insuficiência de dados sobre eventos adversos e necessidade de estudos mais rigorosos.

**Relevância:** Avaliação de alto nível sobre eficácia de intervenções comportamentais em dor crônica, guiando prática e pesquisa.

### 6. Introducing compassion-focused therapy

**Autores:** Paul Gilbert  
**Ano:** 2009  
**Periódico:** Advances in Psychiatric Treatment  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1192/apt.bp.107.005264  
**Link direto:** [https://doi.org/10.1192/apt.bp.107.005264](https://doi.org/10.1192/apt.bp.107.005264)

**Resumo:** Apresenta a terapia focada em compaixão (CFT) como abordagem integrativa para vergonha e autocrítica transdiagnósticas. Fundamentada em modelagens evolutivas, desenvolvimento e neurociência afetiva, a CFT visa ativar sistemas de cuidado e regulação emocional por meio de treino de compaixão, imaginação e experiências corporais de segurança. Descreve princípios, técnicas fundamentais e indicações clínicas, propondo a CFT como complemento valioso às intervenções comportamentais para populações com alta autocrítica.

**Relevância:** Oferece abordagem comportamental-afetiva dirigida a alvos transdiagnósticos como vergonha e autocrítica.

### 7. Self-awareness, self-regulation, and self-transcendence (S-ART): a framework for understanding the neurobiological mechanisms of mindfulness

**Autores:** David R. Vago, David Silbersweig  
**Ano:** 2012  
**Periódico:** Frontiers in Human Neuroscience  
**Classificação:** atual  
**DOI:** https://doi.org/10.3389/fnhum.2012.00296  
**Link direto:** [https://doi.org/10.3389/fnhum.2012.00296](https://doi.org/10.3389/fnhum.2012.00296)

**Resumo:** Propõe o modelo S-ART para articular como práticas de mindfulness cultivam meta-consciência (autoconsciência), autorregulação e auto-transcendência, modulando redes neurais sistêmicas. Discute processos como atenção, regulação emocional, extinção, reconsolidação e prosocialidade, integrando evidências neurocientíficas e psicológicas. O framework sugere como a prática meditativa pode reduzir vieses de auto-processamento e orientar intervenções terapêuticas que visam mudanças sustentadas na organização cognitivo-afetiva e no comportamento clínico.

**Relevância:** Modelo neurocomportamental útil para desenvolver e interpretar intervenções baseadas em atenção e regulação.

### 8. The growing field of digital psychiatry: current evidence and the future of apps, social media, chatbots, and virtual reality

**Autores:** John Torous, Sandra Bucci, Imogen Bell, Lars Vedel Kessing, Maria Faurholt‐Jepsen, Pauline Whelan, André F. Carvalho, Matcheri S. Keshavan  
**Ano:** 2021  
**Periódico:** World Psychiatry  
**Classificação:** atual; revisão sistemática  
**DOI:** https://doi.org/10.1002/wps.20883  
**Link direto:** [https://doi.org/10.1002/wps.20883](https://doi.org/10.1002/wps.20883)

**Resumo:** Revisão que traça o panorama da psiquiatria digital, cobrindo apps móveis, chatbots, redes sociais e realidade virtual. Analisa evidências sobre fenotipagem digital, intervenções remotas e eficácia emergente em depressão, ansiedade, transtornos psicóticos, uso de substâncias e saúde juvenil. Discute desafios de implementação, interoperabilidade, ética e escalabilidade, propondo quadros de implementação (i-PARIHS) para integração ao cuidado clínico e sugerindo prioridades para validar e aplicar tecnologias comportamentais digitais.

**Relevância:** Relevante para aplicações comportamentais digitais e escalabilidade de intervenções terapêuticas.

### 9. Suicide and suicide risk

**Autores:** Gustavo Turecki, David A. Brent, David Gunnell, Rory C. O’Connor, María A. Oquendo, Jane Pirkis, Bárbara Stanley  
**Ano:** 2019  
**Periódico:** Nature Reviews Disease Primers  
**Classificação:** revisão sistemática; atual  
**DOI:** https://doi.org/10.1038/s41572-019-0121-0  
**Link direto:** [https://doi.org/10.1038/s41572-019-0121-0](https://doi.org/10.1038/s41572-019-0121-0)

**Resumo:** Revisão abrangente sobre suicídio e fatores de risco, integrando epidemiologia, etiologia, marcadores biológicos, fatores psicossociais e estratégias de prevenção. Aborda avaliação de risco, mecanismos neurobiológicos e implicações para intervenções clínicas e políticas públicas. Destaca evidências sobre rastreamento, intervenções baseadas em psicoterapia e programas populacionais, enfatizando necessidades de pesquisa translacional para reduzir mortalidade por suicídio através de abordagens preventivas e terapêuticas informadas por dados.

**Relevância:** Integra evidências essenciais para intervenções comportamentais e prevenção do suicídio.

### 10. Mental Health Smartphone Apps: Review and Evidence-Based Recommendations for Future Developments

**Autores:** David Bakker, Nikolaos Kazantzis, Debra Rickwood, Nikki S. Rickard  
**Ano:** 2016  
**Periódico:** JMIR Mental Health  
**Classificação:** atual; revisão sistemática  
**DOI:** https://doi.org/10.2196/mental.4984  
**Link direto:** [https://doi.org/10.2196/mental.4984](https://doi.org/10.2196/mental.4984)

**Resumo:** Revisão que examina a proliferação de aplicativos de saúde mental, identificando lacunas na validação experimental e propondo 16 recomendações baseadas em evidências para desenvolvimento mais robusto. Discute desenho interactivo, planos comportamentais, engajamento do usuário e necessidade de ECRs para validação. Alerta para a falta de dados sobre segurança e eficácia na maioria dos apps, oferecendo orientações práticas para pesquisadores e desenvolvedores interessados em intervenções comportamentais digitais eficazes.

**Relevância:** Direciona desenvolvimento e avaliação de intervenções comportamentais móveis e escaláveis.

### 11. All for One and One for All: Mental Disorders in One Dimension

**Autores:** Avshalom Caspi, Terrie E. Moffitt  
**Ano:** 2018  
**Periódico:** American Journal of Psychiatry  
**Classificação:** clássico; atual  
**DOI:** https://doi.org/10.1176/appi.ajp.2018.17121383  
**Link direto:** [https://doi.org/10.1176/appi.ajp.2018.17121383](https://doi.org/10.1176/appi.ajp.2018.17121383)

**Resumo:** Artigo conceitual que sintetiza evidências a favor do fator geral de psicopatologia (p), análogo ao g da inteligência, que explica comorbidade, persistência e gravidade dos transtornos. Mostra que escores elevados em p se associam a histórico familiar, funcionamento cerebral alterado e maiores prejuízos funcionais. Discute implicações transdiagnósticas para prevenção, pesquisa e terapia, sugerindo que alvos comuns podem explicar respostas terapêuticas não específicas entre diferentes tratamentos comportamentais.

**Relevância:** Suporta abordagem transdiagnóstica em intervenções comportamentais e pesquisa de mecanismos comuns.

### 12. The Mentalizing Approach to Psychopathology: State of the Art and Future Directions

**Autores:** Patrick Luyten, Chloë Campbell, Elizabeth Allison, Peter Fonagy  
**Ano:** 2020  
**Periódico:** Annual Review of Clinical Psychology  
**Classificação:** atual; revisão sistemática  
**DOI:** https://doi.org/10.1146/annurev-clinpsy-071919-015355  
**Link direto:** [https://doi.org/10.1146/annurev-clinpsy-071919-015355](https://doi.org/10.1146/annurev-clinpsy-071919-015355)

**Resumo:** Revisa a abordagem de mentalização (capacidade de inferir estados mentais próprios e alheios) aplicada à psicopatologia, descrevendo dimensões do mentalizar e desequilíbrios associados a transtornos. Aborda evidência para tratamentos baseados em mentalização, principalmente em transtornos de personalidade, e amplia a discussão a depressão, ansiedade e transtornos alimentares. Apresenta princípios de tratamentos, resultados empíricos e direções futuras, promovendo a mentalização como conceito transtheórico útil para intervenções comportamentais.

**Relevância:** Aplica um quadro transtheórico para terapia comportamental centrada na regulação interpessoal e mental.

### 13. The Lancet Psychiatry Commission on psychological treatments research in tomorrow's science

**Autores:** Emily A. Holmes, Ata Ghaderi, Catherine J. Harmer, Paul Ramchandani, Pim Cuijpers, Anthony P. Morrison, Jonathan P. Roiser, Claudi Bockting  
**Ano:** 2018  
**Periódico:** The Lancet Psychiatry  
**Classificação:** atual; revisão sistemática  
**DOI:** https://doi.org/10.1016/S2215-0366(17)30513-8  
**Link direto:** [https://doi.org/10.1016/S2215-0366(17)30513-8](https://doi.org/10.1016/S2215-0366(17)30513-8)

**Resumo:** Comissão que avalia o estado da pesquisa em tratamentos psicológicos e propõe uma agenda para a ciência futura, enfatizando métodos robustos, replicabilidade, mecanismos de mudança, personalização e tradução para prática clínica. Discute integração de novas tecnologias, medidas de processos, desenhos experimentais inovadores e colaboração interdisciplinar para melhorar eficácia e implementação. Fornece recomendações para fortalecer a evidência das intervenções comportamentais e otimizar sua utilidade na saúde mental global.

**Relevância:** Marco orientador para pesquisa e melhoria metodológica em intervenções comportamentais.

### 14. Acceptance and commitment therapy and mindfulness for chronic pain: Model, process, and progress.

**Autores:** Lance M. McCracken, Kevin E. Vowles  
**Ano:** 2014  
**Periódico:** American Psychologist  
**Classificação:** atual; revisão sistemática  
**DOI:** https://doi.org/10.1037/a0035623  
**Link direto:** [https://doi.org/10.1037/a0035623](https://doi.org/10.1037/a0035623)

**Resumo:** Revisão teórico-empírica sobre ACT e abordagens mindfulness no manejo da dor crônica, delineando modelos de processo, evidência empírica e direções de pesquisa. Os autores discutem como aceitação, descentramento e compromisso com ações valiosas atuam como mecanismos de mudança, comparando com TCC tradicional e destacando mediadores e moderadores. Propõe estratégias para aprimorar intervenções e medir processos terapêuticos visando melhorar resultados funcionais e qualidade de vida de pacientes com dor crônica.

**Relevância:** Relevante para abordagens comportamentais de aceitação e atenção aplicadas à dor e regulação emocional.

### 15. Positive and Negative Emotion Regulation in Adolescence: Links to Anxiety and Depression

**Autores:** Katherine S. Young, Christina F. Sandman, Michelle G. Craske  
**Ano:** 2019  
**Periódico:** Brain Sciences  
**Classificação:** atual  
**DOI:** https://doi.org/10.3390/brainsci9040076  
**Link direto:** [https://doi.org/10.3390/brainsci9040076](https://doi.org/10.3390/brainsci9040076)

**Resumo:** Revisão sobre desenvolvimento de habilidades de regulação emocional na adolescência e suas ligações com ansiedade e depressão. Integra achados de autorrelato, comportamentais, psicofisiológicos e neuroimagem, destacando alterações em circuitos amígdala–pré-frontal e déficits em estratégias como reavaliação. Discute inconsistências metodológicas e recomenda a focalização em estratégias específicas em intervenções, além de promover estudos que isolem regulação de reatividade, com implicações práticas para programas preventivos e terapêuticos direcionados a jovens.

**Relevância:** Importante para adaptar intervenções comportamentais à fase adolescente e aos mecanismos de regulação.

## Cognitiva / TCC
### 1. The Psychology of Change: Self-Affirmation and Social Psychological Intervention

**Autores:** Geoffrey L. Cohen, David K. Sherman  
**Ano:** 2014  
**Periódico:** Annual Review of Psychology  
**Classificação:** estudo de intervenção ou resultados clínicos  
**DOI:** https://doi.org/10.1146/annurev-psych-010213-115137  
**Link direto:** [https://doi.org/10.1146/annurev-psych-010213-115137](https://doi.org/10.1146/annurev-psych-010213-115137)

**Resumo:** Artigo relacionado ao tema “The Psychology of Change: Self-Affirmation and Social Psychological Intervention”, relevante para o estudo de fundamentos, processos ou resultados da família 04_cognitiva_tcc. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 04_cognitiva_tcc, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 2. Time for united action on depression: a Lancet–World Psychiatric Association Commission

**Autores:** Helen Herrman, Vikram Patel, Christian Kieling, Michael Berk, Claudia Buchweitz, Pim Cuijpers, Toshiaki A Furukawa, Ronald C Kessler  
**Ano:** 2022  
**Periódico:** The Lancet  
**Classificação:** atual  
**DOI:** https://doi.org/10.1016/s0140-6736(21)02141-3  
**Link direto:** [https://doi.org/10.1016/s0140-6736(21)02141-3](https://doi.org/10.1016/s0140-6736(21)02141-3)

**Resumo:** Artigo relacionado ao tema “Time for united action on depression: a Lancet–World Psychiatric Association Commission”, relevante para o estudo de fundamentos, processos ou resultados da família 04_cognitiva_tcc. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 04_cognitiva_tcc, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 3. Effectiveness of a Novel Integrative Online Treatment for Depression (Deprexis): Randomized Controlled Trial

**Autores:** Björn Meyer, Thomas Berger, Franz Caspar, Christopher G. Beevers, Gerhard Andersson, Mario Weiss  
**Ano:** 2009  
**Periódico:** Journal of Medical Internet Research  
**Classificação:** ensaio clínico,atual  
**DOI:** https://doi.org/10.2196/jmir.1151  
**Link direto:** [https://doi.org/10.2196/jmir.1151](https://doi.org/10.2196/jmir.1151)

**Resumo:** Ensaio clínico randomizado avaliando Deprexis, intervenção online integrativa para depressão que combina ativação comportamental, reestruturação cognitiva, exercícios de mindfulness e treino social. Em amostra recrutada pela internet, o programa reduziu significativamente sintomas depressivos e melhorou funcionamento social ao final de 9 semanas, com efeitos mantidos em seguimento de seis meses. Resultados sugerem eficácia como tratamento adjunto ou autônomo, evidenciando viabilidade de intervenções psicoterapêuticas digitais baseadas em princípios cognitivo‑comportamentais.

**Relevância:** Exemplo robusto de TCC integrada entregue online, relevante para intervenções digitais em saúde mental.

### 4. Therapist-supported Internet cognitive behavioural therapy for anxiety disorders in adults

**Autores:** Janine V. Olthuis, Margo C. Watt, Kristen Bailey, Jill A. Hayden, Sherry H Stewart  
**Ano:** 2016  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** revisão sistemática,atual  
**DOI:** https://doi.org/10.1002/14651858.cd011565.pub2  
**Link direto:** [https://doi.org/10.1002/14651858.cd011565.pub2](https://doi.org/10.1002/14651858.cd011565.pub2)

**Resumo:** Revisão sistemática Cochrane que avalia os efeitos da TCC via internet com suporte de terapeuta para transtornos de ansiedade em adultos. A síntese de 38 ensaios (3214 participantes) indica que ICBT com suporte melhora sintomas de ansiedade e qualidade de vida em comparação a lista de espera, com evidências limitadas de diferença para TCC presencial. A revisão destaca heterogeneidade dos protocolos, qualidade variável e necessidade de estudos de longa duração e em contextos diversos.

**Relevância:** Avalia evidência da entrega digital da TCC, importante para modelos de tratamento acessível e escalável.

### 5. Behavioural activation for depression

**Autores:** David Veale  
**Ano:** 2007  
**Periódico:** Advances in Psychiatric Treatment  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1192/apt.bp.107.004051  
**Link direto:** [https://doi.org/10.1192/apt.bp.107.004051](https://doi.org/10.1192/apt.bp.107.004051)

**Resumo:** Artigo que descreve a ativação comportamental como terapia focal para depressão, enfatizando programação de atividades, análise funcional e redução de esquemas de evitação como mecanismos centrais. O texto discute a justificativa teórica, evidência empírica e implementação clínica, destacando vantagens práticas como facilidade de treinamento e aplicação em ambientes diversos. Fornece orientação prática para formulação e intervenções que reengajam pacientes com metas e reforçamento comportamental, alinhadas a abordagens cognitivas contemporâneas.

**Relevância:** Texto essencial sobre ativação comportamental, componente central de TCC para depressão.

### 6. Mindfulness Broadens Awareness and Builds Eudaimonic Meaning: A Process Model of Mindful Positive Emotion Regulation

**Autores:** Eric L. Garland, Norman A. S. Farb, Philippe R. Goldin, Barbara L. Fredrickson  
**Ano:** 2015  
**Periódico:** Psychological Inquiry  
**Classificação:** atual  
**DOI:** https://doi.org/10.1080/1047840x.2015.1064294  
**Link direto:** [https://doi.org/10.1080/1047840x.2015.1064294](https://doi.org/10.1080/1047840x.2015.1064294)

**Resumo:** Proposta teórica da "mindfulness-to-meaning" que descreve como mindfulness amplia a atenção interoceptiva e cognitiva, facilitando reavaliações adaptativas e o savoring de experiências positivas. O modelo integra evidências afetivas e cognitivas para explicar como prática contemplativa leva à regulação positiva das emoções e aumento do significado e engajamento vital. Implicações clínicas incluem incorporar práticas de atenção plena em intervenções que visam ampliação emocional e reconstrução cognitiva.

**Relevância:** Oferece um modelo processual útil para integrar mindfulness em estratégias cognitivas de reavaliação e promoção de bem‑estar.

### 7. Potential self-regulatory mechanisms of yoga for psychological health

**Autores:** Tim Gard, Jessica J. Noggle, Crystal L. Park, David R. Vago, Angela L. Wilson  
**Ano:** 2014  
**Periódico:** Frontiers in Human Neuroscience  
**Classificação:** atual  
**DOI:** https://doi.org/10.3389/fnhum.2014.00770  
**Link direto:** [https://doi.org/10.3389/fnhum.2014.00770](https://doi.org/10.3389/fnhum.2014.00770)

**Resumo:** Revisão teórica que propõe um modelo integrativo sobre como práticas de yoga promovem saúde psicológica por meio da integração de processos de autorregulação top‑down e bottom‑up, interocepção e mudança nos padrões de percepção preditiva. Os autores discutem evidências sobre efeitos cognitivos, emocionais, comportamentais e autonômicos, sugerindo que yoga pode automatizar respostas adaptativas ao estresse e complementar intervenções cognitivas ao trabalhar vias corporais e de atenção.

**Relevância:** Explica mecanismos somáticos que podem complementar TCC e intervenções baseadas em atenção e autorregulação.

### 8. Body Awareness: a phenomenological inquiry into the common ground of mind-body therapies

**Autores:** Wolf Mehling, Judith Wrubel, Jennifer Daubenmier, Cynthia Price, Catherine E. Kerr, Theresa Silow, Viranjini Gopisetty, Anita L. Stewart  
**Ano:** 2011  
**Periódico:** Philosophy Ethics and Humanities in Medicine  
**Classificação:** atual  
**DOI:** https://doi.org/10.1186/1747-5341-6-6  
**Link direto:** [https://doi.org/10.1186/1747-5341-6-6](https://doi.org/10.1186/1747-5341-6-6)

**Resumo:** Investigação qualitativa sobre a percepção corporal como elemento compartilhado em terapias mente‑corpo (yoga, Tai Chi, mindfulness, entre outras). A análise de grupos focais com praticantes e pacientes destaca a consciência corporal como elo entre corpo e self, praticada através de atenção interoceptiva, ação e interação ambiental. Os autores descrevem um processo terapêutico que promove integração, autorregulação e coesão somato‑psicológica, oferecendo base conceitual para incorporar treino de awareness em terapias cognitivas contemporâneas.

**Relevância:** Define conceitos de consciência corporal relevantes para mecanismos de mudança em intervenções cognitivo‑comportamentais integradas.

### 9. Preventing occupational stress in healthcare workers

**Autores:** Jani Ruotsalainen, Jos Verbeek, A Mariné, Cònsol Serra  
**Ano:** 2015  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** revisão sistemática,atual  
**DOI:** https://doi.org/10.1002/14651858.cd002892.pub5  
**Link direto:** [https://doi.org/10.1002/14651858.cd002892.pub5](https://doi.org/10.1002/14651858.cd002892.pub5)

**Resumo:** Revisão Cochrane sobre intervenções destinadas a prevenir estresse ocupacional em profissionais de saúde, incluindo treinamentos cognitivo‑comportamentais, organização do trabalho e suporte social. A revisão sintetiza evidências sobre eficácia de programas preventivos e destaca intervenções baseadas em habilidades de enfrentamento e regulação emocional como promissoras, embora haja variabilidade metodológica e necessidade de estudos longitudinais que avaliem resultados clínicos e organizacionais sustentados.

**Relevância:** Importante para aplicações da TCC em contextos ocupacionais e programas preventivos para profissionais de saúde.

### 10. Psychological therapies for people with borderline personality disorder (update)

**Autores:** Ole Jakob Storebø, Jutta Stoffers‐Winterling, Birgit Vӧllm, Mickey Kongerslev, Jessica T. Mattivi, Mie Sedoc Jørgensen, Erlend Faltinsen, Adnan Todorovac  
**Ano:** 2020  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** revisão sistemática,atual  
**DOI:** https://doi.org/10.1002/14651858.cd012955.pub2  
**Link direto:** [https://doi.org/10.1002/14651858.cd012955.pub2](https://doi.org/10.1002/14651858.cd012955.pub2)

**Resumo:** Atualização Cochrane que revisa 75 ECRs (4507 participantes) sobre psicoterapias para transtorno de personalidade borderline (BPD). A síntese mostra que psicoterapias específicas (DBT, MBT, schema therapy, entre outras) reduzem severidade de sintomas e podem diminuir autolesão em comparação ao tratamento habitual. Evidência varia por desfecho e abordagem; autores ressaltam qualidade moderada a baixa em muitas comparações e necessidade de estudos que esclareçam quais subgrupos beneficiam de cada modalidade.

**Relevância:** Crucial para fundamentar escolhas terapêuticas em transtornos de personalidade onde TCC e modalidades derivadas são empregadas.

### 11. Psychological therapies for people with borderline personality disorder

**Autores:** Jutta Stoffers‐Winterling, Birgit Vӧllm, Gerta Rücker, Antje Timmer, Nick Huband, Klaus Lieb  
**Ano:** 2012  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** revisão sistemática,clássico  
**DOI:** https://doi.org/10.1002/14651858.cd005652.pub2  
**Link direto:** [https://doi.org/10.1002/14651858.cd005652.pub2](https://doi.org/10.1002/14651858.cd005652.pub2)

**Resumo:** Revisão Cochrane original que avaliou a eficácia de diversas psicoterapias para BPD versus tratamento habitual, lista de espera ou outras terapias. Com inclusão de múltiplos RCTs, os autores encontraram redução clínica relevante na gravidade dos sintomas com psicoterapia. O trabalho estabeleceu base para evidência de DBT e MBT, discutindo limitações metodológicas e a necessidade de comparações entre intervenções especializadas e estudos que avaliem efeitos adversos e aderência terapêutica.

**Relevância:** Revisão seminal que consolidou a evidência de psicoterapias específicas usadas em contextos cognitivo‑comportamentais para BPD.

### 12. The plasticity of well-being: A training-based framework for the cultivation of human flourishing

**Autores:** Cortland J. Dahl, Christine D. Wilson‐Mendenhall, Richard J. Davidson  
**Ano:** 2020  
**Periódico:** Proceedings of the National Academy of Sciences  
**Classificação:** atual  
**DOI:** https://doi.org/10.1073/pnas.2014859117  
**Link direto:** [https://doi.org/10.1073/pnas.2014859117](https://doi.org/10.1073/pnas.2014859117)

**Resumo:** Síntese teórica que identifica quatro dimensões cultiváveis do bem‑estar — consciência, conexão, insight e propósito — e descreve mecanismos neurais e psicológicos que respondem a treinamentos mentais. Os autores integram evidências de intervenções contemplativas, terapêuticas e de reabilitação, propondo um arcabouço para desenvolver programas que promovam florescimento humano. A estrutura informa desenvolvimento e avaliação de intervenções cognitivo‑comportamentais que visam além da redução de sintomas, promovendo bem‑estar positivo.

**Relevância:** Oferece quadro integrador para incorporar treino de bem‑estar em protocolos TCC orientados para promoção positiva.

### 13. Social Safety Theory: A Biologically Based Evolutionary Perspective on Life Stress, Health, and Behavior

**Autores:** George M. Slavich  
**Ano:** 2020  
**Periódico:** Annual Review of Clinical Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.1146/annurev-clinpsy-032816-045159  
**Link direto:** [https://doi.org/10.1146/annurev-clinpsy-032816-045159](https://doi.org/10.1146/annurev-clinpsy-032816-045159)

**Resumo:** Proposta teórica evolucionária que coloca a segurança social no centro da regulação neurocognitiva e imunológica do estresse. Slavich argumenta que ameaças à segurança social ativam respostas neurais e inflamatórias que elevam risco para transtornos mentais e doenças físicas. O artigo integra evidências de psicologia, neurociência e imunologia, sugerindo que intervenções psicoterapêuticas (incluindo estratégias cognitivas e de regulação emocional) podem mitigar efeitos biológicos de ameaças sociais.

**Relevância:** Conecta perigo social e processos biológicos, importante para formulações clínicas em TCC centradas em isolamento e rejeição.

### 14. Resilience in mental health: linking psychological and neurobiological perspectives

**Autores:** Bart P. F. Rutten, Caroline Hammels, Nicole Geschwind, Claudia Menne‐Lothmann, Ehsan Pishva, Koen Schruers, Daniël van den Hove, Günter Kenis  
**Ano:** 2013  
**Periódico:** Acta Psychiatrica Scandinavica  
**Classificação:** atual  
**DOI:** https://doi.org/10.1111/acps.12095  
**Link direto:** [https://doi.org/10.1111/acps.12095](https://doi.org/10.1111/acps.12095)

**Resumo:** Revisão integrativa das evidências psicológicas e biológicas da resiliência, definindo fatores que favorecem adaptação positiva após adversidade. Destacam‑se apego seguro, emoções positivas e sentido de propósito como componentes psicológicos-chave, além de interações gene‑ambiente que modulam sensibilidade ao estresse. A revisão discute implicações para intervenções psicoterapêuticas que visam fortalecer mecanismos de resiliência, reforçando a importância de abordagens cognitivas e comportamentais que promovam regulação emocional e experiências de recompensa.

**Relevância:** Fornece base multidisciplinar para intervenções TCC destinadas a promover resiliência após adversidades.

### 15. In an Absolute State: Elevated Use of Absolutist Words Is a Marker Specific to Anxiety, Depression, and Suicidal Ideation

**Autores:** Mohammed Al‑Mosaiwi, Tom Johnstone  
**Ano:** 2018  
**Periódico:** Clinical Psychological Science  
**Classificação:** atual  
**DOI:** https://doi.org/10.1177/2167702617747074  
**Link direto:** [https://doi.org/10.1177/2167702617747074](https://doi.org/10.1177/2167702617747074)

**Resumo:** Estudo de análise textual que demonstra que fóruns sobre ansiedade, depressão e ideação suicida apresentam maior uso de palavras absolutistas, um indicador linguístico de pensamento dicotômico. Autores argumentam que tal padrão reflete um viés cognitivo específico (pensamento absolutista) mais do que sentimento negativo geral, sugerindo que medidas linguísticas podem identificar vulnerabilidades cognitivas relevantes para avaliação e intervenção. Achados reforçam foco terapêutico da TCC em distorções cognitivas absolutistas.

**Relevância:** Evidência empírica sobre distorções cognitivas centrais ao modelo TCC, útil para avaliação e formulação clínica.

## Sistêmica, familiar e de casais
### 1. 2021 ESC Guidelines for the diagnosis and treatment of acute and chronic heart failure

**Autores:** Theresa A. McDonagh; Marco Metra; Marianna Adamo; Roy S. Gardner; Andreas Baumbach; Michael Böhm; Haran Burri; Javed Butler  
**Ano:** 2021  
**Periódico:** European Heart Journal  
**Classificação:** atual  
**DOI:** https://doi.org/10.1093/eurheartj/ehab368  
**Link direto:** [https://doi.org/10.1093/eurheartj/ehab368](https://doi.org/10.1093/eurheartj/ehab368)

**Resumo:** As diretrizes ESC 2021 consolidam evidências para o diagnóstico e manejo de insuficiência cardíaca aguda e crônica, abordando avaliação diagnóstica, estratificação de risco, terapias farmacológicas e não farmacológicas e cuidados multidisciplinares. O documento integra novas evidências sobre inibidores do SGLT2, terapias direcionadas e recomendações para o seguimento ambulatório, propondo fluxos clínicos e prioridades para manejo individualizado. É um guia abrangente para a prática clínica cardiovascular moderna, com ênfase em redução de mortalidade e melhoria da qualidade de vida.

**Relevância:** Importante para casais/famílias que convivem com insuficiência cardíaca, orientando intervenções que afetam dinâmica familiar e cuidados compartilhados.

### 2. Surviving Sepsis Campaign: International Guidelines for Management of Severe Sepsis and Septic Shock, 2012

**Autores:** R.P. Dellinger; Mitchell M. Levy; Andrew Rhodes; Djillali Annane; Herwig Gerlach; Steven M. Opal; Jonathan Sevransky; Charles L. Sprung  
**Ano:** 2013  
**Periódico:** Intensive Care Medicine  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1007/s00134-012-2769-8  
**Link direto:** [https://doi.org/10.1007/s00134-012-2769-8](https://doi.org/10.1007/s00134-012-2769-8)

**Resumo:** As diretrizes Surviving Sepsis 2012 atualizam recomendações para diagnóstico precoce, ressuscitação hemodinâmica, controle de foco infeccioso e uso racional de antibióticos em sepse grave e choque séptico. Baseadas em método Delphi e GRADE, abordam metas de resuscitação nas primeiras horas, suporte ventilatório, controle glicêmico e uso de vasopressores e corticosteroides em cenários específicos. O documento visa padronizar condutas para reduzir mortalidade e morbilidade em pacientes criticamente doentes.

**Relevância:** Sepse grave altera papéis e decisões familiares; diretrizes orientam intervenções clínicas que impactam comunicação e suporte entre casais e familiares.

### 3. Surviving Sepsis Campaign: International Guidelines for Management of Sepsis and Septic Shock: 2016

**Autores:** Andrew Rhodes; Laura Evans; Waleed Alhazzani; Mitchell M. Levy; Massimo Antonelli; Ricard Ferrer; Anand Kumar; Jonathan Sevransky  
**Ano:** 2017  
**Periódico:** Intensive Care Medicine  
**Classificação:** atual  
**DOI:** https://doi.org/10.1007/s00134-017-4683-6  
**Link direto:** [https://doi.org/10.1007/s00134-017-4683-6](https://doi.org/10.1007/s00134-017-4683-6)

**Resumo:** A atualização de 2016 das diretrizes Surviving Sepsis fornece 93 enunciados sobre manejo precoce da sepse e choque séptico, com recomendações fortes e fracas fundamentadas em revisão sistemática e GRADE. Cobre hemodinâmica, infecção, terapias adjuntas, manejo metabólico e ventilatório, enfatizando intervenções iniciais, administração oportuna de antibióticos e metas de pressão arterial. O documento serve como referência internacional para otimizar desfechos em unidades de terapia intensiva.

**Relevância:** Atualiza práticas críticas que influenciam decisões familiares em crises médicas e planejamento de cuidados entre parceiros.

### 4. Surviving sepsis campaign: international guidelines for management of sepsis and septic shock 2021

**Autores:** Laura Evans; Andrew Rhodes; Waleed Alhazzani; Massimo Antonelli; Craig M. Coopersmith; Craig French; Flávia Ribeiro Machado; Lauralyn McIntyre  
**Ano:** 2021  
**Periódico:** Intensive Care Medicine  
**Classificação:** atual  
**DOI:** https://doi.org/10.1007/s00134-021-06506-y  
**Link direto:** [https://doi.org/10.1007/s00134-021-06506-y](https://doi.org/10.1007/s00134-021-06506-y)

**Resumo:** As diretrizes Surviving Sepsis 2021 sintetizam evidências recentes sobre reconhecimento precoce, ressuscitação, antibióticos, suporte orgânico e medidas de follow-up em pacientes com sepse e choque séptico. Atualizações incluem recomendações sobre estratégias de fluido, vasopressores, manejo de glicemia e cuidados subsequentes, com foco em implementação prática e qualidade de atendimento. O documento reforça a necessidade de abordagem multidisciplinar e comunicação efetiva com famílias durante a trajetória crítica do paciente.

**Relevância:** Fornece base para suporte a famílias e decisões compartilhadas em situação de sepse, afetando papéis conjugais e cuidados familiares.

### 5. Fourth universal definition of myocardial infarction (2018)

**Autores:** Kristian Thygesen; Joseph S. Alpert; Allan S. Jaffe; Bernard Chaitman; Jeroen J. Bax; David A. Morrow; Harvey D. White; ESC Scientific Document Group  
**Ano:** 2018  
**Periódico:** European Heart Journal  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1093/eurheartj/ehy462  
**Link direto:** [https://doi.org/10.1093/eurheartj/ehy462](https://doi.org/10.1093/eurheartj/ehy462)

**Resumo:** A quarta definição universal de infarto do miocárdio (2018) padroniza critérios diagnósticos baseados em biomarcadores, sinais eletrocardiográficos e achados clínicos e imagiológicos, distinguindo tipos e mecanismos de IAM. O documento contextualiza evolução histórica, limitações de definições anteriores e propõe critérios para uso clínico e pesquisa, com implicações para terapia aguda, prevenção secundária e comunicação entre equipes. Visa uniformizar relatos e melhorar comparabilidade de estudos cardiovasculares.

**Relevância:** Critérios diagnósticos de IAM são essenciais para comunicar prognóstico e decisões de cuidado que impactam dinâmica e planejamento familiar entre parceiros.

### 6. Heart Disease and Stroke Statistics—2013 Update

**Autores:** Alan S. Go; Dariush Mozaffarian; Véronique L. Roger; Emelia J. Benjamin; Jarett D. Berry; William B. Borden; Dawn M. Bravata; Shifan Dai  
**Ano:** 2012  
**Periódico:** Circulation  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1161/cir.0b013e31828124ad  
**Link direto:** [https://doi.org/10.1161/cir.0b013e31828124ad](https://doi.org/10.1161/cir.0b013e31828124ad)

**Resumo:** O relatório estatístico AHA 2013 compila dados epidemiológicos sobre doenças cardiovasculares e acidente vascular cerebral, incluindo incidência, prevalência, fatores de risco, mortalidade, qualidade de cuidados e custos. Oferece análise de tendências temporais e capítulos sobre prevenção, intervenção e impacto populacional. Serve como referência para pesquisadores, gestores e clínicos na formulação de políticas e estratégias de prevenção, além de sublinhar a carga socioeconômica dessas doenças.

**Relevância:** Dados epidemiológicos ajudam a compreender impacto das doenças cardiovasculares na estrutura e nas responsabilidades dos casais e famílias.

### 7. Vascular Contributions to Cognitive Impairment and Dementia

**Autores:** Philip B. Gorelick; Angelo Scuteri; Sandra E. Black; Charles DeCarli; Steven M. Greenberg; Costantino Iadecola; Lenore J. Launer; Stéphane Laurent  
**Ano:** 2011  
**Periódico:** Stroke  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1161/str.0b013e3182299496  
**Link direto:** [https://doi.org/10.1161/str.0b013e3182299496](https://doi.org/10.1161/str.0b013e3182299496)

**Resumo:** Esta declaração científica revisa evidências sobre como lesões vasculares cerebrais contribuem para comprometimento cognitivo e demência, discutindo neuropatologia, neuroimagem, fatores de risco e oportunidades de prevenção/tratamento. Enfatiza interação entre doença vascular e Alzheimer, mecanismos da neurovascular unit e importância do controle de fatores vasculares para reduzir risco cognitivo. Oferece recomendações transdisciplinares para pesquisa e prática clínica visando prevenção de perda funcional e impacto social.

**Relevância:** Demência e déficit cognitivo têm efeitos profundos na dinâmica conjugal e responsabilidades familiares, crucial para intervenções sistêmicas.

### 8. ESC/EAS Guidelines for the management of dyslipidaemias

**Autores:** Željko Reiner; Alberico L. Catapano; Guy De Backer; Ian Graham; Marja‑Riitta Taskinen; Olov Wiklund; Stefan Agewall; Eduardo Alegría  
**Ano:** 2011  
**Periódico:** European Heart Journal  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1093/eurheartj/ehr158  
**Link direto:** [https://doi.org/10.1093/eurheartj/ehr158](https://doi.org/10.1093/eurheartj/ehr158)

**Resumo:** As diretrizes ESC/EAS (2011) abordam prevenção e manejo de dislipidemias como componente central da prevenção cardiovascular, detalhando avaliação de risco, metas lipídicas, terapias farmacológicas, estilo de vida e estratégias para populações especiais. O documento integra evidências sobre uso de estatinas, terapia combinada e medidas não farmacológicas, buscando reduzir eventos cardiovasculares e mortalidade por meio de políticas clínicas e educação do paciente.

**Relevância:** Controle de fatores de risco lipídico envolve mudanças de estilo de vida que dependem de apoio familiar e decisões conjuntas entre parceiros.

### 9. Characteristics of SARS-CoV-2 and COVID-19

**Autores:** Ben Hu; Hua Guo; Peng Zhou; Zheng‑Li Shi  
**Ano:** 2020  
**Periódico:** Nature Reviews Microbiology  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1038/s41579-020-00459-7  
**Link direto:** [https://doi.org/10.1038/s41579-020-00459-7](https://doi.org/10.1038/s41579-020-00459-7)

**Resumo:** Revisão abrangente sobre a biologia do SARS-CoV-2 e as características clínicas, epidemiológicas e patológicas da COVID-19, incluindo diferenças genômicas e uso de receptor viral, modelos animais e abordagens antivirais. Discute origem zoonótica potencial e avanços rápidos em diagnóstico e tratamento nos primeiros estágios da pandemia. O texto sintetiza conhecimento essencial para entendimento da doença e fundamenta medidas de saúde pública e clínicas.

**Relevância:** Pandemia modificou dinâmicas familiares e conjugais, exigindo adaptações no cuidado mútuo e gerenciamento de risco dentro de casais.

### 10. The trinity of COVID-19: immunity, inflammation and intervention

**Autores:** Matthew Zirui Tay; Chek Meng Poh; Laurent Rénia; Paul A. MacAry; Lisa F. P. Ng  
**Ano:** 2020  
**Periódico:** Nature Reviews Immunology  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1038/s41577-020-0311-8  
**Link direto:** [https://doi.org/10.1038/s41577-020-0311-8](https://doi.org/10.1038/s41577-020-0311-8)

**Resumo:** Esta revisão sintetiza mecanismos imunológicos e inflamatórios centrais na COVID-19 e discute estratégias terapêuticas emergentes. Aborda resposta imune inata e adaptativa, tempestade de citocinas, compromissos teciduais e implicações para intervenções farmacológicas e vacinais. O artigo integra dados pré-clínicos e clínicos para orientar desenvolvimento de tratamentos e compreender heterogeneidade de apresentações clínicas da doença.

**Relevância:** Entender mecanismos e intervenções é relevante para decisões familiares sobre risco, isolamento e cuidado de parceiros em contexto de doença infecciosa.

### 11. Gut microbiota in human metabolic health and disease

**Autores:** Yong Fan; Oluf Pedersen  
**Ano:** 2020  
**Periódico:** Nature Reviews Microbiology  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1038/s41579-020-0433-9  
**Link direto:** [https://doi.org/10.1038/s41579-020-0433-9](https://doi.org/10.1038/s41579-020-0433-9)

**Resumo:** Revisão sobre o papel do microbioma intestinal na saúde metabólica humana e nas doenças associadas, descrevendo mecanismos de interação microbe-hospedeiro que influenciam obesidade, diabetes e inflamação sistêmica. O artigo explora evidências de estudos populacionais e mecanismos moleculares, além de discutir potenciais intervenções dietéticas, prebióticos, probióticos e terapias dirigidas ao microbioma para modular risco metabólico.

**Relevância:** Microbioma e saúde metabólica influenciam padrões alimentares e rotinas familiares, relevantes para intervenções sistêmicas em casais.

### 12. Short Chain Fatty Acids (SCFAs)-Mediated Gut Epithelial and Immune Regulation and Its Relevance for Inflammatory Bowel Diseases

**Autores:** Daniela Parada Venegas; Marjorie K. De la Fuente; Glauben Landskron; María Julieta González; Rodrigo Quera; Gerard Dijkstra; Hermie J. M. Harmsen; Klaas Nico Faber  
**Ano:** 2019  
**Periódico:** Frontiers in Immunology  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.3389/fimmu.2019.00277  
**Link direto:** [https://doi.org/10.3389/fimmu.2019.00277](https://doi.org/10.3389/fimmu.2019.00277)

**Resumo:** A revisão detalha como ácidos graxos de cadeia curta (SCFAs) produzidos por microbiota regulam epitélio intestinal e resposta imune, com foco na fisiopatologia da doença inflamatória intestinal (DII). Discute transporte e sinalização por receptores GPCRs, evidências pré-clínicas e clínicas, redução de SCFAs em DII ativa e potencial terapêutico de intervenções que aumentem produtores de SCFAs ou administração direta como estratégia terapêutica.

**Relevância:** Doenças intestinais crônicas afetam cuidado familiar e rotinas alimentares do casal, sendo relevante para intervenções sistêmicas de suporte.

### 13. Guidelines for the Provision and Assessment of Nutrition Support Therapy in the Adult Critically Ill Patient

**Autores:** Stephen A. McClave; Beth Taylor; Robert G. Martindale; Malissa Warren; Debbie R. Johnson; Carol Braunschweig; Mary S. McCarthy; Evangelia Davanos  
**Ano:** 2016  
**Periódico:** Journal of Parenteral and Enteral Nutrition  
**Classificação:** atual  
**DOI:** https://doi.org/10.1177/0148607115621863  
**Link direto:** [https://doi.org/10.1177/0148607115621863](https://doi.org/10.1177/0148607115621863)

**Resumo:** Diretrizes colaborativas descrevem práticas ideais de suporte nutricional em pacientes críticos adultos, incluindo avaliação nutricional, estimativa de necessidades energéticas e proteicas, preferências por via enteral versus parenteral e uso de calorimetria indireta. Revisam evidências de ensaios clínicos e coortes, sugerindo abordagem individualizada, otimização da nutrição enteral e papel limitado da imunonutrição. Fornecem recomendações práticas para melhorar resultados clínicos em unidades de terapia intensiva.

**Relevância:** Cuidados nutricionais em doença crítica impactam responsabilidades familiares e exigem coordenação entre parceiros e cuidadores.

### 14. Photodynamic therapy of cancer: An update

**Autores:** Patrizia Agostinis; Kristian Berg; Keith A. Cengel; Thomas H. Foster; Albert W. Girotti; Sandra O. Gollnick; Stephen M. Hahn; Michael R. Hamblin  
**Ano:** 2011  
**Periódico:** CA: A Cancer Journal for Clinicians  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.3322/caac.20114  
**Link direto:** [https://doi.org/10.3322/caac.20114](https://doi.org/10.3322/caac.20114)

**Resumo:** Atualização sobre terapia fotodinâmica (PDT) no câncer: mecanismo de ação, agentes fotossensibilizantes, efeitos sobre células tumorais e microvasculatura, resposta inflamatória local e aplicações clínicas. Revisam evidências de eficácia em tumores precoces e avanços tecnológicos que ampliam indicações e combinam PDT com outras modalidades oncológicas. Destacam benefícios como preservação de função orgânica e perfil de toxicidade favorável em tumores selecionados.

**Relevância:** Tratamentos oncológicos afetam decisões familiares e papéis conjugais; PDT destaca opções que podem influenciar qualidade de vida do casal.

### 15. Biological properties of extracellular vesicles and their physiological functions

**Autores:** María Yáñez‑Mó; Pia Siljander; Zoraida Andreu; Apolonija Bedina Zavec; Francesc E. Borràs; Edit I. Buzás; Krisztina Buzás; Enriqueta Casal  
**Ano:** 2015  
**Periódico:** Journal of Extracellular Vesicles  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.3402/jev.v4.27066  
**Link direto:** [https://doi.org/10.3402/jev.v4.27066](https://doi.org/10.3402/jev.v4.27066)

**Resumo:** Revisão abrangente sobre vesículas extracelulares (EVs): composição molecular, biogênese, mecanismos de transporte intercelular e funções fisiológicas em diferentes tecidos e fluidos biológicos. O artigo sintetiza evidências sobre papel das EVs em comunicação celular, homeostase e doenças, incluindo câncer e doenças autoimunes, e discute métodos analíticos e potenciais aplicações diagnósticas e terapêuticas.

**Relevância:** Compreensão de mecanismos biológicos sistêmicos apoia intervenções que afetam saúde familiar e decisões sobre cuidados entre parceiros.

## Construtivista e narrativa
### 1. Michael White's Narrative Therapy

**Autores:** Alan Carr  
**Ano:** 1998  
**Periódico:** Contemporary Family Therapy  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1023/a:1021680116584  
**Link direto:** [https://doi.org/10.1023/a:1021680116584](https://doi.org/10.1023/a:1021680116584)

**Resumo:** Este artigo apresenta uma síntese crítica e introdutória ao trabalho de Michael White sobre terapia narrativa. A partir de princípios construtivistas, discute-se como as histórias pessoais e sociais moldam a experiência de problemas e identidades, e como as práticas terapêuticas de externalização, reauthoring e mapeamento de influência possibilitam a reconstrução de narrativas mais capacitadoras. O texto contextualiza os fundamentos teóricos e oferece exemplos clínicos que traduzem conceitos abstratos em intervenções práticas centradas na linguagem e no significado.

**Relevância:** Texto-chave que apresenta e sistematiza os princípios da terapia narrativa de Michael White, essencial à família construtivista/narrativa.

### 2. Research on the alliance: Knowledge in search of a theory

**Autores:** Adam O. Horvath  
**Ano:** 2017  
**Periódico:** Psychotherapy Research  
**Classificação:** atual  
**DOI:** https://doi.org/10.1080/10503307.2017.1373204  
**Link direto:** [https://doi.org/10.1080/10503307.2017.1373204](https://doi.org/10.1080/10503307.2017.1373204)

**Resumo:** Revisão crítica sobre o desenvolvimento teórico e empírico da aliança terapêutica, identificando desafios conceituais e operacionais na pesquisa contemporânea. O autor sintetiza evidências históricas, descreve divergências na definição do construto e discute como a falta de consenso limita avanços teóricos e metodológicos. Propõe caminhos para integrar diferentes variáveis relacionais e recomenda retomar o diálogo interdisciplinar sobre a relação terapêutica, central para processos de mudança em abordagens construtivistas e narrativas.

**Relevância:** A aliança é um mecanismo central em terapia narrativa/constructivista; este trabalho clarifica conceitos e direções para pesquisa aplicada.

### 3. The responsiveness problem in psychotherapy: A review of proposed solutions.

**Autores:** Uëli Kramer; William B. Stiles  
**Ano:** 2015  
**Periódico:** Clinical Psychology Science and Practice  
**Classificação:** atual  
**DOI:** https://doi.org/10.1111/cpsp.12107  
**Link direto:** [https://doi.org/10.1111/cpsp.12107](https://doi.org/10.1111/cpsp.12107)

**Resumo:** Revisão conceitual sobre o problema da responsividade terapêutica — isto é, como o comportamento do terapeuta se ajusta ao contexto em mudança — e as implicações para teoria e pesquisa em psicoterapia. Os autores categorizam seis estratégias para abordar a responsividade, incluindo medições quantitativas e intervenções clinicamente responsivas, e argumentam que enfrentar o problema exige perguntas e métodos novos. O artigo é relevante para práticas construídas a partir do ajuste contínuo à narrativa do cliente.

**Relevância:** A responsividade é um princípio prático nas abordagens construtivistas/narrativas; o artigo sistematiza soluções metodológicas e clínicas.

### 4. Nonverbal synchrony and affect in dyadic interactions

**Autores:** Wolfgang Tschacher; Georg M. Rees; Fabian Ramseyer  
**Ano:** 2014  
**Periódico:** Frontiers in Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.3389/fpsyg.2014.01323  
**Link direto:** [https://doi.org/10.3389/fpsyg.2014.01323](https://doi.org/10.3389/fpsyg.2014.01323)

**Resumo:** Estudo experimental sobre sincronização não verbal e afetividade em interações díades sob condições cooperativa, competitiva e lúdica. Usando análise automática de movimento, os autores mostraram que maior sincronização corporal correlaciona-se com afeto positivo, especialmente em díades femininas, e que a sincronização tende a preceder mudanças afetivas. Resultados apontam mecanismos de co-regulação interacional relevantes para processos terapêuticos construtivistas, onde a presença corporal e a sintonia não verbal facilitam a construção conjunta de significado.

**Relevância:** Evidência empírica sobre sintonia não verbal como mecanismo que sustenta a co-construção narrativa em intervenções terapêuticas.

### 5. ‘Into the Wild’: A meta-synthesis of talking therapy in natural outdoor spaces

**Autores:** Sam J. Cooley; Ceri Jones; Arabella Kurtz; Noelle Robertson  
**Ano:** 2020  
**Periódico:** Clinical Psychology Review  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1016/j.cpr.2020.101841  
**Link direto:** [https://doi.org/10.1016/j.cpr.2020.101841](https://doi.org/10.1016/j.cpr.2020.101841)

**Resumo:** Meta-síntese qualitativa de 38 estudos sobre terapia falada em espaços naturais, examinando experiências de praticantes e clientes e construindo um quadro de boas práticas. As autoras descrevem como o ambiente externo pode ser incorporado passivamente ou ativamente (por metáforas, role play, terapia narrativa), e identificam benefícios como maior mutualidade, expressão livre e integração mente-corpo. Questões práticas e éticas são discutidas, com recomendações para avaliação, consentimento e competência profissional.

**Relevância:** Mostra aplicação concreta de técnicas narrativas fora do consultório e evidencia sinergias entre contexto ambiental e reauthoring.

### 6. Narrative, identity and mental health: How men with serious mental illness re-story their lives through sport and exercise

**Autores:** David Carless; Kitrina Douglas  
**Ano:** 2007  
**Periódico:** Psychology of Sport and Exercise  
**Classificação:** atual  
**DOI:** https://doi.org/10.1016/j.psychsport.2007.08.002  
**Link direto:** [https://doi.org/10.1016/j.psychsport.2007.08.002](https://doi.org/10.1016/j.psychsport.2007.08.002)

**Resumo:** Investigação qualitativa sobre como homens com transtornos mentais graves usam esporte e exercício para reconstruir identidades e recontar suas vidas. O estudo descreve processos de re-significação, resistência ao estigma e construção de narrativas alternativas que promovem agência e bem-estar. Discute como atividades físicas funcionam como espaços narrativos que permitem experimentação identitária e fortalecem recursos sociais e emocionais, indicando caminhos terapêuticos complementares para intervenções construtivistas centradas na história de vida.

**Relevância:** Exemplifica re-authoring e reconstrução identitária fora do setting clínico, relevante para práticas narrativas.

### 7. Living, resisting, and playing the part of athlete: Narrative tensions in elite sport

**Autores:** David Carless; Kitrina Douglas  
**Ano:** 2013  
**Periódico:** Psychology of Sport and Exercise  
**Classificação:** atual  
**DOI:** https://doi.org/10.1016/j.psychsport.2013.05.003  
**Link direto:** [https://doi.org/10.1016/j.psychsport.2013.05.003](https://doi.org/10.1016/j.psychsport.2013.05.003)

**Resumo:** Artigo qualitativo que explora tensões narrativas vividas por atletas de elite — entre identidades impostas e resistidas — e como essas histórias moldam comportamento, sentido e escolhas. Os autores analisam conflitos entre papéis sociais, expectativas institucionais e agência individual, mostrando como re-significações narrativas sustentam resiliência e bem-estar. O trabalho oferece insights sobre práticas dialogais e construtivistas para apoiar atletas na recriação de narrativas mais integradas e sustentáveis.

**Relevância:** Ilustra como abordagens narrativas ajudam a entender e intervir nas tensões identitárias em contextos específicos.

### 8. Simulating Emotions: An Active Inference Model of Emotional State Inference and Emotion Concept Learning

**Autores:** Ryan Smith; Thomas Parr; Karl Friston  
**Ano:** 2019  
**Periódico:** Frontiers in Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.3389/fpsyg.2019.02844  
**Link direto:** [https://doi.org/10.3389/fpsyg.2019.02844](https://doi.org/10.3389/fpsyg.2019.02844)

**Resumo:** O artigo apresenta um modelo de Inferência Ativa para explicar como agentes aprendem conceitos emocionais e inferem estados afetivos. Simulações mostram aquisição de repertório conceitual em 'infância' e 'idade adulta' e destacam a influência de experiências iniciais, estabilidade ambiental e hábitos atencionais. A modelagem formal oferece uma ponte entre processos computacionais e construtos psicológicos, sugerindo mecanismos para como narrativas e rótulos emocionais se formam e influenciam regulação emocional em terapia construtivista.

**Relevância:** Fornece base teórica e computacional para entender como conceitos emocionais são construídos, relevante para intervenções narrativas.

### 9. Becoming more oneself? Changes in personality following DBS treatment for psychiatric disorders: Experiences of OCD patients and general considerations

**Autores:** Sanneke de Haan; Erik Rietveld; Martin Stokhof; Damiaan Denys  
**Ano:** 2017  
**Periódico:** PLoS ONE  
**Classificação:** atual  
**DOI:** https://doi.org/10.1371/journal.pone.0175748  
**Link direto:** [https://doi.org/10.1371/journal.pone.0175748](https://doi.org/10.1371/journal.pone.0175748)

**Resumo:** Estudo qualitativo com 18 pacientes com TOC submetidos a Estimulação Cerebral Profunda (DBS) que investiga relatos sobre mudanças percebidas na personalidade e no sentido de si. Os autores discutem dificuldades conceituais na definição de 'personalidade' e como efeitos do tratamento influenciam identidade, autonomia e narrativas de vida. A pesquisa contribui para debates éticos e clínicos sobre intervenções biomédicas que alteram trajetórias narrativas individuais e o processo de re-construção do eu.

**Relevância:** Explora impacto biomédico sobre identidade e narrativas pessoais, tema central para a família construtivista/narrativa.

### 10. Meaning in life as a protective factor against suicidal tendencies in Chinese University students

**Autores:** Bob Lew; Ksenia Chistopolskaya; Augustine Osman; Jenny Mei Yiu Huen; Mansor Abu Talib; Angel Nga Man Leung  
**Ano:** 2020  
**Periódico:** BMC Psychiatry  
**Classificação:** atual  
**DOI:** https://doi.org/10.1186/s12888-020-02485-4  
**Link direto:** [https://doi.org/10.1186/s12888-020-02485-4](https://doi.org/10.1186/s12888-020-02485-4)

**Resumo:** Estudo quantitativo com 2.074 estudantes universitários chineses que avalia presença e busca de sentido como mediadores entre desesperança/orientações futuras e comportamento suicida. Resultados indicam que a presença de sentido (MLQ-P) media a relação entre desesperança e tendências suicidas, e que tanto presença quanto busca de sentido mediam relações entre dimensões do foco futuro e ideação suicida. O trabalho enfatiza a função protetora do significado de vida na promoção de narrativas de futuro mais adaptativas.

**Relevância:** Evidencia empírica da centralidade do sentido/meaning-making, núcleo das intervenções narrativas construtivistas.

### 11. Spiritual Lifemaps: A Client-Centered Pictorial Instrument for Spiritual Assessment, Planning, and Intervention

**Autores:** David R. Hodge  
**Ano:** 2005  
**Periódico:** Social Work  
**Classificação:** atual  
**DOI:** https://doi.org/10.1093/sw/50.1.77  
**Link direto:** [https://doi.org/10.1093/sw/50.1.77](https://doi.org/10.1093/sw/50.1.77)

**Resumo:** Apresenta o instrumento pictórico 'spiritual lifemap' para avaliação espiritual centrada no cliente, integrando avaliação, planejamento e intervenção. O autor descreve aplicação clínica com caso ilustrativo e discute intervenções espirituais trans-teóricas. A ferramenta facilita a externalização de significados e valores, apoiando o trabalho de re-significação narrativo em terapia. São abordadas questões éticas e conflitos de valores, com orientações práticas para uso em contextos de saúde mental e serviço social.

**Relevância:** Instrumento prático que apoia mapeamento narrativo de espiritualidade e significado no processo terapêutico.

### 12. Practitioner Review: When parent training doesn’t work: theory‐driven clinical strategies

**Autores:** Stephen Scott; Mark R. Dadds  
**Ano:** 2009  
**Periódico:** Journal of Child Psychology and Psychiatry  
**Classificação:** atual  
**DOI:** https://doi.org/10.1111/j.1469-7610.2009.02161.x  
**Link direto:** [https://doi.org/10.1111/j.1469-7610.2009.02161.x](https://doi.org/10.1111/j.1469-7610.2009.02161.x)

**Resumo:** Revisão para clínicos que aborda estratégias teóricas quando programas de treinamento parental baseados em aprendizagem social falham. Os autores propõem integrar teorias de apego, sistemas familiares, atribuições cognitivas e técnicas de empoderamento/motivational interviewing para enriquecer intervenções. Fornece diretrizes práticas para formular casos complexos e adaptar abordagens, enfatizando flexibilidade e sensibilidade contextual — princípios alinhados com a postura construtivista e narrativa na construção de intervenções centradas nas histórias familiares.

**Relevância:** Oferece estratégias integrativas e sensíveis ao contexto que ecoam princípios construtivistas quando abordagens padrão não mostram efeito.

### 13. Integrating Health Behavior Theory and Design Elements in Serious Games

**Autores:** Colleen Cheek; Theresa Fleming; Mathijs Lucassen; Heather Bridgman; Karolina Stasiak; Matthew Shepherd; P Orpin  
**Ano:** 2015  
**Periódico:** JMIR Mental Health  
**Classificação:** atual  
**DOI:** https://doi.org/10.2196/mental.4133  
**Link direto:** [https://doi.org/10.2196/mental.4133](https://doi.org/10.2196/mental.4133)

**Resumo:** Artigo que propõe um modelo integrador (baseado na Self-Determination Theory) para o desenho de serious games de saúde, ilustrado pelo desenvolvimento do SPARX para depressão em adolescentes. A análise combina percepções de usuários (focus groups e entrevistas) com elementos de design que promovem autonomia, competência e relacionamentos. O texto discute como narrativas interativas, imersão e aliança virtual podem facilitar mudanças comportamentais e emocionais em intervenções digitais construtivistas.

**Relevância:** Relaciona-se à família ao mostrar como narrativas interativas e design centrado no usuário suportam reauthoring e engajamento terapêutico digital.

### 14. Compassion Fatigue, Secondary Traumatic Stress, and Vicarious Traumatization: a Qualitative Review and Research Agenda

**Autores:** Rachel S. Rauvola; Dulce M. Vega; Kristi N. Lavigne  
**Ano:** 2019  
**Periódico:** Occupational Health Science  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1007/s41542-019-00045-1  
**Link direto:** [https://doi.org/10.1007/s41542-019-00045-1](https://doi.org/10.1007/s41542-019-00045-1)

**Resumo:** Revisão qualitativa que sintetiza literatura sobre fadiga por compaixão, estresse traumático secundário e vicarious traumatization em profissionais de saúde, descrevendo sintomas, mecanismos e lacunas de pesquisa. Os autores propõem uma agenda investigativa e práticas para prevenção e intervenção, abordando necessidades de suporte organizacional e pessoal. O tema é relevante para terapeutas narrativos, cujo trabalho com histórias traumáticas dos clientes pode gerar impacto vicariante significativo.

**Relevância:** Importante para práticas narrativas ao evidenciar riscos e estratégias de proteção para profissionais que trabalham com histórias traumáticas.

### 15. Adolescent Boys: Exploring Diverse Cultures of Boyhood

**Autores:** Niobe Way; Judy Y. Chu  
**Ano:** 2004  
**Periódico:** NYU Press  
**Classificação:** clássico  
**DOI:** https://doi.org/10.18574/nyu/9781479872572.001.0001  
**Link direto:** [https://doi.org/10.18574/nyu/9781479872572.001.0001](https://doi.org/10.18574/nyu/9781479872572.001.0001)

**Resumo:** Obra que investiga culturas diversas da masculinidade adolescente a partir de estudos qualitativos, destacando como jovens constroem narrativas de si em contextos culturais variados. Explora processos de socialização, identidade e significado, mostrando como histórias de boyhood se interseccionam com raça, classe e comunidades. Os autores apresentam implicações para intervenções psicoeducativas e clínicas que visam trabalhar narrativas identitárias em adolescentes, oferecendo ferramentas para abordagens construtivistas sensíveis ao contexto.

**Relevância:** Contribui à compreensão de construção narrativa de identidade em jovens, útil para práticas construtivistas e narrativas.

## Interpessoal e relacional
### 1. A developmental, mentalization-based approach to the understanding and treatment of borderline personality disorder

**Autores:** Peter Fonagy, Patrick Luyten  
**Ano:** 2009  
**Periódico:** Development and Psychopathology  
**Classificação:** clássico/revisão teórica  
**DOI:** https://doi.org/10.1017/S0954579409990198  
**Link direto:** [https://doi.org/10.1017/S0954579409990198](https://doi.org/10.1017/S0954579409990198)

**Resumo:** Este artigo desenvolve uma abordagem baseada em mentalização para compreender e tratar o transtorno de personalidade borderline (TPB). Argumenta que as características centrais do TPB — desregulação afetiva, impulsividade e relacionamentos instáveis — decorrem de déficits em diferentes facetas da mentalização, relacionados a circuitos neurais específicos. Discute como um limiar baixo de ativação do sistema de apego e a desativação da mentalização controlada levam à confusão entre estados mentais próprios e alheios, provocando ciclos interpessoais disfuncionais e implicações terapêuticas para o tratamento baseado em mentalização.

**Relevância:** Fundamental para a família por oferecer um modelo relacional e clínico centrado em mentalização e apego aplicável a tratamentos interpessoais.

### 2. Social Networking Sites and Addiction: Ten Lessons Learned

**Autores:** Daria J. Kuss, Mark D. Griffiths  
**Ano:** 2017  
**Periódico:** International Journal of Environmental Research and Public Health  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.3390/ijerph14030311  
**Link direto:** [https://doi.org/10.3390/ijerph14030311](https://doi.org/10.3390/ijerph14030311)

**Resumo:** Artigo relacionado ao tema “Social Networking Sites and Addiction: Ten Lessons Learned”, relevante para o estudo de fundamentos, processos ou resultados da família 07_interpessoal_relacional. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 07_interpessoal_relacional, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 3. Relational regulation theory: A new approach to explain the link between perceived social support and mental health.

**Autores:** Brian Lakey, Edward Orehek  
**Ano:** 2011  
**Periódico:** Psychological Review  
**Classificação:** atual/teórica  
**DOI:** https://doi.org/10.1037/a0023477  
**Link direto:** [https://doi.org/10.1037/a0023477](https://doi.org/10.1037/a0023477)

**Resumo:** Propõe a Relational Regulation Theory (RRT) como explicação alternativa ao papel do suporte social na saúde mental. Em vez de apenas tamponar o estresse, RRT sustenta que interações rotineiras — conversas e atividades compartilhadas — regulam afetos e pensamentos, promovendo efeitos diretos na saúde mental. Define operacionalmente os tipos de relações relevantes e gera previsões novas sobre intervenções que visam aumentar a regulação cotidiana por meio de vínculos pessoais preferidos pelo sujeito.

**Relevância:** Relevante por oferecer uma teoria relacional que explica como interações cotidianas impactam saúde mental e intervenções sociais.

### 4. Disorders of extreme stress: The empirical foundation of a complex adaptation to trauma

**Autores:** Bessel A. van der Kolk, Susan Roth, David Pelcovitz, Susanne Sunday, Joseph Spinazzola  
**Ano:** 2005  
**Periódico:** Journal of Traumatic Stress  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.1002/jts.20047  
**Link direto:** [https://doi.org/10.1002/jts.20047](https://doi.org/10.1002/jts.20047)

**Resumo:** Artigo relacionado ao tema “Disorders of extreme stress: The empirical foundation of a complex adaptation to trauma”, relevante para o estudo de fundamentos, processos ou resultados da família 07_interpessoal_relacional. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 07_interpessoal_relacional, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 5. Nostalgia: Content, triggers, functions.

**Autores:** Tim Wildschut, Constantine Sedikides, Jamie Arndt, Clay Routledge  
**Ano:** 2006  
**Periódico:** Journal of Personality and Social Psychology  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.1037/0022-3514.91.5.975  
**Link direto:** [https://doi.org/10.1037/0022-3514.91.5.975](https://doi.org/10.1037/0022-3514.91.5.975)

**Resumo:** Artigo relacionado ao tema “Nostalgia: Content, triggers, functions.”, relevante para o estudo de fundamentos, processos ou resultados da família 07_interpessoal_relacional. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 07_interpessoal_relacional, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 6. A Developmental Psychopathology Perspective on Child Abuse and Neglect

**Autores:** Dante Cicchetti, Sheree L. Toth  
**Ano:** 1995  
**Periódico:** Journal of the American Academy of Child & Adolescent Psychiatry  
**Classificação:** clássico/teórico-empírico  
**DOI:** https://doi.org/10.1097/00004583-199505000-00008  
**Link direto:** [https://doi.org/10.1097/00004583-199505000-00008](https://doi.org/10.1097/00004583-199505000-00008)

**Resumo:** Apresenta uma perspectiva do desenvolvimento sobre abuso e negligência infantil, enfatizando como adversidades precoces interrompem trajetórias de desenvolvimento em múltiplos domínios: emocional, cognitivo e social. Discute mecanismos psicológicos e biológicos que explicam heterogeneidade de desfechos e destaca fatores de risco e proteção ao longo do ciclo vital. O texto integra pesquisa empírica e teoria para orientar avaliação, prevenção e intervenções centradas nas relações familiares e contextos sociais das crianças maltreatmentadas.

**Relevância:** Base essencial sobre efeitos relacionais do abuso infantil e implicações para intervenções familiares.

### 7. Annual Research Review: Resilient functioning in maltreated children – past, present, and future perspectives

**Autores:** Dante Cicchetti  
**Ano:** 2012  
**Periódico:** Journal of Child Psychology and Psychiatry  
**Classificação:** revisão/anual  
**DOI:** https://doi.org/10.1111/j.1469-7610.2012.02608.x  
**Link direto:** [https://doi.org/10.1111/j.1469-7610.2012.02608.x](https://doi.org/10.1111/j.1469-7610.2012.02608.x)

**Resumo:** Revisão integrativa sobre funcionamento resiliente em crianças maltreatadas, abordando achados históricos e avanços contemporâneos. O autor destaca a natureza multicausal da resiliência, a interação entre fatores biológicos, genéticos e psicossociais, e a importância de investigações multilíneas que capturem processos dinâmicos. Conclui que ainda são necessários estudos multissetoriais para entender plenamente os mecanismos de resiliência e propõe direções para intervenções que promovam ajustes adaptativos em contextos adversos.

**Relevância:** Importante para a família por abordar resiliência relacional em contextos de abuso e suas implicações para intervenção.

### 8. Interpersonal relatedness and self-definition: Two prototypes for depression

**Autores:** Sidney J. Blatt, David C. Zuroff  
**Ano:** 1992  
**Periódico:** Clinical Psychology Review  
**Classificação:** clássico/teórico  
**DOI:** https://doi.org/10.1016/0272-7358(92)90070-O  
**Link direto:** [https://doi.org/10.1016/0272-7358(92)90070-O](https://doi.org/10.1016/0272-7358(92)90070-O)

**Resumo:** Revisa evidências que distinguem dois protótipos de depressão: um centrado em problemas de relações interpessoais (relatedness) e outro em ameaças à autoestima e auto‑definição (self‑definition). Analisa associações com experiências precoces, qualidade de vínculos parentais e sensibilidade a tipos específicos de estressores. Oferece um modelo etiológico que relaciona predisposições de personalidade a eventos de vida, contribuindo para uma compreensão diferenciada e personalizada das manifestações depressivas e suas implicações terapêuticas relacionais.

**Relevância:** Clássico que fundamenta distinções interpessoais na psicopatologia depressiva, útil para formulações relacionais.

### 9. A Model of Mindful Parenting: Implications for Parent–Child Relationships and Prevention Research

**Autores:** Larissa G. Duncan, J. Douglas Coatsworth, Mark T. Greenberg  
**Ano:** 2009  
**Periódico:** Clinical Child and Family Psychology Review  
**Classificação:** atual/modelo  
**DOI:** https://doi.org/10.1007/s10567-009-0046-3  
**Link direto:** [https://doi.org/10.1007/s10567-009-0046-3](https://doi.org/10.1007/s10567-009-0046-3)

**Resumo:** Propõe um modelo operacional de parentalidade consciente (mindful parenting) enfatizando atenção plena na interação com crianças, consciência emocional, autorregulação e compaixão não julgadora. Discute evidências e aplicações preventivas, sugerindo que práticas de atenção plena dos pais melhoram a qualidade das relações parentais, reduzem reatividade e promovem desenvolvimento socioemocional saudável nas crianças, especialmente durante a transição para a adolescência. Inclui implicações para integração em programas de prevenção familiar baseados em evidência.

**Relevância:** Relevante por focalizar intervenções relacionais no contexto pai‑filho e prevenção familiar.

### 10. Supportive Accountability: A Model for Providing Human Support to Enhance Adherence to eHealth Interventions

**Autores:** David C. Mohr, Pim Cuijpers, Kenneth A. Lehman  
**Ano:** 2011  
**Periódico:** Journal of Medical Internet Research  
**Classificação:** atual/modelo clínico  
**DOI:** https://doi.org/10.2196/jmir.1602  
**Link direto:** [https://doi.org/10.2196/jmir.1602](https://doi.org/10.2196/jmir.1602)

**Resumo:** Apresenta o modelo "Supportive Accountability" para orientar o suporte humano que aumenta adesão a intervenções e‑saúde. Sustenta que a presença de um coach percebido como confiável, benevolente e competente gera responsabilidade que melhora o seguimento, com expectativas processuais definidas conjuntamente. Examina moderação por motivação intrínseca e mediação pelo meio de comunicação (telefone, e‑mail, mensagens). O artigo propõe hipóteses testáveis e recomenda manualização do suporte humano para facilitar disseminação e avaliação.

**Relevância:** Importante para intervenções relacionais mediadas por tecnologia e pelo papel do suporte humano na adesão.

### 11. What is compassion and how can we measure it? A review of definitions and measures

**Autores:** Clara Strauss, Billie Lever Taylor, Jenny Gu, Willem Kuyken, Ruth A. Baer, Fergal W. Jones, Kate Cavanagh  
**Ano:** 2016  
**Periódico:** Clinical Psychology Review  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1016/j.cpr.2016.05.004  
**Link direto:** [https://doi.org/10.1016/j.cpr.2016.05.004](https://doi.org/10.1016/j.cpr.2016.05.004)

**Resumo:** Revisão sistemática sobre definições e medidas de compaixão, propondo uma definição operativa composta por cinco elementos: reconhecer sofrimento, entender sua universalidade, sentir empatia, tolerar sentimentos desconfortáveis e motivação/ação para aliviar o sofrimento. Avalia nove instrumentos publicados, apontando limitações psicométricas em consistência interna, estrutura fatorial e validade temporal. Recomenda desenvolvimento de medidas robustas alinhadas à definição proposta para avaliar intervenções que visam aumentar compaixão em contextos clínicos e relacionais.

**Relevância:** Pertinente por tratar mensuração de compaixão, construto-chave em intervenções relacionais e terapêuticas.

### 12. Diagnosis and classification of disorders specifically associated with stress: proposals for ICD-11

**Autores:** Andréas Maercker, Chris R. Brewin, Richard A. Bryant, Marylène Cloître, Mark van Ommeren, Lynne Jones, Asma Humayan, Ashraf Kagee  
**Ano:** 2013  
**Periódico:** World Psychiatry  
**Classificação:** revisão/consenso clínico  
**DOI:** https://doi.org/10.1002/wps.20057  
**Link direto:** [https://doi.org/10.1002/wps.20057](https://doi.org/10.1002/wps.20057)

**Resumo:** Discute propostas para a 11ª revisão da CID sobre transtornos associados ao estresse, propondo um conceito mais restrito para PTSD e a inclusão de "complex PTSD" com clusters adicionais intrapessoais e interpessoais, além de diagnosticar luto prolongado e revisar transtorno de ajustamento. As propostas priorizam utilidade clínica e aplicabilidade global, com ênfase nas manifestações relacionais e de regulação associadas ao trauma prolongado e suas implicações para prática clínica e políticas de saúde mental.

**Relevância:** Importante por formalizar categorias diagnósticas que incorporam sintomas interpessoais de trauma complexo.

### 13. The Brief RCOPE: Current Psychometric Status of a Short Measure of Religious Coping

**Autores:** Kenneth I. Pargäment, Margaret Feuille, Donna C. Burdzy  
**Ano:** 2011  
**Periódico:** Religions  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.3390/rel2010051  
**Link direto:** [https://doi.org/10.3390/rel2010051](https://doi.org/10.3390/rel2010051)

**Resumo:** Artigo relacionado ao tema “The Brief RCOPE: Current Psychometric Status of a Short Measure of Religious Coping”, relevante para o estudo de fundamentos, processos ou resultados da família 07_interpessoal_relacional. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 07_interpessoal_relacional, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 14. Self-enhancement and self-protection: What they are and what they do

**Autores:** Mark D. Alicke, Constantine Sedikides  
**Ano:** 2009  
**Periódico:** European Review of Social Psychology  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.1080/10463280802613866  
**Link direto:** [https://doi.org/10.1080/10463280802613866](https://doi.org/10.1080/10463280802613866)

**Resumo:** Artigo relacionado ao tema “Self-enhancement and self-protection: What they are and what they do”, relevante para o estudo de fundamentos, processos ou resultados da família 07_interpessoal_relacional. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 07_interpessoal_relacional, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 15. The Development and Initial Validation of the Cognitive Fusion Questionnaire

**Autores:** David Gillanders, Helen Bolderston, Frank W. Bond, Maria Dempster, Paul E. Flaxman, Lindsey Campbell, Sian Kerr, Louise Tansey  
**Ano:** 2013  
**Periódico:** Behavior Therapy  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.1016/j.beth.2013.09.001  
**Link direto:** [https://doi.org/10.1016/j.beth.2013.09.001](https://doi.org/10.1016/j.beth.2013.09.001)

**Resumo:** Artigo relacionado ao tema “The Development and Initial Validation of the Cognitive Fusion Questionnaire”, relevante para o estudo de fundamentos, processos ou resultados da família 07_interpessoal_relacional. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 07_interpessoal_relacional, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

## Integrativa e eclética
### 1. The impact of perception and presence on emotional reactions: a review of research in virtual reality

**Autores:** Julia Diemer, Georg W. Alpers, Henrik M. Peperkorn, Youssef Shiban, Andreas MÃ ⁄ hlberger  
**Ano:** 2015  
**Periódico:** Frontiers in Psychology  
**Classificação:** revisão ou síntese de evidências  
**DOI:** https://doi.org/10.3389/fpsyg.2015.00026  
**Link direto:** [https://doi.org/10.3389/fpsyg.2015.00026](https://doi.org/10.3389/fpsyg.2015.00026)

**Resumo:** Artigo relacionado ao tema “The impact of perception and presence on emotional reactions: a review of research in virtual reality”, relevante para o estudo de fundamentos, processos ou resultados da família 08_integrativa_ecletica. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 08_integrativa_ecletica, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 2. Transdiagnostic approaches to mental health problems: Current status and future directions.

**Autores:** Tim Dalgleish, Melissa Black, David Johnston, Anna Bevan  
**Ano:** 2020  
**Periódico:** Journal of Consulting and Clinical Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.1037/ccp0000482  
**Link direto:** [https://doi.org/10.1037/ccp0000482](https://doi.org/10.1037/ccp0000482)

**Resumo:** Artigo relacionado ao tema “Transdiagnostic approaches to mental health problems: Current status and future directions.”, relevante para o estudo de fundamentos, processos ou resultados da família 08_integrativa_ecletica. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 08_integrativa_ecletica, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 3. Psychological therapies for chronic post-traumatic stress disorder (PTSD) in adults

**Autores:** Jonathan I. Bisson, Neil P. Roberts, Martin Andrew, Rosalind Cooper, Catrin Lewis  
**Ano:** 2013  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1002/14651858.cd003388.pub4  
**Link direto:** [https://doi.org/10.1002/14651858.cd003388.pub4](https://doi.org/10.1002/14651858.cd003388.pub4)

**Resumo:** Cochrane review que avaliou 70 estudos com 4761 participantes sobre tratamentos psicológicos para PTSD crônico. Concluiu que terapias focadas no trauma, como TFCBT e EMDR, foram mais eficazes que espera/TAU na redução de sintomas pós-trauma. Evidências variaram em qualidade e mostrou heterogeneidade e risco de viés em muitos estudos. Resultados apontam que várias intervenções são efetivas imediatamente, com algumas vantagens de TFCBT/EMDR em seguimento, porém a qualidade geral das evidências exige cautela.

**Relevância:** Revisão sistemática fundamental para integrar opções terapêuticas baseadas em evidência no manejo de PTSD dentro de práticas ecléticas.

### 4. The Role of Common Factors in Psychotherapy Outcomes

**Autores:** Pim Cuijpers, Mirjam Reijnders, Marcus J. H. Huibers  
**Ano:** 2018  
**Periódico:** Annual Review of Clinical Psychology  
**Classificação:** estudo de intervenção ou resultados clínicos  
**DOI:** https://doi.org/10.1146/annurev-clinpsy-050718-095424  
**Link direto:** [https://doi.org/10.1146/annurev-clinpsy-050718-095424](https://doi.org/10.1146/annurev-clinpsy-050718-095424)

**Resumo:** Artigo relacionado ao tema “The Role of Common Factors in Psychotherapy Outcomes”, relevante para o estudo de fundamentos, processos ou resultados da família 08_integrativa_ecletica. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 08_integrativa_ecletica, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 5. The Role of Empathy in Health and Social Care Professionals

**Autores:** Μαρία Μουδάτσου, Areti Stavropoulou, Αnastas Philalithis, Sofia Koukouli  
**Ano:** 2020  
**Periódico:** Healthcare  
**Classificação:** atual  
**DOI:** https://doi.org/10.3390/healthcare8010026  
**Link direto:** [https://doi.org/10.3390/healthcare8010026](https://doi.org/10.3390/healthcare8010026)

**Resumo:** Artigo relacionado ao tema “The Role of Empathy in Health and Social Care Professionals”, relevante para o estudo de fundamentos, processos ou resultados da família 08_integrativa_ecletica. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 08_integrativa_ecletica, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 6. Treating PTSD: A Review of Evidence-Based Psychotherapy Interventions

**Autores:** Laura E. Watkins, Kelsey Sprang, Barbara O. Rothbaum  
**Ano:** 2018  
**Periódico:** Frontiers in Behavioral Neuroscience  
**Classificação:** revisão ou síntese de evidências  
**DOI:** https://doi.org/10.3389/fnbeh.2018.00258  
**Link direto:** [https://doi.org/10.3389/fnbeh.2018.00258](https://doi.org/10.3389/fnbeh.2018.00258)

**Resumo:** Artigo relacionado ao tema “Treating PTSD: A Review of Evidence-Based Psychotherapy Interventions”, relevante para o estudo de fundamentos, processos ou resultados da família 08_integrativa_ecletica. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 08_integrativa_ecletica, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 7. Paradox Research in Management Science: Looking Back to Move Forward

**Autores:** Jonathan Schad, Marianne W. Lewis, Sebastian Raisch, Wendy K. Smith  
**Ano:** 2016  
**Periódico:** Academy of Management Annals  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.1080/19416520.2016.1162422  
**Link direto:** [https://doi.org/10.1080/19416520.2016.1162422](https://doi.org/10.1080/19416520.2016.1162422)

**Resumo:** Artigo relacionado ao tema “Paradox Research in Management Science: Looking Back to Move Forward”, relevante para o estudo de fundamentos, processos ou resultados da família 08_integrativa_ecletica. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 08_integrativa_ecletica, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 8. An overview of and recommendations for more accessible digital mental health services

**Autores:** Emily G. Lattie, Colleen Stiles‐Shields, Andrea K. Graham  
**Ano:** 2022  
**Periódico:** Nature Reviews Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.1038/s44159-021-00003-1  
**Link direto:** [https://doi.org/10.1038/s44159-021-00003-1](https://doi.org/10.1038/s44159-021-00003-1)

**Resumo:** Artigo relacionado ao tema “An overview of and recommendations for more accessible digital mental health services”, relevante para o estudo de fundamentos, processos ou resultados da família 08_integrativa_ecletica. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 08_integrativa_ecletica, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 9. Psychotherapies for PTSD: what do they have in common?

**Autores:** Ulrich Schnyder, Anke Ehlers, Thomas Elbert, Edna B. Foa, Berthold P. R. Gersons, Patricia A. Resick, Francine Shapiro, Marylène Cloître  
**Ano:** 2015  
**Periódico:** European Journal of Psychotraumatology  
**Classificação:** atual  
**DOI:** https://doi.org/10.3402/ejpt.v6.28186  
**Link direto:** [https://doi.org/10.3402/ejpt.v6.28186](https://doi.org/10.3402/ejpt.v6.28186)

**Resumo:** Artigo coletivo que solicita a pioneiros de terapias para trauma que descrevam suas abordagens e identifiquem três componentes críticos comuns. A síntese aponta convergências: psicoeducação, regulação emocional, exposição imaginária, reprocessamento cognitivo e trabalho com memória e significado. Os autores discutem implicações teóricas e práticas, sugerindo investigação de mecanismos compartilhados e desenvolvimento de tratamentos ajustados a subgrupos clínicos e apresentações complexas.

**Relevância:** Identifica componentes transversais úteis para montagem de protocolos integrativos e ecléticos em PTSD.

### 10. American Academy of Clinical Neuropsychology (AACN) 2021 consensus statement on validity assessment: Update of the 2009 AACN consensus conference statement on neuropsychological assessment of effort, response bias, and malingering

**Autores:** Jerry J. Sweet, Robert L. Heilbronner, Joel E. Morgan, Glenn J. Larrabee, Martin L. Rohling, Kyle B. Boone, Michael W. Kirkwood, Ryan W. Schroeder  
**Ano:** 2021  
**Periódico:** The Clinical Neuropsychologist  
**Classificação:** atual  
**DOI:** https://doi.org/10.1080/13854046.2021.1896036  
**Link direto:** [https://doi.org/10.1080/13854046.2021.1896036](https://doi.org/10.1080/13854046.2021.1896036)

**Resumo:** Artigo relacionado ao tema “American Academy of Clinical Neuropsychology (AACN) 2021 consensus statement on validity assessment: Update of the 2009 AACN consensus conference statement on neuropsychological assessment of effort, response bias, and malingering”, relevante para o estudo de fundamentos, processos ou resultados da família 08_integrativa_ecletica. A referência deve ser consultada no texto integral para a análise detalhada de seu método, população, intervenção e achados.

**Relevância:** Complementa a literatura da família 08_integrativa_ecletica, oferecendo um ponto de referência para a compreensão de seus conceitos, métodos ou aplicações clínicas.

### 11. An Overview of Chatbot-Based Mobile Mental Health Apps: Insights From App Description and User Reviews

**Autores:** Md Romael Haque, Sabirat Rubya  
**Ano:** 2023  
**Periódico:** JMIR mhealth and uhealth  
**Classificação:** atual  
**DOI:** https://doi.org/10.2196/44838  
**Link direto:** [https://doi.org/10.2196/44838](https://doi.org/10.2196/44838)

**Resumo:** Estudo exploratório sobre chatbots em apps de saúde mental, analisando descrições e milhares de avaliações de usuários. Conclui que interações personalizadas e humanizadas são bem recebidas, mas respostas inadequadas e falta de detecção confiável de crises comprometem utilidade. Usuários apreciam disponibilidade 24/7 e ambiente sem julgamento, embora o uso excessivo possa promover dependência. O trabalho sugere recomendações de personalização, limites de serviço e estratégias para melhorar segurança e eficácia.

**Relevância:** Explora ferramentas digitais que podem ser incorporadas em práticas integrativas ecléticas, especialmente em cuidados complementares e contínuos.

### 12. Motivational interviewing for substance abuse

**Autores:** Geir Smedslund, Rigmor C. Berg, Karianne Thune Hammerstrøm, Asbjørn Steiro, Kari Ann Leiknes, Helene Dahl, Kjetil Karlsen  
**Ano:** 2011  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** revisão sistemática  
**DOI:** https://doi.org/10.1002/14651858.cd008063.pub2  
**Link direto:** [https://doi.org/10.1002/14651858.cd008063.pub2](https://doi.org/10.1002/14651858.cd008063.pub2)

**Resumo:** Revisão Cochrane de 59 estudos (13.342 participantes) sobre entrevista motivacional (EM) para abuso de substâncias. EM mostrou efeito significativo em reduzir uso comparado a nenhum tratamento, com efeito maior no pós-intervenção e diminuindo ao longo do tempo; não houve diferença consistente frente ao tratamento habitual. Evidências são de qualidade variada e muitas conclusões são de baixa confiança, indicando necessidade de estudos adicionais com maior rigidez metodológica.

**Relevância:** MI/EM é uma técnica integrável em modelos ecléticos, relevante para intervenções motivacionais em diferentes contextos clínicos.

### 13. Factors associated with dropout from treatment for eating disorders: a comprehensive literature review

**Autores:** Secondo Fassino, Andrea Pierò, Elena Tomba, Giovanni Abbate‐Daga  
**Ano:** 2009  
**Periódico:** BMC Psychiatry  
**Classificação:** atual  
**DOI:** https://doi.org/10.1186/1471-244x-9-67  
**Link direto:** [https://doi.org/10.1186/1471-244x-9-67](https://doi.org/10.1186/1471-244x-9-67)

**Resumo:** Revisão extensa sobre preditores de abandono em tratamentos de transtornos alimentares (1980–2009). Reporta taxas altas de dropout, variando por setting. Identifica inconsistências metodológicas entre estudos, mas destaca associação consistente com subtipo binge-purge, traços psicológicos como medo de maturidade e impulsividade, e dimensões de personalidade (baixa autodireção e cooperação). Autores recomendam padronização da definição de abandono e avaliação de traços de personalidade para reduzir evasão terapêutica.

**Relevância:** Foco em adesão e fatores de risco de abandono útil para modelos integrativos que visam personalizar e manter tratamentos.

### 14. The International Society for Traumatic Stress Studies New Guidelines for the Prevention and Treatment of Posttraumatic Stress Disorder: Methodology and Development Process

**Autores:** Jonathan I. Bisson, Lucy Berliner, Marylène Cloître, David Forbes, Tine K. Jensen, Catrin Lewis, Candice M. Monson, Miranda Olff  
**Ano:** 2019  
**Periódico:** Journal of Traumatic Stress  
**Classificação:** atual  
**DOI:** https://doi.org/10.1002/jts.22421  
**Link direto:** [https://doi.org/10.1002/jts.22421](https://doi.org/10.1002/jts.22421)

**Resumo:** Descrição metodológica do processo que gerou as diretrizes ISTSS (2018) para prevenção e tratamento do PTSD. Relata busca sistemática, inclusão de 361 RCTs, realização de 208 meta-análises e construção de 125 recomendações com níveis de evidência variados. Discute ponderações acerca de apresentações complexas (CPTSD), lacunas de evidência e implicações para pesquisa e prática. O artigo é um recurso sobre rigor metodológico e interpretação de recomendações clínicas em trauma.

**Relevância:** Fornece base metodológica e recomendações que orientam a seleção integrada de intervenções para PTSD em práticas ecléticas.

### 15. Complementary and Alternative Medicine in the Management of Pain, Dyspnea, and Nausea and Vomiting Near the End of Life

**Autores:** Cynthia X. Pan, R. Sean Morrison, Jose Ness, Adriane Fugh‐Berman, Rosanne M. Leipzig  
**Ano:** 2000  
**Periódico:** Journal of Pain and Symptom Management  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1016/S0885-3924(00)00190-1  
**Link direto:** [https://doi.org/10.1016/S0885-3924(00)00190-1](https://doi.org/10.1016/S0885-3924(00)00190-1)

**Resumo:** Revisão sobre o uso de terapias complementares e alternativas (TCAs) no controle de dor, dispneia e náuseas/emese no fim de vida. Analisa evidências para técnicas como acupuntura, massagem, aromaterapia e relaxamento, discutindo benefícios potenciais, limitações de estudos e considerações de segurança. Os autores destacam o papel das TCAs como complementos às intervenções paliativas convencionais e a necessidade de mais pesquisa controlada para integrar práticas eficazes de forma segura.

**Relevância:** Exemplo precoce de integração entre medicina convencional e práticas complementares, relevante para família integrativa/ecletica.

## Social, cultural e gênero
### 1. Culture and Psychopathology: New Perspectives on Research, Practice, and Clinical Training in a Globalized World

**Autores:** Carla Moleiro  
**Ano:** 2018  
**Periódico:** Frontiers in Psychiatry  
**Classificação:** atual  
**DOI:** https://doi.org/10.3389/fpsyt.2018.00366  
**Link direto:** [https://doi.org/10.3389/fpsyt.2018.00366](https://doi.org/10.3389/fpsyt.2018.00366)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Culture and Psychopathology: New Perspectives on Research, Practice, and Clinical Training in a Globalized World” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Contribui diretamente para uma psicoterapia culturalmente responsiva e atenta a gênero, raça, sexualidade, desigualdade e contexto sociopolítico.

### 2. An Evidence-Based Approach for Treating Stress and Trauma due to Racism

**Autores:** Monnica T. Williams, Samantha C. Holmes, Manzar Zare, Angela M. Haeny, Sonya C. Faber  
**Ano:** 2022  
**Periódico:** Cognitive and Behavioral Practice  
**Classificação:** revisão ou síntese de evidências  
**DOI:** https://doi.org/10.1016/j.cbpra.2022.07.001  
**Link direto:** [https://doi.org/10.1016/j.cbpra.2022.07.001](https://doi.org/10.1016/j.cbpra.2022.07.001)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “An Evidence-Based Approach for Treating Stress and Trauma due to Racism” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Contribui diretamente para uma psicoterapia culturalmente responsiva e atenta a gênero, raça, sexualidade, desigualdade e contexto sociopolítico.

### 3. The Biopsychosocial Model and the Sex-Positive Approach: an Integrative Perspective for Sexology and General Health Care

**Autores:** Filippo Maria Nimbi, Roberta Galizia, Roberta Rossi, Erika Limoncin, Giacomo Ciocca, Lilibeth Fontanesi, Emmanuele A. Jannini, Chiara Simonelli  
**Ano:** 2021  
**Periódico:** Sexuality Research and Social Policy  
**Classificação:** atual  
**DOI:** https://doi.org/10.1007/s13178-021-00647-x  
**Link direto:** [https://doi.org/10.1007/s13178-021-00647-x](https://doi.org/10.1007/s13178-021-00647-x)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “The Biopsychosocial Model and the Sex-Positive Approach: an Integrative Perspective for Sexology and General Health Care” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

### 4. Trans as Bodily Becoming: Rethinking the Biological as Diversity, Not Dichotomy

**Autores:** Riki Lane  
**Ano:** 2008  
**Periódico:** Hypatia  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.1111/j.1527-2001.2009.01049.x  
**Link direto:** [https://doi.org/10.1111/j.1527-2001.2009.01049.x](https://doi.org/10.1111/j.1527-2001.2009.01049.x)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Trans as Bodily Becoming: Rethinking the Biological as Diversity, Not Dichotomy” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

### 5. Future Directions in Mental Health Treatment with Stigmatized Youth

**Autores:** Maggi Price, Nathan L. Hollinsaid  
**Ano:** 2022  
**Periódico:** Journal of Clinical Child & Adolescent Psychology  
**Classificação:** estudo de intervenção ou resultados clínicos  
**DOI:** https://doi.org/10.1080/15374416.2022.2109652  
**Link direto:** [https://doi.org/10.1080/15374416.2022.2109652](https://doi.org/10.1080/15374416.2022.2109652)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Future Directions in Mental Health Treatment with Stigmatized Youth” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

### 6. Thematic review of family therapy journals in 2013

**Autores:** Alan Carr  
**Ano:** 2014  
**Periódico:** Journal of Family Therapy  
**Classificação:** revisão ou síntese de evidências  
**DOI:** https://doi.org/10.1111/1467-6427.12061  
**Link direto:** [https://doi.org/10.1111/1467-6427.12061](https://doi.org/10.1111/1467-6427.12061)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Thematic review of family therapy journals in 2013” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

### 7. Being an anti-racist clinician

**Autores:** Monnica T. Williams, Sonya C. Faber, Caroline Duniya  
**Ano:** 2022  
**Periódico:** The Cognitive Behaviour Therapist  
**Classificação:** atual  
**DOI:** https://doi.org/10.1017/s1754470x22000162  
**Link direto:** [https://doi.org/10.1017/s1754470x22000162](https://doi.org/10.1017/s1754470x22000162)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Being an anti-racist clinician” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

### 8. The Limits of Resilience and the Need for Resistance: Articulating the Role of Music Therapy With Young People Within a Shifting Trauma Paradigm

**Autores:** Elly Scrine  
**Ano:** 2021  
**Periódico:** Frontiers in Psychology  
**Classificação:** estudo de intervenção ou resultados clínicos  
**DOI:** https://doi.org/10.3389/fpsyg.2021.600245  
**Link direto:** [https://doi.org/10.3389/fpsyg.2021.600245](https://doi.org/10.3389/fpsyg.2021.600245)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “The Limits of Resilience and the Need for Resistance: Articulating the Role of Music Therapy With Young People Within a Shifting Trauma Paradigm” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

### 9. Toward Cognitive-Behavioral Therapy for Sexual Minority Women: Voices From Stakeholders and Community Members

**Autores:** Jillian R. Scheer, Kirsty A. Clark, Erin M. McConocha, Katie Wang, John E. Pachankis  
**Ano:** 2022  
**Periódico:** Cognitive and Behavioral Practice  
**Classificação:** estudo de intervenção ou resultados clínicos  
**DOI:** https://doi.org/10.1016/j.cbpra.2022.02.019  
**Link direto:** [https://doi.org/10.1016/j.cbpra.2022.02.019](https://doi.org/10.1016/j.cbpra.2022.02.019)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Toward Cognitive-Behavioral Therapy for Sexual Minority Women: Voices From Stakeholders and Community Members” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Contribui diretamente para uma psicoterapia culturalmente responsiva e atenta a gênero, raça, sexualidade, desigualdade e contexto sociopolítico.

### 10. Cultural Competence Interventions in European Healthcare: A Scoping Review

**Autores:** Berta De-María, Gabriela Topa, M. Ángeles López-González  
**Ano:** 2024  
**Periódico:** Healthcare  
**Classificação:** revisão ou síntese de evidências  
**DOI:** https://doi.org/10.3390/healthcare12101040  
**Link direto:** [https://doi.org/10.3390/healthcare12101040](https://doi.org/10.3390/healthcare12101040)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Cultural Competence Interventions in European Healthcare: A Scoping Review” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Contribui diretamente para uma psicoterapia culturalmente responsiva e atenta a gênero, raça, sexualidade, desigualdade e contexto sociopolítico.

### 11. Impostor Phenomenon in Racially/Ethnically Minoritized Groups: Current Knowledge and Future Directions

**Autores:** Kevin Cokley, Donte L. Bernard, Steven Stone‐Sabali, Germine H. Awad  
**Ano:** 2024  
**Periódico:** Annual Review of Clinical Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.1146/annurev-clinpsy-081122-015724  
**Link direto:** [https://doi.org/10.1146/annurev-clinpsy-081122-015724](https://doi.org/10.1146/annurev-clinpsy-081122-015724)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Impostor Phenomenon in Racially/Ethnically Minoritized Groups: Current Knowledge and Future Directions” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Contribui diretamente para uma psicoterapia culturalmente responsiva e atenta a gênero, raça, sexualidade, desigualdade e contexto sociopolítico.

### 12. The Case of Felix: An Example of Gay-Affirmative, Cognitive-Behavioral Therapy

**Autores:** Judith M. Glassgold  
**Ano:** 2009  
**Periódico:** Pragmatic Case Studies in Psychotherapy  
**Classificação:** estudo de intervenção ou resultados clínicos  
**DOI:** https://doi.org/10.14713/pcsp.v5i4.995  
**Link direto:** [https://doi.org/10.14713/pcsp.v5i4.995](https://doi.org/10.14713/pcsp.v5i4.995)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “The Case of Felix: An Example of Gay-Affirmative, Cognitive-Behavioral Therapy” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

### 13. Providing Validating Clinical Care to LGBTQ+ Adolescents and Young Adults

**Autores:** Savannah R. Roberts, Claire D. Stout, Brian C. Thoma, Sophia Choukas-Bradley  
**Ano:** 2026  
**Periódico:** Journal of Health Service Psychology  
**Classificação:** atual  
**DOI:** https://doi.org/10.1007/s42843-025-00150-6  
**Link direto:** [https://doi.org/10.1007/s42843-025-00150-6](https://doi.org/10.1007/s42843-025-00150-6)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Providing Validating Clinical Care to LGBTQ+ Adolescents and Young Adults” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Contribui diretamente para uma psicoterapia culturalmente responsiva e atenta a gênero, raça, sexualidade, desigualdade e contexto sociopolítico.

### 14. Conundrums in Women’s Mental Health: Social Determinants and Systemic Challenges

**Autores:** Prajwalkumar Bhatkar  
**Ano:** 2026  
**Periódico:** Journal of Artificial Intelligence and Information  
**Classificação:** atual  
**DOI:** https://doi.org/10.66069/ojspub.1811260611  
**Link direto:** [https://doi.org/10.66069/ojspub.1811260611](https://doi.org/10.66069/ojspub.1811260611)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Conundrums in Women’s Mental Health: Social Determinants and Systemic Challenges” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

### 15. Respecting Diversity, Equity, and Inclusion: Pluralism and Human Rights in Civil Society

**Autores:** Laurence J. Kirmayer, Dörte Bemme, G. Eric Jarvis  
**Ano:** 2026  
**Periódico:** Transcultural Psychiatry  
**Classificação:** atual  
**DOI:** https://doi.org/10.1177/13634615261445845  
**Link direto:** [https://doi.org/10.1177/13634615261445845](https://doi.org/10.1177/13634615261445845)

**Resumo:** Artigo que aborda, a partir do tema indicado no título — “Respecting Diversity, Equity, and Inclusion: Pluralism and Human Rights in Civil Society” —, as relações entre sofrimento psíquico, cultura, marcadores sociais, gênero, raça, sexualidade e contexto histórico. É pertinente para uma leitura psicoterapêutica socialmente situada porque desloca a compreensão do caso individual para a interação entre experiência subjetiva, relações de poder, identidade e condições de vida; a contribuição específica deve ser lida no texto integral.

**Relevância:** Amplia a discussão sobre como contexto social e marcadores de identidade atravessam a avaliação, a relação terapêutica e o cuidado.

## Pragmáticos e orientados a objetivos
### 1. High-quality health systems in the Sustainable Development Goals era: time for a revolution

**Autores:** Margaret E. Kruk, Anna Gage, Catherine Arsenault, Keely Jordan, Hannah H. Leslie, Sanam Roder‐DeWan, Olusoji Adeyi, Pierre Barker  
**Ano:** 2018  
**Periódico:** The Lancet Global Health  
**Classificação:** atual  
**DOI:** https://doi.org/10.1016/s2214-109x(18)30386-3  
**Link direto:** [https://doi.org/10.1016/s2214-109x(18)30386-3](https://doi.org/10.1016/s2214-109x(18)30386-3)

**Resumo:** Artigo relacionado ao tema “High-quality health systems in the Sustainable Development Goals era: time for a revolution”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 2. The Lancet Commission on global mental health and sustainable development

**Autores:** Vikram Patel, Shekhar Saxena, Crick Lund, Graham Thornicroft, Florence Baingana, Paul Bolton, Dan Chisholm, Pamela Y. Collins  
**Ano:** 2018  
**Periódico:** The Lancet  
**Classificação:** atual  
**DOI:** https://doi.org/10.1016/s0140-6736(18)31612-x  
**Link direto:** [https://doi.org/10.1016/s0140-6736(18)31612-x](https://doi.org/10.1016/s0140-6736(18)31612-x)

**Resumo:** Artigo relacionado ao tema “The Lancet Commission on global mental health and sustainable development”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 3. Large language models encode clinical knowledge

**Autores:** Karan Singhal, Shekoofeh Azizi, Tao Tu, S. Sara Mahdavi, Jason Lee, Hyung Won Chung, Nathan Scales, Ajay Kumar Tanwani  
**Ano:** 2023  
**Periódico:** Nature  
**Classificação:** atual  
**DOI:** https://doi.org/10.1038/s41586-023-06291-2  
**Link direto:** [https://doi.org/10.1038/s41586-023-06291-2](https://doi.org/10.1038/s41586-023-06291-2)

**Resumo:** Artigo relacionado ao tema “Large language models encode clinical knowledge”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 4. The Ripple Effect: Emotional Contagion and its Influence on Group Behavior

**Autores:** Sigal G. Barsade  
**Ano:** 2002  
**Periódico:** Administrative Science Quarterly  
**Classificação:** clássico  
**DOI:** https://doi.org/10.2307/3094912  
**Link direto:** [https://doi.org/10.2307/3094912](https://doi.org/10.2307/3094912)

**Resumo:** Artigo relacionado ao tema “The Ripple Effect: Emotional Contagion and its Influence on Group Behavior”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 5. A survey of socially interactive robots

**Autores:** Terrence Fong, Illah Nourbakhsh, Kerstin Dautenhahn  
**Ano:** 2003  
**Periódico:** Robotics and Autonomous Systems  
**Classificação:** clássico  
**DOI:** https://doi.org/10.1016/s0921-8890(02)00372-x  
**Link direto:** [https://doi.org/10.1016/s0921-8890(02)00372-x](https://doi.org/10.1016/s0921-8890(02)00372-x)

**Resumo:** Artigo relacionado ao tema “A survey of socially interactive robots”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 6. Beyond Adoption: A New Framework for Theorizing and Evaluating Nonadoption, Abandonment, and Challenges to the Scale-Up, Spread, and Sustainability of Health and Care Technologies

**Autores:** Trisha Greenhalgh, Joseph Wherton, Chrysanthi Papoutsi, Jennifer Lynch, Gemma Hughes, Christine A’Court, Susan Hinder, Nick Fahy  
**Ano:** 2017  
**Periódico:** Journal of Medical Internet Research  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.2196/jmir.8775  
**Link direto:** [https://doi.org/10.2196/jmir.8775](https://doi.org/10.2196/jmir.8775)

**Resumo:** Artigo relacionado ao tema “Beyond Adoption: A New Framework for Theorizing and Evaluating Nonadoption, Abandonment, and Challenges to the Scale-Up, Spread, and Sustainability of Health and Care Technologies”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 7. Enhancing Our Lives with Immersive Virtual Reality

**Autores:** Mel Slater, María V. Sánchez-Vives  
**Ano:** 2016  
**Periódico:** Frontiers in Robotics and AI  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.3389/frobt.2016.00074  
**Link direto:** [https://doi.org/10.3389/frobt.2016.00074](https://doi.org/10.3389/frobt.2016.00074)

**Resumo:** Artigo relacionado ao tema “Enhancing Our Lives with Immersive Virtual Reality”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 8. The Person-Based Approach to Intervention Development: Application to Digital Health-Related Behavior Change Interventions

**Autores:** Lucy Yardley, Leanne Morrison, Katherine Bradbury, Ingrid Müller  
**Ano:** 2015  
**Periódico:** Journal of Medical Internet Research  
**Classificação:** estudo de intervenção ou resultados clínicos  
**DOI:** https://doi.org/10.2196/jmir.4055  
**Link direto:** [https://doi.org/10.2196/jmir.4055](https://doi.org/10.2196/jmir.4055)

**Resumo:** Artigo relacionado ao tema “The Person-Based Approach to Intervention Development: Application to Digital Health-Related Behavior Change Interventions”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 9. Interventions for treating obesity in children

**Autores:** Hiltje Oude Luttikhuis, Louise A. Baur, Hanneke Jansen, Vanessa A. Shrewsbury, Claire O’Malley, Ronald P. Stolk, Carolyn Summerbell  
**Ano:** 2009  
**Periódico:** Cochrane Database of Systematic Reviews  
**Classificação:** estudo de intervenção ou resultados clínicos  
**DOI:** https://doi.org/10.1002/14651858.cd001872.pub2  
**Link direto:** [https://doi.org/10.1002/14651858.cd001872.pub2](https://doi.org/10.1002/14651858.cd001872.pub2)

**Resumo:** Artigo relacionado ao tema “Interventions for treating obesity in children”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 10. The World Federation of ADHD International Consensus Statement: 208 Evidence-based conclusions about the disorder

**Autores:** Stephen V. Faraone, Tobias Banaschewski, David Coghill, Yi Zheng, Joseph Biederman, Mark A. Bellgrove, Jeffrey H. Newcorn, Martin Gignac  
**Ano:** 2021  
**Periódico:** Neuroscience & Biobehavioral Reviews  
**Classificação:** revisão ou síntese de evidências  
**DOI:** https://doi.org/10.1016/j.neubiorev.2021.01.022  
**Link direto:** [https://doi.org/10.1016/j.neubiorev.2021.01.022](https://doi.org/10.1016/j.neubiorev.2021.01.022)

**Resumo:** Artigo relacionado ao tema “The World Federation of ADHD International Consensus Statement: 208 Evidence-based conclusions about the disorder”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 11. A Clinical Practice Guideline for Treating Tobacco Use and Dependence: 2008 Update

**Autores:** ⁎  
**Ano:** 2008  
**Periódico:** American Journal of Preventive Medicine  
**Classificação:** estudo teórico ou empírico  
**DOI:** https://doi.org/10.1016/j.amepre.2008.04.009  
**Link direto:** [https://doi.org/10.1016/j.amepre.2008.04.009](https://doi.org/10.1016/j.amepre.2008.04.009)

**Resumo:** Artigo relacionado ao tema “A Clinical Practice Guideline for Treating Tobacco Use and Dependence: 2008 Update”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 12. Multimorbidity

**Autores:** Søren Thorgaard Skou, Frances S Mair, Martin Fortin, Bruce Guthrie, Bruno Pereira Nunes, J. Jaime Miranda, Cynthia M. Boyd, Sanghamitra Pati  
**Ano:** 2022  
**Periódico:** Nature Reviews Disease Primers  
**Classificação:** atual  
**DOI:** https://doi.org/10.1038/s41572-022-00376-4  
**Link direto:** [https://doi.org/10.1038/s41572-022-00376-4](https://doi.org/10.1038/s41572-022-00376-4)

**Resumo:** Artigo relacionado ao tema “Multimorbidity”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 13. Volume 10, Supplementary 2 (2026)

**Autores:** Editorial Team IJAHS  
**Ano:** 2026  
**Periódico:** INTERNATIONAL JOURNAL OF ALLIED HEALTH SCIENCES  
**Classificação:** atual  
**DOI:** https://doi.org/10.31436/ijahs.v10isupp2.1165  
**Link direto:** [https://doi.org/10.31436/ijahs.v10isupp2.1165](https://doi.org/10.31436/ijahs.v10isupp2.1165)

**Resumo:** Artigo relacionado ao tema “Volume 10, Supplementary 2 (2026)”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** Ajuda a compreender princípios pragmáticos de formulação, intervenção breve e avaliação orientada a problemas e objetivos.

### 14. The Concept of Recovery in Compulsive Sexual Behavior Disorder – A Scoping Review

**Autores:** Belle Gavriel‐Fried, Naama Glaser-Guy, Rita Horváth, Rózsa Vivien Szabó, Zsolt Demetrovics, Beáta Bőthe  
**Ano:** 2026  
**Periódico:** The Journal of Sex Research  
**Classificação:** revisão ou síntese de evidências  
**DOI:** https://doi.org/10.1080/00224499.2026.2704252  
**Link direto:** [https://doi.org/10.1080/00224499.2026.2704252](https://doi.org/10.1080/00224499.2026.2704252)

**Resumo:** Artigo relacionado ao tema “The Concept of Recovery in Compulsive Sexual Behavior Disorder – A Scoping Review”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** É relevante para intervenções focalizadas, definição de metas, mudança comportamental e avaliação objetiva de resultados clínicos.

### 15. Lived experiences of navigating cancer medication access among patients, caregivers, and healthcare providers at a referral oncology teaching hospital

**Autores:** Fatemeh Homayounifar, Sadra Valiee, Seyed Reza Abdipour Mehrian, Sahand Khajeheian, Mahboobeh Saber, Alireza Abbasi, Ali Amanati  
**Ano:** 2026  
**Periódico:** Scientific Reports  
**Classificação:** atual  
**DOI:** https://doi.org/10.1038/s41598-026-64113-7  
**Link direto:** [https://doi.org/10.1038/s41598-026-64113-7](https://doi.org/10.1038/s41598-026-64113-7)

**Resumo:** Artigo relacionado ao tema “Lived experiences of navigating cancer medication access among patients, caregivers, and healthcare providers at a referral oncology teaching hospital”, situado no campo das intervenções psicoterapêuticas pragmáticas, breves e orientadas a objetivos. A referência é útil para estudar formulação de problemas, definição de metas, mecanismos de mudança, mensuração de resultados e escolha de estratégias focalizadas; a natureza e os achados específicos dependem do desenho apresentado no artigo original.

**Relevância:** Ajuda a compreender princípios pragmáticos de formulação, intervenção breve e avaliação orientada a problemas e objetivos.
